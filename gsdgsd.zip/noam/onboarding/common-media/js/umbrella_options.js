function Umbrella_Individual_All(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectUmbrella').checked = false;
     
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
 			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';	
			     
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_AAM_Individuals').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
	  document.getElementById('selectUmbrella').checked = false;

			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'inline';			

      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_AAM_Individuals').style.display = 'inline';
			break;

		case "umbrella":
      document.getElementById('selectUmbrella').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;

	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
      
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_AAM_Individuals').style.display = 'inline';
			break;
	} 
}

function Advisory_Portfolio_All(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectAdvisoryportfolio').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';           
		document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Advisory_Potfolio_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
	 		document.getElementById('I_AP_LFG_Fee').style.display = 'none';
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectAdvisoryportfolio').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';           
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Advisory_Potfolio_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
			document.getElementById('I_AP_LFG_Fee').style.display = 'inline';	
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';

      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "advisoryportfolio":
      document.getElementById('selectAdvisoryportfolio').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
 
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';          
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
      
      document.getElementById('I_Advisory_Potfolio_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
			document.getElementById('I_AP_LFG_Fee').style.display = 'none';
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
   
	} 
}


function Umbrella_Trust_All(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectUmbrella').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';           
		document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
	 		document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectUmbrella').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';           
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'inline';	
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';

      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "umbrella":
      document.getElementById('selectUmbrella').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
 
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';          
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
      
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
   
	} 
}
function Umbrella_Estate_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectUmbrella').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';     
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectUmbrella').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';    
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'inline';
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';

      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "umbrella":
      document.getElementById('selectUmbrella').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
      document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
			document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
   
	} 
}

function Umbrella_Entity_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectUmbrella').checked = false;


	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
      document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
 			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectUmbrella').checked = false;


	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';

      document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Umbrella_Playback').style.display = 'inline';
	  
			document.getElementById('I_Managed_General_App').style.display = 'inline';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "umbrella":
      document.getElementById('selectUmbrella').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';

      document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	  document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
 			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
	} 
}

function Umbrella_Entity_ERISA(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectUmbrella').checked = false;
    
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
      document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
 			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectUmbrella').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "umbrella":
      document.getElementById('selectUmbrella').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;

	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	  document.getElementById('I_Umbrella_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
 			document.getElementById('I_Umbrella_LFG_Fee').style.display = 'none';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
    
	} 
}



function Ind_IRA_Umbrella(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
	  document.getElementById('selectSEP').checked = false;
      
	  document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
	  document.getElementById('selectSEP').checked = false;
      
	  document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
			
	case "sep":	
	  document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = false;
	   document.getElementById('selectSEP').checked = true;
      
	  document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';	
		
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'inline';
      document.getElementById('I_Brokerage_5305').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
     		break;
			
	} 
}