/*
CAO Portal Comprehensive List of URLs
Last Updated: 05/13/2014
Author: Johnny Zhang
*/

var cao_email = {
  lfg: 'mailto:dl.CPB.US.LFG.NE.CAO.Hub@imcnam.ssmb.com',
  hnw: 'mailto:dl.cpb.us.hnw.cao.hub@imcnam.ssmb.com',
  cc_email:'mailto:*TC Trust Middle Office',
  ccb: 'mailto:CCB_Acct_Servicing@imcnam.ssmb.com',
  cim_us_emea_acct_opening: 'mailto:dl.cpb.us.tpg.account.opening@imcnam.ssmb.com',
  cpb_nam_americas_onboarding: 'mailto:dl.cpb.us.americas.onboarding.team@imcnam.ssmb.com',
  cim_latam_emea_acct_opening: 'mailto:dl.cbp.latam.tpg.account.opening@imcnam.ssmb.com',
  cim_us_client_support: 'mailto:dl.tpg.americas.client.service.support@imcnam.ssmb.com',
  christian_wilczek: 'mailto:cw81798@imcnam.ssmb.com',
  isaac_zion: 'mailto:iz32327@imcnam.ssmb.com',
  cb_checking_plus: 'mailto:SBB.Loanpath.Apps@imcnam.ssmb.com',
  citi_merchant_service_rep_ny: 'mailto:amy.surkin@firstdata.com',
  citi_metchant_service_rep_sf: 'mailto:Kate.Antonini@FirstData.com',
  cim_ca_client_emea_account_opening: 'mailto:dl.cbp.ca.tpg.account.opening@imcnam.ssmb.com',
  security_deposit_account_rodriguez: 'mailto:mr91803@imcnam.ssmb.com',
  security_deposit_account_estrada: 'mailto:je73139@imcnam.ssmb.com',
  security_deposit_account_koepp: 'mailto:tk02729@imcnam.ssmb.com',
  security_deposit_account_lopez: 'mailto:sl61353@imcnam.ssmb.com',
  security_deposit_account_perez: 'mailto:jp19248@imcnam.ssmb.com',
  isd_desk: 'mailto:*CPB NAM Managed Investments Desk',
  nam_americas_onboarding_team: 'mailto:dl.cpb.us.americas.onboarding.team@imcnam.ssmb.com',
  client_support_services: 'mailto:dl.cpb.americas.ao.credit.cards@imcnam.ssmb.com',
  us_client_service_support:'mailto:*CIM US Client Service Support',
  nam_cao_hub:'mailto:*CPB NAM HNW CAO Hub',
  nam_lfg_cao_hub:'mailto:*CPB NAM LFG NE CAO Hub',
  us_capital_markets:'mailto:dl.cpb.us.capital.markets.account.opening@imcnam.ssmb.com',
  tcmiddle:'mailto:*TC Middle Office Team',
  tcadvisory:'mailto:*TAC Trust Advisory Committee',
  ch_account_opening: 'mailto:*CPB CH Account Opening',
  cim_emea_pat: 'mailto: *CIM EMEA PAT',
  ch_securities_middle_office_zurich: 'mailto:*CPB CH Securities Middle Office Zurich ',
  emea_uk_cso_team: 'mailto: *CPB EMEA UK CSO Team ',
  ch_controls: 'mailto:*CPB CH Controls ',
  uk_tax_docs: 'mailto:*CPB UK Tax Documentation ',
  ch_tax_ops: 'mailto: *CPB CH Tax Ops ',
  uk_client_tax_reporting: 'mailto: *CPB UK Client Tax Reporting'
}      
var email = {
	michelle_tillery:'mailto:michelle.d.tillery@citi.com',
	justina_pearson:'mailto:justina.pearson@citi.com',
	eduardo_agostinho:'mailto:eduardo.henrique.agostinho@citi.com',
	john_huber:'mailto:john.r.huber@citi.com',
	victor_pagano:'mailto:victor.pagano@citi.com',
	kathy_chung:'mailto:kathy.chung@citi.com',
	nicole_galofaro:'mailto:nicole.galofaro@citi.com',
	thomas_pelletier:'mailto:thomas.john.pelletier@citi.com',
	dina_canzoneri:'mailto:dina.d.canzoneri@citi.com',
	marta_watsonvidot:'mailto:marta.watsonvidot@citi.com',
	melissa_mastroni:'mailto:melissa.mastroni@citi.com',
	cim_us_support:'mailto:dl.tpg.americas.client.service.support@imcnam.ssmb.com',
	patricia_perry:'mailto:patricia.perry@citi.com',
	mardochee_dorvilien:'mailto:mardochee.dorvilien@citi.com',
	juan_jimenez:'mailto:juan.jimenez@citi.com',
	mitch_higgins:'mailto:mitch.higgins@citi.com',
	tom_pirone:'mailto:thomas.pirone@citi.com',
	brian_kennedy:'mailto:brian2.kennedy@citi.com',
	cpb_latam_custom:'mailto:*CPB MACS CUSTOM',
	cheyenne_lewis:'mailto:cheyenne.l.lewis@citi.com',
	supervisory:'mailto:*CPB Americas Supervisory Principal Notifications',
	latam_sales:'mailto:*CPB LATAM Sales Support Requests',
	ewa_banach:'mailto:ewa.banach@citi.com',
	larry_repanes:'mailto:larry.repanes@citi.com',
	shirley_blunt:'mailto:shirley.n.blunt@citi.com',
	melissa_williams:'mailto:melissa.a.williams@citi.com',
	bruce_borgue:'mailto:bruce.r.bogue@citi.com',
	kathryn_turner:'mailto:kathryn.turner@citi.com',
	john_bagni:'mailto:john.bagni@citi.com',
	elsa_ramirez:'mailto:er67638@imcnam.ssmb.com',
	matt_woodruff: 'mailto:matthew.woodruff@citi.com',
	catherine_carmody: 'mailto:catherine.carmody@citi.com',
	nick_robinson: 'mailto:nick.a.robinson@citi.com',
	carmella_dirienzo: 'mailto:carmella.dirienzo@citi.com',
	patrick_holenstien: 'mailto:patrick.holenstein@citi.com ',
	guido_scaravilli: 'mailto:Guido.scaravilli@citi.com',
	robert_vanscherpenzeel:'mailto:robert.vanscherpenzeel@citi.com',
	barbara_hale: 'mailto:barbara_hale@citi.com',
	ralph_woog: 'mailto:ralph.woog@citi.com',
	santosh_kumar: 'mailto:santosh7.kumar@citi.com',
	travis_cooper: 'mailto:travis.alexander.cooper@citi.com',
	winnie_chow: 'mailto:winnie.yuen.man.chow@citi.com',
	maggie_tan: 'mailto:maggie.tan@citi.com',
	daniel_seixas: 'mailto:daniel.seixas@citi.com',
	marjo_fung: 'mailto:marjo1.fung@citi.com',
	maria_wong: 'mailto:maria.k.y.wong@citi.com',
	song_li:'mailto:song.li@citi.com',
	susanna_chan: 'mailto:susanna.chan@citi.com',
	carolyn_leung: 'mailto:carolyn.leung@citi.com',
	robert_mcguire: 'mailto:robertj.mcguire@citi.com'
	
}
  
var citibusiness = {
	schedule_of_fees_2016:'https://www.privatebank.citigroup.net/banking/docs/schedule_of_fees_2016.pdf',
	application: 'https://www.privatebank.citigroup.net/banking/docs/Business_Deposit_Account_Application.pdf',
	signature_card: 'https://www.privatebank.citigroup.net/banking/docs/PBG302A_SigCd_1106_B1.pdf',
	indemmnifcation_letter_signing_authority: '/noam/onboarding/common-media/docs/kyc/Indemnification_Letter_Signing_Authority.doc',
	title_extension_policy: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/acceptable_titles_for_special_title_account.pdf',
	amendment_for_erisa_408b2: 'https://www.privatebank.citigroup.net/banking/docs/erisaCMAmendment.pdf',
  	erisa_408b2_disclosure: 'http://citi.com/investorinfo/advisoryprivacy/408b2disclosures/citibus_disc.pdf',
	amendment_for_fdic_coverage: 'https://www.privatebank.citigroup.net/banking/docs/fdicAmendment.pdf',
	branch_transfer_form: '/noam/kc/forms/docs/branch_transfer_form_citibusiness.pdf',
	branch_transfer_procedures: '/noam/kc/forms/docs/business_retail_transfer_procedures.pdf',
	certificate_of_fiduciaries: 'https://www.privatebank.citigroup.net/banking/docs/CertofFidPBG334_1006_B.pdf',
	client_manual: 'https://www.privatebank.citigroup.net/banking/docs/citiBusinessClientManual.pdf',
	online_enrollment_page: 'http://www.citigroup.net/banking/useb/forms/citibusiness_online_forms.htm',
	schedule_of_fees_2014: '/banking/docs/Schedule_Fees_Charges_2014.pdf',
	schedule_of_fees_2015: '/banking/docs/Schedule_Fees_Charges_2015.pdf',
	client_funds_transfer_agreement: 'https://www.privatebank.citigroup.net/banking/docs/fundsTransferAgreement.pdf',
	client_funds_transfer_instructions_terms_and_conditions: 'https://www.privatebank.citigroup.net/banking/docs/CFTTermsConditions.pdf',
	cpb_addendum_citibusiness_client_manual: 'https://www.privatebank.citigroup.net/banking/docs/PBG-4_1108_B-CPB.pdf',
	fax_advisory_service_enrollment_all_other_marketplace: 'http://www.citigroup.net/banking/useb/forms/pdf-files/i/IncomingWireTransfer.pdf',
	fax_advisory_service_enrollment_ny_marketplace: 'https://www.privatebank.citigroup.net/banking/citibusiness_docs/FaxAdvCitiBusPBG-FAE_1006_final.pdf',
	federal_funds_approval: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/federal_funds_approval.docx',
	funds_transfer_agreement: 'https://www.privatebank.citigroup.net/banking/citibusiness_docs/FaxAdvCitiBusPBG-FAE_1006_final.pdf',
	important_notice_regarding_your_citibusiness_banking_card: 'https://www.privatebank.citigroup.net/banking/docs/citiBusinessBankingCardAddendum.pdf',
	incoming_wire_notification: 'https://www.privatebank.citigroup.net/banking/citibusiness_docs/686IncomingWireNotificationRequestForm.pdf',
	standing_predefined_funds_transfer_form: 'https://www.privatebank.citigroup.net/banking/citibusiness_docs/Standing_Pre_defined_FT_PBG335_1006_final.pdf',
  	renmimbi_disclosure: 'https://www.privatebank.citigroup.net/banking/docs/renmimbi_disclosure.pdf',
  	business_atm_txns_cutoff: 'https://www.privatebank.citigroup.net/banking/docs/NCOT_debit_cutoff_flyer.pdf',
  	important_note_about_security: 'https://www.privatebank.citigroup.net/banking/citibusiness_docs/696_071108_lh_TPGemailadviseletterhead.doc',
 	branch_transfer_form: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/branch_transfer_form_citibusiness.pdf',
  	checking_plus_application: 'http://www.citigroup.net/banking/useb/forms/pdf-files/cb/business_checking_plus_application_KIT_less_20000.pdf',
	exchange_sales_operation_process: 'https://www.privatebank.citigroup.net/banking/docs/1031_xchng_Sales_Op_Process.doc',
  	cbusol_enrollement_form: 'http://www.citigroup.net/banking/useb/forms/pdf-files/cb/cb_online_enrollment_form.pdf',
  	cbusol_maintenance_and_custom_entitlement: 'http://www.citigroup.net/banking/useb/forms/pdf-files/cb/cb_online_maintenance_form.pdf',
	cbusol_appointment_form: '/noam/onboarding/common-media/docs/banking/cbusol_appointment_form.pdf',
  	citibusiness_online_forms: 'http://www.citigroup.net/banking/useb/forms/citibusiness_online_forms.htm',
  	aged_document_policy: 'https://www.privatebank.citigroup.net/banking/docs/agedDocumentPolicy.pdf',
  	fiduciary_lending_sticker: 'https://www.privatebank.citigroup.net/noam/cra/docs/fiduciaryLendingStickerNewCitibank.pdf',
  	cbp_exchange: 'https://www.privatebank.citigroup.net/banking/docs/Communications_CPBxchg.pdf',
  	one_generation_citifolio_package: '/noam/onboarding/common-media/docs/banking/1GEN_CitiFolioPackage.pdf',
  	one_generation_cra_package: '/noam/onboarding/common-media/docs/banking/1GEN_CRA.pdf',
  	old_citifolio_package: '/noam/onboarding/common-media/docs/banking/OLD_CitiFolio.pdf',
 	old_cra_package: '/noam/onboarding/common-media/docs/banking/OLD_CRA.pdf',
	cc_merchant_services_product_overview: 'https://www.privatebank.citigroup.net/banking/docs/MS_INTERNAL_Flyer.pdf',
  	cc_merchant_services_client_onepager: 'https://www.privatebank.citigroup.net/banking/docs/Merch_Services_Client_Flyer.pdf',
  	cc_merchant_services_website: 'http://www.firstdata.com/',
  	cc_merchant_services_referrals: 'http://www.merchantreferrals.com/',
  	banking_product_overview: 'https://www.privatebank.citigroup.net/banking/product_serviceOverview.ppt',
  	payroll_prepaid_information: 'http://act.moneynetwork.com/content/payroll-distribution?MNDPS=mn',
  	payroll_prepaid_apa: 'http://www.firstdata.com/apa',
  	small_business_card_placemat: '/banking/docs/BusinessCardPlacemat.pdf',
	joint_and_several_domestic: '/banking/docs/joint_and_several_dom_app.pdf',
  	small_business_js_app_domestic: '/banking/docs/JSApplicationDomestic.pdf',
  	small_business_js_app_global: '/banking/docs/JSApplicationGlobal.pdf',
  	small_business_js_app_corporate: '/banking/docs/JSApplicationCorporate.pdf',
  	small_business_js_app_corporate_internal_chklist:'/banking/docs/JSApplicationCorporate_Internal_Chklist.pdf',
  	small_business_app_instructions: 'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/onboarding-smallBusinessAppInstructions.pdf',
	mmdpapp: 'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/MMDPApplication.pdf',
	mmdpagree: 'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/MMDPAgreement.pdf',
	mmdptransfer:'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/MMDPTransfer.pdf',
  	middle_market_referral_wizard: 'http://salesforceautomationprod.citibanknorthamerica.citigroup.net/productwizard/',
  	fatca: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/FATCA_Buckslip.pdf',
  	security_deposit_info:'https://www.privatebank.citigroup.net/banking/securityDepositAccts.htm',
	final_control_account_sda_application_form: '/noam/onboarding/common-media/docs/banking/Final_Control_Account_SDA_Application_Form.pdf',
	sda_tenant_account_application:'/noam/onboarding/common-media/docs/banking/SDA_tenant_account_application.pdf',
	joint_and_several_domestic_application_instructions:'/noam/onboarding/common-media/docs/banking/joint_and_several_domestic_application_instructions.pdf'
};


var citiescrow = {	
	control_application: 'https://www.privatebank.citigroup.net/banking/docs/CitiEscrow_Control_Account.pdf',
	client_application: 'https://www.privatebank.citigroup.net/banking/docs/CitiEscrow_Client_Account.pdf',
	shared_interest_income: 'https://www.privatebank.citigroup.net/banking/docs/SharedInterestIncomeSetup.doc',
	iota_iolta_account_policies: 'http://www.source.citicorp.com/srvs/source_html/BusinessAccountOpeningIOLAIOLTAIOTAAccounts.html?Source20=Yes&OBJID=83052&Title=Business%20Account%20Opening:%20IOLA/IOLTA/IOTA%20Accounts',
	bar_tax_id_holding_accounts: 'https://www.privatebank.citigroup.net/banking/docs/BarTaxID_HoldingAccounts.xls'
};


var resolution = {
	general: '/noam/onboarding/common-media/docs/banking/general_deposit_resolution.pdf',
	llc: 'https://www.privatebank.citigroup.net/banking/docs/LLC_PBG331_1006_final.pdf',
	corporation: 'https://www.privatebank.citigroup.net/banking/docs/Corp_Res_PBG327_1006_final2.pdf',
	joint_venture: 'https://www.privatebank.citigroup.net/banking/docs/JointVenturePBG333_1006_B.pdf',
	partnership: 'https://www.privatebank.citigroup.net/banking/docs/Partnership_PBG329_1006_final.pdf',
	firm_partnership: 'https://www.privatebank.citigroup.net/banking/docs/Partnership_Law_Firms_PBG329_1006_final.pdf',
	firm_supp: 'https://www.privatebank.citigroup.net/banking/docs/sup_to_partnership_dec_and_agree_LF.pdf',
	single_stockholder: 'https://www.privatebank.citigroup.net/banking/docs/Single_Stockholder_PBG328_1006_final.pdf',
	unincorporated: 'https://www.privatebank.citigroup.net/banking/docs/Unincorporated_Res_PBG332_1006_final.pdf',
	addendum: 'https://www.privatebank.citigroup.net/banking/docs/Addendum_Bus_Gen_Deposit.pdf' ,
	cotrolling_entity:'https://www.privatebank.citigroup.net/banking/docs/Controlling_Entity_Resolution.pdf'
};



var tax_certification = {
	w9: 'http://www.irs.gov/pub/irs-pdf/fw9.pdf',
	w8ben: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/canada/W8ben.pdf',
	w8ben_2014: 'http://www.irs.gov/pub/irs-pdf/fw8ben.pdf',
	w8bene:'http://www.irs.gov/pub/irs-pdf/fw8bene.pdf',
	w8_imy: 'http://www.irs.gov/pub/irs-pdf/fw8imy.pdf',
	w8_imy_info: 'http://www.irs.gov/formw8imy',
	witholding_statement: '/noam/onboarding/common-media/docs/canada/Canada_Withholding_Statement.pdf',
	w8_exp:'http://www.irs.gov/pub/irs-pdf/fw8exp.pdf',
	fatca_site:'https://www.privatebank.citigroup.net/compliance/fatca.htm' 
};


var citifolio = {
	application: '/noam/onboarding/common-media/docs/banking/citifolio_application_form.pdf',
	signature_card: '/noam/onboarding/common-media/docs/banking/citifolio_signature_card.pdf',
	terms_and_conditions: '/banking/docs/CitiFolioT_C_march13.pdf',
  credit_card_offers: 'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/Amendment_Terms_and_Conditions_July_2016_Citifolio.pdf',
  product_service_fact_sheet: 'https://www.privatebank.citigroup.net/banking/docs/PBG718BKG_March2013.pdf',
  credit_card_amendments: 'https://www.privatebank.citigroup.net/banking/docs/prestigeAABenefits.pdf',
  client_manual_update_error_resolution: 'https://www.privatebank.citigroup.net/banking/docs/TC_Comunications_CBPex.doc',
  compilation_amendments: '/noam/onboarding/common-media/docs/banking/disclosures_CitiFolioamdt.pdf',
  dodd_frank: 'https://www.privatebank.citigroup.net/banking/docs/Checking_Plus.pdf',
  citifolio_application_ccl: 'https://www.privatebank.citigroup.net/banking/docs/CitiFolioApplication.pdf',
   global_client: 'http://citiweb1.citicorp.com/banking/useb/forms/nfo/cards/globalclient/',
   cards: 'http://citiweb1.citicorp.com/banking/useb/forms/nfo/index.html',
   july_2016_ammendments_tc_citfolio: 'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/Amendment_Terms_and_Conditions_July_2016_Citifolio.pdf' 
};

var cra = {
  application: '/noam/onboarding/common-media/docs/banking/cra_application_form.pdf',
  signature_card: '/noam/onboarding/common-media/docs/banking/cra_signature_card.pdf',
  terms_and_conditions: '/banking/docs/CRA_TC.pdf',
  adv_bio_overview: 'https://www.privatebank.citigroup.net/noam/cra/docs/ADV2B_Overview.pdf',
  credit_card_offers: 'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/Amendment_Terms_and_Conditions_July_2016.pdf',
  product_service_fact_sheet: 'https://www.privatebank.citigroup.net/banking/docs/products_services_factsheet.pdf',
  compilation_amendments: '/noam/onboarding/common-media/docs/banking/disclosures_CRAamdt.pdf',
  lfg_fee: '/noam/onboarding/common-media/docs/umbrella/MACS_LFG_Fee.pdf',
  banking_T_and_C_Citifolio_CRA: '/noam/onboarding/common-media/docs/banking/banker_attestation_banking_tandc.pdf',
  april_2016_ammendments_tc:'/noam/onboarding/common-media/docs/banking/Amendment_Terms_and_Conditions_April_2016.pdf',
  july_2016_ammendments_tc:'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/Amendment_Terms_and_Conditions_July_2016.pdf',
  banking_july_2016_ammendments_tc:"https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/banking_july_2016_ammendments_tc.pdf",
  aug_2016_ammendments_tc:"https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/banking/banking_amendments_tc.pdf",
  cover_letter: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/cover_letter_cra_citifolio.pdf', 
  tax_attestation: '/noam/onboarding/common-media/docs/banking/tax_attestation_client.pdf',
  banker_tax_attestation: 'https://www.privatebank.citigroup.net/compliance/docs/Banker-Onboarding-Attestation-Form.pdf' 
  
};


var consumer = {
	reg_dd_upgrade_form: 'https://www.privatebank.citigroup.net/banking/docs/REGDDUpgradeForm.doc',
	cpb_revocable_living_trust_conversion: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/banking/cpb_convert_accts_ind-rev_trust.doc',
	citibank_auto_deduct_authorization: 'http://www.citigroup.net/banking/useb/forms/pdf-files/a/Citi_Auto_Deduct_Auth_Form.pdf',
	web_paper_enrollment_form_cpb: 'https://www.privatebank.citigroup.net/applications/cws/docs/extenrollform_us.pdf',
	removal_of_deceased_account_holder: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/banking/removing_deceased_acct_holder.pdf',
	explanation_of_us_address_nra: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/explain_us_address.doc',
	tennants_in_common: 'http://www.citigroup.net/banking/useb/forms/pdf-files/t/TenantsInCommon.pdf',
	prepatriot_act_id_exception: 'http://www.citigroup.net/privbank/businessriskandcontrol/onesource-conversion/documents/id_memos/pre-patriot_act_clients.doc',
	minor_account_opening_process: '/noam/kc/forms/docs/minor_account_opening_process.pdf',
	branch_transfer_form_retail: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/branch_transfer_form_retail&citigold.pdf',
	checking_plus_line_replacement_form: 'https://www.privatebank.citigroup.net/banking/docs/CheckingPlus_REPLACEMENT_Form.pdf',
	direct_debit_authorization: 'https://www.privatebank.citigroup.net/banking/docs/DirectDebitAuthorization.pdf',
	direct_deposit_authorization: 'https://www.privatebank.citigroup.net/banking/docs/DirectDepositAuthorization.pdf',
	funds_transfer_instruction: 'https://www.privatebank.citigroup.net/banking/citifolio/FundsTransferInstructions.pdf',
	funds_transfer_instruction_trust_estate_only: 'https://www.privatebank.citigroup.net/banking/citifolio/47495_1208_final.pdf',
	funds_transfer_standing_predefined_individual: 'https://www.privatebank.citigroup.net/banking/citifolio/PBG728_1208_final.pdf',
	itf_beneficiary_designation: 'https://www.privatebank.citigroup.net/banking/docs/CitiFolio_ITF_addendum.doc',
	joint_account_delete_signer_form: '/noam/onboarding/common-media/docs/banking/joint_account_delete_signer.pdf',
	joint_minor_indem_DTD: '/noam/kc/forms/docs/indemnity_letter_dtd_savings_acc.doc',
  joint_minor_indem_CheckMM: '/noam/kc/forms/docs/indemnity_letter_money_market_acc.doc',
  joint_minor_indem_AddMinor: '/noam/kc/forms/docs/indemnity_letter_add_minor.doc',
  joint_minor_indem_RetailMinorCo: '/noam/kc/forms/docs/indemnity_letter_retail_transfer_minor_coapp.doc',
  joint_minor_indem_RetailMinorPrimary: '/noam/kc/forms/docs/indemnity_letter_retail_transfer_primary_accholder.doc',
  power_of_attorney_POA_NY_Only: 'https://www.privatebank.citigroup.net/banking/citifolio/PBG715-NY.pdf',
	power_of_attorney_POA: 'https://www.privatebank.citigroup.net/banking/citifolio/PBG715_POA_1006final.pdf',
	temporary_fdic_notice: 'https://www.privatebank.citigroup.net/banking/docs/fdicAnnouncement.doc',
	joint_account_agreement_to_delete_account_signer: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/joint_account_delete_signer.pdf',
	legal_title_change: '/noam/kc/forms/docs/legal_title_change.docx',
  checking_plus: 'https://www.privatebank.citigroup.net/banking/checking_plus.htm',
  branch_transfer_form_faq: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/consumer_transfer_faq.pdf',
  citifolio_latest_ao_kit: '/noam/onboarding/inc/banking/Banking_Order_latest_CRA.htm',
  power_of_attorney_full_force_affidavit: '/noam/onboarding/common-media/docs/banking/power_of_attorney_full_force_affidavit.pdf',
  process_transfer_accts_btwn_LA_US: '/noam/onboarding/common-media/docs/banking/process_transfer_accts_btwn_LA_US.pdf',
  tax_attestation: 'www.google.com'
};


var aam = {
	entity_lfg: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/aam_entity_lfg.pdf',
	entity_hnw: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/aam_entity_hnw.pdf',
	individual_lfg: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/aam_individual_lfg.pdf',
	individual_hnw: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/aam_individual_hnw.pdf',
  aam_guidelines: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/aam_guidelines.pdf',
  aam_guidelines_replay: 'https://training.citigroup.net/SumTotal/app/management/LMS_ActDetails.aspx?UserMode=0&ActivityId=1110805',
  aam_form_training: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/aam_form_training.pdf',
  aam_guidelines_non_sens: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/aam_guidelines_non-sens.pdf'
};


var common_investment = {
	managed_general_account_application: 'https://www.privatebank.citigroup.net/investments/managed/US_Disc_Combined_field.pdf',
	cgmi_adv: 'https://www.privatebank.citibank.com/pdf/cgmi_adv.pdf',
	cip_form: 'https://www.privatebank.citigroup.net/noam/kc/pershing/docs/CIP_Form.pdf',
	community_property_form: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/community_prop_form.pdf',
	cpb_securities_tickets: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/cpb_securities_tickets.pdf',
	erisa_disclosure_cover_letter: 'https://www.privatebank.citigroup.net/noam/kc/us_service/docs/408b2_external_communication_to_plan_sponsors.pdf',
	ip_profile_template_for_managed_portfolios: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/OnBoarding_Template.pdf',
	joint_account_grid_managed_portfolios: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/joint_account_types.pdf',
	loa_to_transfer_assets: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/3171A-CPB.pdf',
	managed_account_maintenance_grid: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/cpb_loa_maint_managed.pdf',
	managed_account_tax_selling: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/tax_selling_loa1_final.pdf',
	managed_account_tax_selling_faq: 'https://www.privatebank.citigroup.net/noam/kc/communications/docs-old/20080804_tax_selling_qa.pdf',
	managed_account_tax_selling_guidelines_pershing: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/cti.pdf',
	managed_account_tax_selling_providing_usd_amount_for_losses_pershing_template: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/tax_selling_loa2_final.pdf',
	managed_account_tax_selling_take_maximum_losses_pershing_template: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/tax_selling_loa3_final.pdf',
	organizational_agreement_managed_portfolios_and_investor_accounts: 'http://portal.privatebank.citigroup.net/gwm/citigroup_private_bank/products/investments/common-forms/cpb_org_agreement.pdf',
	sei_transfer_form_non_ira: 'https://www.privatebank.citigroup.net/investments/managed/0256_acttrans.pdf',
	sei_trustee_to_trustee_transfer_form: 'https://www.privatebank.citigroup.net/investments/managed/0256_ttee2ttee.pdf',
	tenants_by_entirety_rider_managed_portfolios_fl_residents_only: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/Tenants_By_Entirety_IM_Rider.pdf',
	tenants_in_common_rider_managed_portfolios: 'https://www.privatebank.citigroup.net/investments/managed/tenant-in-common_rider.pdf',
	tenants_in_common_rider_cgmi:
'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/2103_Tenants_in_Common.pdf',
	third_party_designation_form_managed_portfolios: 'https://www.privatebank.citigroup.net/investments/managed/cpb_third_party.pdf',
	tod_affidavit_form_5474_cpb_pershing_only: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/TOD_agreement.pdf', 
	tod_affidavit_cim: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/ToD_affidavit.pdf',
	tod_agreement_beneficiary_designation_form_6949_cpb_pershing_only: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/5474-CPB.pdf',
	tod_beneficiary_designation_cim: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/TOD_ben_designation.pdf',
	us_approval_requirements_managed_portfolios: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/managed_portfolios/US_approval_requirements.pdf',
  ERISA_OS_Banker_Attestation: 'https://www.privatebank.citigroup.net/noam/kc/us_service/docs/onesource_408(b)(2)_short-term.pdf',
  Form_2323: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/Form_2323.pdf',
  ADV_Part2: 'https://www.privatebank.citigroup.net/noam/cra/docs/ADV2B_Overview.pdf',
  Privacy_Notice: 'https://www.privatebank.citibank.com/privacy.htm',
  ERISA_408B2_Citi_Investment_Advisory: 'http://www.citi.com/investorinfo/advisoryprivacy/408b2disclosures/invadv_disc.pdf',                                         
  fee_linkage_form: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/CPB_managed_feelinkage_form.pdf',
  erisa_blocked_list: 'https://www.privatebank.citigroup.net/noam/kc/us_service/docs/list_managers_without_408b2disclosure.xls',
  erisa_regulation: 'https://www.privatebank.citigroup.net/noam/kc/us_service/a-e_files/erisa_408b2.htm',
  general_investment: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/Investment_Management_Application.pdf'
};


var investments_ira = {
  cpb_ira_constibution_form: 'https://www.privatebank.citigroup.net/investments/managed/6897_CPB_IRA_Contribution.pdf',
  pc_ira_distribution_form: 'https://www.privatebank.citigroup.net/investments/managed/6893_CPB_IRA_Distrib.pdf',
	cpb_ira_transfer_form: 'https://www.privatebank.citigroup.net/investments/managed/0256_ttee2ttee.pdf',
	cpb_roth_ira_contribution_form: 'https://www.privatebank.citigroup.net/custody/common-forms/Roth_IRA_Contribution_Form.pdf',
  ira_application_citibank_na: 'http://www.citigroup.net/banking/useb/forms/pdf-files/r/RPS/CIS069SB.pdf',
	ira_beneficiary_designation_pershing:'https://www.privatebank.citigroup.net/noam/kc/forms/docs/IRA-designation.pdf',
	ira_change_information_form_citibank_na: 'http://www.citigroup.net/banking/useb/forms/pdf-files/r/RPS/356667.pdf',
	ira_charitible_distribution_request_form_openwealth: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/IRA_charitable_dist_req_form.pdf',
	ira_contribution_form_pershing: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/IRA-contribution_form.pdf',
	ira_distribution_form_pershing: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/IRA-DIST.pdf',
  roth_adoption_agreement_pershing_only: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/IRAB-ROTH-ADOP.pdf',
	roth_conversion_recharacterization_request_pershing: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/ROTH_recharacterization_form.pdf',
  roth_ira_plan_documents_openwealth: 'http://www.citigroup.net/banking/useb/forms/pdf-files/r/RPS/56001-D.pdf',
  traditional_ira_plan_documents: 'http://www.citigroup.net/banking/useb/forms/pdf-files/r/RPS/355925-D.pdf',
	traditional_ira_plan_documents_openwealth_only: 'http://www.citigroup.net/banking/useb/forms/pdf-files/r/RPS/355925-D.pdf',
	traditional_sep_ire_adoption_agreement_pershing_only: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/IRAB_TRAD_ADOP.pdf',
  citibank_ira_application: 'http://www.citigroup.net/banking/useb/forms/pdf-files/r/RPS/CIS069.pdf'
};

	
var investor_account = {
	application_old: 'http://portal.privatebank.citigroup.net/gwm/citigroup_private_bank/products/investments/capital_markets/common-forms/0318_investor_agree.pdf',
	application: 'https://www.privatebank.citigroup.net/investments/capital_markets/docs/0318_Investor_Agreement.pdf',
	playback: 'https://www.privatebank.citigroup.net/noam/cra/docs/playback/investor.pdf',
	tenants_in_common_rider: 'https://www.privatebank.citigroup.net/investments/managed/TIC_investor_rider.pdf',
  erisa_40b2:'http://citi.com/investorinfo/advisoryprivacy/408b2disclosures/cpbinvstr_disc.pdf',
  tenants_in_common_rider: '/noam/onboarding/common-media/docs/investor/CPB_TIC_Rider_Investor.pdf',
  tc_amendments:'/noam/onboarding/common-media/docs/investor/TC_Amendment.pdf'
};


var brokerage = {
	brokerage_3026: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/3026-CPB.pdf',
	brokerage_internal_addendum: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/internal_addendums.doc',
	account_transfer_form_pershing_only: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/account_transfer_form.pdf',
	quick_reference_guide: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/Quick_Reference_Grid.xls',
  erisa_408b2: 'http://citi.com/investorinfo/advisoryprivacy/408b2disclosures/brkrg_disc.pdf',
  trust_certification: '/noam/onboarding/common-media/docs/brokerage/5036_Trust_Certification.pdf',
  estate_certification: '/noam/onboarding/common-media/docs/brokerage/5501_Estate_Certification.pdf',
  affidavit_domocile: '/noam/onboarding/common-media/docs/brokerage/2115_Affidavit_of_Domicle.pdf',
  brokerage_5143: '/noam/onboarding/common-media/docs/brokerage/5143_IRA_Brokerage.pdf',
  form_2104: '/noam/onboarding/common-media/docs/brokerage/2104_Partnership.pdf',
  form_2105: '/noam/onboarding/common-media/docs/brokerage/2105_Corporate.pdf',
  form_5305: '/noam/onboarding/common-media/docs/brokerage/5305_SEP.pdf',
  form_5466: '/noam/onboarding/common-media/docs/brokerage/5466_LLC.pdf',
  form_sep_408_adop: '/noam/onboarding/common-media/docs/brokerage/SEP-408-ADOP-CPB.pdf',
  form_3164: '/noam/onboarding/common-media/docs/brokerage/3164_Sole.pdf',
  form_5277: '/noam/onboarding/common-media/docs/brokerage/5277_Unincorporated.pdf',
  form_5699: '/noam/onboarding/common-media/docs/brokerage/5699_CES.pdf',
  form_6603: '/noam/onboarding/common-media/docs/brokerage/6603_Citi_Advisor.pdf',
  form_6831: '/noam/onboarding/common-media/docs/brokerage/6831_DAP.pdf', 
  form_9841: '/noam/onboarding/common-media/docs/brokerage/9841_Fiduciary_Services.pdf',
  form_9843: '/noam/onboarding/common-media/docs/brokerage/9843_Investment_Management.pdf', //<--Single Advisory Contract (SAC)
  form_5130: '/noam/onboarding/common-media/docs/brokerage/5130_IPO_Certification.pdf',
  form_5800: '/noam/onboarding/common-media/docs/brokerage/5800_Entity_No_Agent.pdf',
  form_5802: '/noam/onboarding/common-media/docs/brokerage/5802_Entity_Entity_Agent.pdf',
  form_5803: '/noam/onboarding/common-media/docs/brokerage/5803_Entity_Individual_Agent.pdf',
  form_6034: '/noam/onboarding/common-media/docs/brokerage/6034_Individual_No_Agent.pdf',
  form_6035: '/noam/onboarding/common-media/docs/brokerage/6035_Individual_Agent.pdf',
  form_6600: '/noam/onboarding/common-media/docs/brokerage/6600_Equity_Offerings.pdf',
  form_6601: '/noam/onboarding/common-media/docs/brokerage/6601_Fixed_Income_2.pdf',
  form_6610: '/noam/onboarding/common-media/docs/brokerage/6610_Fixed_Income_3.pdf',
  form_7610: '/noam/onboarding/common-media/docs/brokerage/7610_Syndicate_EDelivery.pdf',
  form_5485: '/noam/onboarding/common-media/docs/brokerage/5485_Prime_Broker_Agreement.pdf',
  form_2053: '/noam/onboarding/common-media/docs/brokerage/2053_Community_Property.pdf',
  form_2103: '/noam/onboarding/common-media/docs/brokerage/2103_Tenants_in_Common.pdf',
  form_5502: '/noam/onboarding/common-media/docs/brokerage/5502_ERISA.pdf',
  form_4875: '/noam/onboarding/common-media/docs/brokerage/4875_Fiduciary_Services.pdf',
  form_3590c: '/noam/onboarding/common-media/docs/brokerage/3590C.pdf',
  dvp_citi_settlement: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/I_Form_Brokerage_DVP_Citi_Settlement.pdf',
  form_5868: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/5868_Agent_Info.pdf',
  form_0518: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/0518_Options_Account_Application.pdf',
  form_ira_dist: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/IRA-DIST-CPB.pdf',
  form_qrp_cont: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/QRP_CONT_CPB.pdf',
  form_ach: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/ACH-A-C.pdf',
  form_5121: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/5121_DPOA_Limited.pdf',
  form_6949: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/6949_TOD.pdf',
  form_2315: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/2315_DPOA_Full.pdf',
  form_3882: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/3882_Texas_Joint_Account.pdf',
  form_5272: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/5272_SLOA.pdf',
  form_9545:'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/9545_Enrollment.pdf',
  recharacter: '/noam/onboarding/common-media/docs/brokerage/recharacter.pdf',
  c92_ao_guide: '/noam/onboarding/common-media/docs/brokerage/c92_acct_opening_reference_guide.pdf',
  citi_trust_forms:'/noam/onboarding/common-media/docs/brokerage/citi_trust_forms.pdf',
  OB_Ref_Brokerage: 'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/brokerage/Brokerage_Reference_Guide.pdf',
  tax_exemptmmmf: '/noam/onboarding/common-media/docs/brokerage/tax_exempt.pdf'
};

var latam_brokerage = {
	form5521C:'/noam/onboarding/common-media/docs/brokerage/5521C.pdf',
	form5556:'/noam/onboarding/common-media/docs/brokerage/5556.pdf',
	form5966:'/noam/onboarding/common-media/docs/brokerage/5966.pdf',
	form2313:'/noam/onboarding/common-media/docs/brokerage/2313.pdf',
	form2314:'/noam/onboarding/common-media/docs/brokerage/2314.pdf',
	form9240:'/noam/onboarding/common-media/docs/brokerage/9240.pdf',
	wolf_question:'/noam/onboarding/common-media/docs/brokerage/wolf_question.pdf',
	sic_waiver:'/noam/onboarding/common-media/docs/brokerage/sic_waiver.pdf',
	form67131:'/noam/onboarding/common-media/docs/brokerage/67131.pdf'
};

var capital_markets = {
	capital_markets_isda_request_form: '/noam/kc/us_products/docs/managed_portfolios/Capital_Mkts_Acct_Opening_Form.doc',
	dcli_account_agreement: 'https://www.privatebank.citigroup.net/investments/us-capitalMarkets/docs/fx/DCLIAccountAggrement.pdf',
	dcli_information_statement: 'https://www.privatebank.citigroup.net/investments/us-capitalMarkets/docs/fx/DCLIInfoStatement.pdf',
	capital_markets_client_eligibility_requirements: 'https://www.privatebank.citigroup.net/investments/us-capitalMarkets/docs/ClientEligibilityReq_NDF.pdf',
	foreign_exchange_transaction_approval_memo: 'https://www.privatebank.citigroup.net/investments/managed/tam.doc',
	global_sponsorship: '/noam/onboarding/common-media/docs/capital_markets/Capital_Markets_Global_Sponsorship_Form.doc',
	ecp_attestation_form: '/noam/onboarding/common-media/docs/capital_markets/ECP_Attestation_Form_Individual.xls',
	qi_banker_attestation: '/noam/onboarding/common-media/docs/capital_markets/Capital_Markets_QI_Banker_Attestation.xls',
	structured_notes_master_agreement: '/noam/onboarding/common-media/docs/capital_markets/Capital_Markets_Structured_Notes_Agreement.pdf',
  ecp_one_pager: '/noam/onboarding/common-media/docs/capital_markets/ECP_One_Pager.pdf',
  ai: 'http://www.sec.gov/answers/accred.htm',
  df_scope:'/noam/onboarding/common-media/docs/capital_markets/df_scope_products.pdf',
  tam:'/noam/onboarding/common-media/docs/capital_markets/transaction_approval_memo.pdf',
  dodd_frank_clearing:'/noam/onboarding/common-media/docs/capital_markets/df_clearing_exception.pdf',
  gov_pressroom:'http://www.cftc.gov/PressRoom/PressReleases/pr6429-12'
};


var msp = {
	msp_product_specific: 'https://www.privatebank.citigroup.net/investments/managed/MSP_fields.pdf',
	msp_playback: 'https://www.privatebank.citigroup.net/noam/cra/docs/playback/msp.pdf',
	msp_addendum: 'https://www.privatebank.citigroup.net/investments/managed/msp_addendum.pdf',
	msp_e_delivery_consent_form: 'https://www.privatebank.citigroup.net/noam/kc/communications/docs/client_communications/eDelivery_Consent.pdf',	
	msp_terms_and_conditions: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/MSP_TC_US.pdf',
	msp_verbal_form: 'https://www.privatebank.citigroup.net/investments/managed/msp_US_verbal_form.pdf',
	sma_manager_fees: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/SMAManagerFeeSchedule.pdf',
	third_party_designation: '/noam/onboarding/common-media/docs/investor/third_party_designation.pdf'
};

var fs = {
	fs_playback: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/Fiduciary_Services_Playback.pdf',
  fee_eligibilty_grid:'http://portal.privatebank.citigroup.net/gwm/citigroup_private_bank/products/investments/manager_selection_program/common-communications/SMAFeeEligibilityGrid.pdf',
  cms_new_account_fs: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/FS_CMS Package_RE.pdf',
  exception_grid: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/approvalGrid.pdf'
};


var cim = {
	cim_administration_form: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/0647_tpg_admin.pdf',
	cim_administration_form_Old: '/noam/onboarding/common-media/docs/CIM_admin_OLD_VERSION.pdf', 
	cim_administration_form_latamNY: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/0647_tpg_admin.pdf',
	cim_administration_form_latamNY_Old: '/noam/onboarding/common-media/docs/CIM_admin_OLD_VERSION.pdf',
	cim_product_specific: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/product_application_US.pdf',
	cim_playback: 'https://www.privatebank.citigroup.net/noam/cra/docs/playback/CIM.pdf',
	cim_portfolio_change_form: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/TPG_Portfolio_Change_Form.pdf',
	cim_terms_and_conditions: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/0866_tailored_tc_us.pdf',
	cim_verbal_form: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/tpg_US_verbal_form.pdf',
  third_party_custody_side: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/CustodySideLetter.pdf',
  cim_core_application: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/TPGUSCoreAppRE.pdf',
  cim_adiminstration_form_emea: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/TPG-AdminForm.pdf',
  cim_emea_account_checklist:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/CIM_GLOBAL_CHECKLIST.docx',
  cim_core_tdp_tcs: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/TPGLatamTermsConditions.pdf',
  tdp_workflow: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/opening_tdp.pdf',
  tdp_change_form: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/691863_TPG_TDP.pdf',
  trust_account_form_us: 'https://www.privatebank.citigroup.net/trust/documents/forms/cim/Trust_Account.pdf',
  cim_playback_072014: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/CIM_Playback.pdf',
	acc_tips:'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/BankerAccnt_tips_EU_US.pdf',
	acc_tips_ccifl:'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-marketing_materials/AccountOpeningTips_CCIFL.pdf',
	trust_structure:'https://www.privatebank.citigroup.net/marketing/noam/cpb_exchange/docs/CoveredFundQuestionnaireTrustStructures.pdf',
	non_trust_structure:'https://www.privatebank.citigroup.net/marketing/noam/cpb_exchange/docs/CoveredFundQuestionnaireNonTrustEntityStructures.pdf',
	goblal_volcker:'https://www.privatebank.citigroup.net/marketing/noam/cpb_exchange/docs/CPBGlobalVolckerRule.pdf',
	cim_product_guide: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-communications/TPGProductGuide.pdf',
	cim_admin_form_old: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/cim_admin_form_old.pdf'
};


var umbrella = {
	umbrella_product_specific: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/umbrella/UMBProdSpecInfo.pdf',
	umbrella_terms_and_conditions: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/Umbrella_TC.pdf',
	letter_of_acknowledgement_cgmi: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/umbrella/umbrellaTransitionLetter.pdf',
	cgmi_general_account_information: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/umbrella/CGMI_GeneralAccountInfo.pdf',
	umbrella_playback: '/noam/onboarding/common-media/docs/brokerage/Umbrella_Playback.pdf',
	macs_acceptance_letter: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/MACS_acceptance_Letter.pdf',
	terms_conditions:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/macsUSTeC.pdf',
	citi_trust_app:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/macsAccountAppNonCRA_US.pdf',
	citi_trust_settlement:'/noam/onboarding/common-media/docs/umbrella/citi_trust_settlement.pdf',
	citi_trust_memo:'/noam/onboarding/common-media/docs/umbrella/New_Sub_Account_Review_Memo.pdf',
	citi_trust_questionnaire:'https://www.privatebank.citigroup.net/trust/documents/forms/MA_Questionnaire.pdf',
	c92_ao_guide_macs:'/noam/onboarding/common-media/docs/umbrella/c92_acct_opening_reference_guide_macs.pdf',
	admin_section_internal: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/AdminForm_Asia_EMEA.pdf',
	app_one:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/appendix1.pdf',
	advisory_portfolio_playback:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/advisory_portfolio_playback.pdf',
	ap_lfg_fee: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/ap_lfg_fee.pdf'
};


var dap = {
  dap_product_specific: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/DAPUSApplicationv2.pdf',
	dap_client_loa_template: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/Client_LOA_Template.doc',
	dap_playback: 'https://www.privatebank.citigroup.net/noam/cra/docs/playback/select_uma.pdf',
	dap_terms_and_conditions: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/TandC.pdf',
	dap_playback_072014: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/DAP_UMA_Playback.pdf'
};


var preferred_custody = {
  transfer_authorization_form: 'https://www.privatebank.citigroup.net/custody/common-forms/ACATSTransferForm.pdf',
  ira_plan_disclosures: 'https://www.privatebank.citigroup.net/custody/common-forms/TradIRAPlan.pdf',
  ira_roth_disclosures: 'https://www.privatebank.citigroup.net/custody/common-forms/RothIRAPlan.pdf' ,
  ira_sep_disclosures: 'https://www.privatebank.citigroup.net/custody/common-forms/SEPIRAPlan.pdf',
	account_application: 'https://www.privatebank.citigroup.net/custody/common-forms/1066_pcs_combined-forms.pdf',
  signature_card: 'https://www.privatebank.citigroup.net/custody/common-forms/cust_sig_card.pdf',
	appointment_of_investment_advisor: 'https://www.privatebank.citigroup.net/custody/common-forms/1066_pcs_apoint_invest_advisor.pdf',
	pc_cfta: 'https://www.privatebank.citigroup.net/custody/common-forms/1066_pcs_CFTA.pdf',
	playback: 'https://www.privatebank.citigroup.net/noam/cra/docs/playback/preferred.pdf',
	playback_future_opening: 'https://www.privatebank.citigroup.net/noam/cra/docs/playback/preferred_future.pdf',
	relationship_fee_schedule: 'https://www.privatebank.citigroup.net/custody/common-forms/1066_pcs_scheduleOfFees.pdf',
	schedule_remittance_authorization_form: 'https://www.privatebank.citigroup.net/custody/common-forms/1066_pcs_sch_remit.pdf',
  resolution: 'http://portal.privatebank.citigroup.net/gwm/citigroup_private_bank/products/investments/common-forms/cpb_org_agreement.pdf',
  acats: 'https://www.privatebank.citigroup.net/custody/common-forms/ACATSclientFundsTransfer.pdf',
  third_party_designation: 'https://www.privatebank.citigroup.net/custody/common-forms/1066_pcs_third_party.pdf',
  erisa_408b2: 'https://www.privatebank.citigroup.net/custody/common-forms/cpbCustody408b2Disclosure.pdf',
  ira_transfer_direct_rollover: 'https://www.privatebank.citigroup.net/custody/common-forms/iraTransferDirectRolloverForm.pdf',
  schedule_fees: 'https://www.privatebank.citigroup.net/custody/common-forms/scheduleOfFees.pdf',
  msp_custody_rider: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/MSP_Rider.pdf',
  fs_custody_rider: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/FS_Rider.pdf',
  cim_custody_rider: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/tpg_pc_rider_final.pdf',
  ces_custody_rider: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/CES_Rider.pdf',
  roth_ira_conversion_req: 'https://www.privatebank.citigroup.net/custody/common-forms/Roth_IRA_Conv_Requirements.doc',
  privacy_notice: 'https://www.privatebank.citigroup.net/custody/common-forms/PrivacyNotice.pdf',           
  non_escrow_agent_agreement: '/noam/onboarding/common-media/docs/banking/Non_MandA_Escrow_Agent_Agreement.doc',
  tax_attestation: 'www.google.com'
};


var ces = {
	ces_application_dual_contract: 'https://www.privatebank.citigroup.net/investments/managed/CES_fields.pdf',
	ces_terms_and_conditions: 'http://portal.privatebank.citigroup.net/gwm/citigroup_private_bank/products/investments/consulting_and_evaluation_services/common-forms/0574_CES_tc_us.pdf',
	ces_third_party_custody_form: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/0574_CES_tc_us.pdf',
	cms_new_account_ces: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/CPB_CES_CMS_Package_RE.pdf'
};


var misc = {
  cao_request_form: 'https://www.privatebank.citigroup.net/noam/cao_portal/docs/request_form.pdf',
  cao_request_form_citi_trust:'/noam/kc/forms/docs/cao_request_form.pdf',
	brm: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/business_risk_memo_us.pdf',
	brm_policy: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/business_risk_memo_policy_us.pdf',
	how_to_obtain_duplicate_1099: 'https://www.privatebank.citigroup.net/noam/kc/us_products/docs/tax/how_to_obtain_duplicate_1099.pdf',
	if_sponsorship_memo: 'https://www.privatebank.citigroup.net/noam/cao_portal/docs/sponsorship_form.doc',
	pfs_hnw: 'https://www.privatebank.citigroup.net/investmentFinance/docs/margin_finance/CitiPFSForm.pdf',
	pfs_lfg: 'https://www.privatebank.citigroup.net/LawFirmGroup/docs/PFS.pdf',
	prospect_registration_form: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/prospect_referral_form.doc',
	web_enrollment_playback: 'https://www.privatebank.citigroup.net/noam/cra/docs/playback/web.pdf',
	money_manager_sample_letter: 'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/KYC_Money_Manager_Sample_Letter.pdf',
	municipal_checklist: '/noam/onboarding/common-media/docs/kyc/municipal_checklist.docx',
	referring_citi_affiliate_attestation: '/noam/onboarding/common-media/docs/kyc/Referring_Citi_Affiliate_Attestation.doc',	
	e1_exception_approval_form:'/noam/onboarding/common-media/docs/kyc/E1_Exception_Approval_Form.doc',
  kyc_appendix: '/noam/onboarding/common-media/docs/kyc/KYC_Appendix_AZ.pdf',
  title_extension_policy: 'https://www.privatebank.citigroup.net/noam/kc/forms/docs/title_extension_policy.pdf',
  muni_checklist:'https://www.privatebank.citigroup.net/noam/onboarding/common-media/docs/kyc/municipal_checklist.pdf'    
};


var cao_portal = {
  hnw_ind_crf0: 'hnw/HNW_Individual_CRF.htm',
  tax_training_2013: '/noam/kc/us_service/docs/tax_training.pdf',
  tax_comm: '/noam/onboarding/common-media/docs/banking/tax_comm_for_cpb.doc',
  tax_procedures_manual: 'https://www.privatebank.citigroup.net/noam/kc/us_service/p-t_files/tax_procedures.html'
};

var banking = {
	custom_credit_line_application_approval: 'https://www.privatebank.citigroup.net/banking/docs/CCLAppApprovalProcess.pdf',
	rc_transmittal: 'https://www.privatebank.citigroup.net/banking/citifolio/RC_transmittal.pdf',
	credit_request: 'https://www.privatebank.citigroup.net/LawFirmGroup/docs/lawyersCreditRequest.pdf',
	experian_request: 'https://www.privatebank.citigroup.net/banking/docs/ExperianRequests.pdf',
	credit_scoring_grid: 'https://www.privatebank.citigroup.net/banking/docs/CreditScoringGrid.xls',
	credit_grid_instructions: 'https://www.privatebank.citigroup.net/banking/docs/GridInstructions.pdf',
	checking_plus_addendum: 'https://www.privatebank.citigroup.net/banking/citifolio/checkingPlusAddendumFinal.pdf',
	checking_plus_application: 'https://www.privatebank.citigroup.net/banking/docs/CheckingPlusStandAloneApp.pdf',
	checking_plus_move_package: 'https://www.privatebank.citigroup.net/banking/docs/CheckingPlus_Move_Package.pdf',
	cfpb_regulation: 'http://sokmd38cob1.nam.nsroot.net/srvs/apps/commtool/preview.asp?type=Communication&id=12109',
	domestic_transmittal: '/noam/onboarding/common-media/docs/banking/domesticTransmittalPrestige.pdf',
	global_transmittal: '/noam/onboarding/common-media/docs/banking/Global_Transmittal.pdf',
	citi_ty_college_students: '/banking/docs/CitiThankYou-CollegeStudents.doc',
	secured_card: '/banking/docs/securedCardInstructions.pdf',
	ability_to_pay: 'https://www.privatebank.citigroup.net/banking/docs/AbilityTP.pdf',
	nra_faqs: 'https://www.privatebank.citigroup.net/banking/docs/faq_nra_doc.pdf',
	processing_time: 'https://www.privatebank.citigroup.net/banking/docs/Processing.pdf',
	promotional_offers: 'https://www.privatebank.citigroup.net/banking/docs/Bonus_offers.pdf',
	//<--Removed decline_credit_card_app: 'https://www.privatebank.citigroup.net/banking/Credit_Card_Application_Decline.htm',
	//<--Removed nra_requests: 'https://www.privatebank.citigroup.net/banking/docs/NRARequests.doc',
	card_act: 'https://www.privatebank.citigroup.net/banking/docs/CardAct.pdf',
	beneficiary_designation: '/noam/onboarding/common-media/docs/banking/beneficiary_designation_form.doc',
	whats_new: '/noam/onboarding/whatsnew.htm',
	cra_playback: '/noam/onboarding/common-media/docs/banking/cra_playback.pdf',
	citifolio_playback: '/noam/onboarding/common-media/docs/banking/citifolio_playback.pdf',
	exchange_playback: '/noam/onboarding/common-media/docs/banking/cpb_exchange_banking_playback_v3.doc',
	playback_package: '/noam/onboarding/common-media/docs/banking/playback_package.pdf',
	joint_addendum:'/noam/onboarding/common-media/docs/banking/joint_addendum.pdf',
	rate_exception:'https://www.privatebank.citigroup.net/banking/docs/RateExceptionTemplate.xlsx',
	banking_intranet:'https://www.privatebank.citigroup.net/banking/rateExceptions.htm',
	cssgs: 'https://www.privatebank.citigroup.net/banking/CSSCGS.pdf',
	csscd:'https://www.privatebank.citigroup.net/banking/CSSCD.pdf',
	mmmf: '/noam/onboarding/common-media/docs/banking/mmmf_amend.pdf'
	
};

var mortgage = {
  mortgage_1003_application: '/noam/onboarding/common-media/docs/mortgage/1003_Writable.pdf',
  mortgage_checklist: '/noam/onboarding/common-media/docs/mortgage/Mortgage_Checklist.pdf',
  archesaranda_desiree: '/noam/onboarding/common-media/docs/mortgage/ArchesAranda_Desiree_1003.pdf',
  boudwin_paul: '/noam/onboarding/common-media/docs/mortgage/Boudwin_Paul_1003.pdf',
  baum_douglas:'/noam/onboarding/common-media/docs/mortgage/Baum_Douglas_1003.pdf',
  carrel_harry: '/noam/onboarding/common-media/docs/mortgage/Carrel_Harry_1003.pdf',
  chan_choylin: '/noam/onboarding/common-media/docs/mortgage/Chan_Choylin_1003.pdf',
  finn_william: '/noam/onboarding/common-media/docs/mortgage/Finn_William_1003.pdf',
  leeeubanks_susan: '/noam/onboarding/common-media/docs/mortgage/LeeEubanks_Susan_1003.pdf',
  menapace_fred: '/noam/onboarding/common-media/docs/mortgage/Menapace_Fred_1003.pdf',
  pappas_christopher: '/noam/onboarding/common-media/docs/mortgage/Pappas_Christopher_1003.pdf',
  rueda_german: '/noam/onboarding/common-media/docs/mortgage/Rueda_German_1003.pdf',
  slavik_deedee: '/noam/onboarding/common-media/docs/mortgage/Slavik_Deedee_1003.pdf',
  tuzo_nadeen: '/noam/onboarding/common-media/docs/mortgage/Tuzo_Nadeen_1003.pdf',
  weintraub_sol: '/noam/onboarding/common-media/docs/mortgage/Weintraub_Sol_1003.pdf',
  wills_todd: '/noam/onboarding/common-media/docs/mortgage/Wills_Todd_1003.pdf',
  gallagher_colleen: '/noam/onboarding/common-media/docs/mortgage/gallagher_colleen_1003.pdf',
  milender_steven: '/noam/onboarding/common-media/docs/mortgage/milender_steven_1003.pdf',
  ochoa_joshua: '/noam/onboarding/common-media/docs/mortgage/ochoa_joshua_1003.pdf',
  sardjev_stoyan: '/noam/onboarding/common-media/docs/mortgage/Sardjev_Stoyan_1003.pdf',
  wallace_rosanne: '/noam/onboarding/common-media/docs/mortgage/Wallace_Rosanne_1003.pdf',
  rodriguez_rosario: '/noam/onboarding/common-media/docs/mortgage/Rodriguez_Rosario_1003.pdf',
  boline_stuart: '/noam/onboarding/common-media/docs/mortgage/Boline_Stuart_1003.pdf',
  hildebrandt_michael: '/noam/onboarding/common-media/docs/mortgage/hildebrandt_michael_1003.pdf',
  milchman_paul:'/noam/onboarding/common-media/docs/mortgage/Milchman_Paul_1003.pdf',
  mlo_faq: '/noam/onboarding/common-media/docs/real_estate/mlo_faqs.pdf',
  mlo_training:'/noam/onboarding/common-media/docs/real_estate/mlo_training.pdf',
  barycza_adam:'/noam/onboarding/common-media/docs/mortgage/barycza_adam_1003.pdf',
  heldman_denise:'/noam/onboarding/common-media/docs/mortgage/heldman_denise_1003.pdf',
  tim_mammadov:'/noam/onboarding/common-media/docs/mortgage/tim_mammadov_1003.pdf',
  eric_schuller: '/noam/onboarding/common-media/docs/mortgage/Schuller_Eric_1003.pdf'
  
};

var canada = {
  account_opening_app: '/noam/onboarding/common-media/docs/canada/Canada_Account_Opening_Application.pdf',
  sig_card: '/noam/onboarding/common-media/docs/canada/Canada_Signature_Card.pdf',
  tc: '/noam/onboarding/common-media/docs/canada/Canada_T_C.pdf',
  acknowledgement_form: '/noam/onboarding/common-media/docs/canada/Canada_Customer_Use_Acknowledgement.pdf',
  communication_consent: '/noam/onboarding/common-media/docs/canada/Canada_Unencrypted_Elec_Comm_Consent.pdf',
  verification: '/noam/onboarding/common-media/docs/canada/Canada_Customer_ID_Verification.pdf',
  invest_funds: '/noam/onboarding/common-media/docs/canada/Canada_Invest_Funds_Limited_App.pdf',
  ccifl_tc: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/MSP_CCIFL_TnC.pdf',
  ccifl_admin: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/MSP_CCIFL_AdminForm.pdf',
  ccifl_application: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/MSP_CCIFLApp.pdf',
  ccifl_discretionary_manager_app: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/DiscretionaryManagerApp_CCIFL_RE.pdf',
  banking_business_risk_memo: '/noam/onboarding/common-media/docs/canada/banking_business_risk_memo.pdf',
  banking_account_opening_checklist: '/noam/onboarding/common-media/docs/canada/banking_account_opening_checklist.doc',
  banking_account_opening_change_form: '/noam/onboarding/common-media/docs/canada/canada_account_opening_change.xls',
  banking_us_mailing_address: '/noam/onboarding/common-media/docs/canada/banking_explanation_of_us_mailing_address.doc',
  banking_fee_schedule: '/noam/onboarding/common-media/docs/canada/canada_fee_schedule.xls',
  banking_citi_affiliate_attestation: '/noam/onboarding/common-media/docs/canada/canada_referring_citi_affiliate_attestation.pdf',
  ben_own_auth_rep: '/noam/onboarding/common-media/docs/canada/Beneficial_Owner_D1_1.pdf',
  ben_own_owner: '/noam/onboarding/common-media/docs/canada/Beneficial_Owner_D1_2.pdf',
  ben_own_inc_entity: '/noam/onboarding/common-media/docs/canada/Beneficial_Owner_D2.pdf',
  ben_own_uninc_entity: '/noam/onboarding/common-media/docs/canada/Beneficial_Owner_D3.pdf',
  ben_own_trustee: '/noam/onboarding/common-media/docs/canada/Beneficial_Owner_Trustee_Declaration.pdf',
  ben_sh_response: '/noam/onboarding/common-media/docs/canada/beneficial_shareholder_client_response.doc',
  ben_sh_instructions: '/noam/onboarding/common-media/docs/canada/beneficial_shareholder_instructions.doc',
  ccifl_cim_app: '/noam/onboarding/common-media/docs/canada/ccifl_acct_app_agreement.pdf',
  ccifl_cim_core_app: '/noam/onboarding/common-media/docs/canada/ccifl_core_cim_app.pdf',
  ccifl_admin_section: '/noam/onboarding/common-media/docs/canada/Canada_CIM_CCIFL_Admin_Form.pdf',
  ccifl_admin_section_Old: '/noam/onboarding/common-media/docs/canada/CIM_CCIFL_Admin_Form_OLD_VERSION.pdf',
  ccifl_intl_acct_opening_checklist_msp: '/noam/onboarding/common-media/docs/canada/Canada_International_Account_Opening_Checklist.pdf',
  fiduciary_ao_memo: '/noam/onboarding/common-media/docs/canada/CPB_Fiduciary_AO_Memorandum.pdf',
  exhibit_I: '/noam/onboarding/common-media/docs/canada/Exhibit_I.doc',
  investment_account_activation: '/noam/onboarding/common-media/docs/canada/Investment_Account_Activation.pdf',
  inc_entity:'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/Dec_Ben_Own_by_Inc_Entity.pdf',
  ben_owner:'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/Dec_Ben_Own_by_Ben_Owner.pdf',
  partnership:'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/Dec_Ben_Own_Partner_Other_Uninc_Entities.pdf',
  auth_rep:'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/Dec_Ben_own_Auth_Rep.pdf',
  trustee_dec:'https://collaboration.cmb.citigroup.net/sites/coopm/onboarding_site/documents/Trustee_Declaration_RE.pdf',
  ccifl_core_app:'/noam/onboarding/common-media/docs/canada/Core_Application_CCIFL.pdf',
  CCIFL_MACS_TC: '/noam/onboarding/common-media/docs/canada/Canada_CCIFL_MACS_TC.pdf',
  CCIFL_MACS_App: '/noam/onboarding/common-media/docs/canada/Canada_CCIFL_MACS_App.pdf',
  managed_acc_fin_instructions: 'https://www.privatebank.citigroup.net/investments/managed/Transactions_noWINS.pdf',
  managed_acc_maint_form: "https://www.privatebank.citigroup.net/investments/managed/0256_SSR.pdf",
  citibank_delivery_instructions: "https://www.privatebank.citigroup.net/investments/managed/0256_SEIdelivery-instr.pdf",
  macs_exceptions_grid: "https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/MAC_Exceptions_Grid.pdf",
  AAM_Form_Individuals: "https://www.privatebank.citigroup.net/banking/forms/docs/AcctActivityForm_Ind.doc",
  ca_tax_attestation: '/noam/onboarding/common-media/docs/canada/Tax_Disclosure_Terms_and_Attestation.pdf',
  banker_ca_tax_attestation: '/noam/onboarding/common-media/docs/canada/Banker_Tax_Onboarding_Attestation_Form.pdf'
  
};

var hf = {
	discretionary_app: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/CTA_DiscretionaryApp.pdf',
	discretionary_tc: '/investments/alternative_investments/docs/CTA_DiscretionaryTC.pdf',
	discretionary_adv_part2: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/cai_llc_adv_form_part_2.pdf',
	discretionary_admin: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CTA_GlobalAdminForm.pdf',
	nondiscretionary_app: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/CTA_NonDiscretionaryApp.pdf',
	nondiscretionary_tc: '/investments/alternative_investments/docs/CTA_NonDiscretionaryTC.pdf',
	nondiscretionary_adv_part2: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/cai_llc_adv_form_part_2.pdf',
	nondiscretionary_admin: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CTA_GlobalAdminForm.pdf',
	portfolio_deck: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CTA_GlobalAdminForm.pdf',
	fee_schedule: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CustomHFPortfolios_FeeSchedule.pdf',
	glance: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/HedgeFundPlatformAtaGlance.pdf',
	manager_glance: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/HedgeFundPlatformAtaGlance.pdf',
	review: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/Hedge_Fund_Review.pdf'
};

var kyc = {
	corp_trustee_approv: '/noam/onboarding/common-media/docs/kyc/Third_Party_Procedures.pdf'
};