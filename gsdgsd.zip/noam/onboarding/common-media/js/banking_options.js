// JavaScript Document
function Individual_AO_Banking(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
	  
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
	    document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	    document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	    document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      

      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
	    document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
	    document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	    document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
			
		
	} 
}

function Individual_Custodial(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}

function Individual_Joint_Minor_Banking(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';   
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Joint_Minor_Indemnity').style.display = 'none';
      document.getElementById('I_Joint_Minor_BRM').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
      
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Joint_Minor_Indemnity').style.display = 'none';
      document.getElementById('I_Joint_Minor_BRM').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}

function Trust_AO_Banking(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}

function Estate_AO_Banking(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}