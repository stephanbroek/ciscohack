// JavaScript Document

var orgination = {
	
	 //AIRCRAFT
	aircraft_discussion: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Origination/Aircraft%20Discussion%20Sheet.docx' ,
	aircraft_specification_sheet: 		'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Origination/CPB-AF%20Aircraft%20Specifcation%20Sheet.docx',
	aircraft_CPPAC_Memo: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Origination/AF%20CPPAC%20Memo%20v1.2%2012-16-13.docx',
	aircraft_completed_app_checklist:'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Origination/Aircraft%20-%20Application%20Checklist.pdf',
	aircraft_repeat_credit_application:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Multiple%20Programs/NAM%20Tailored%20Credit%20Repeat%20Credit%20Application%20-%20Jan%202016.pdf',
	
	//ART 
	art_discussion: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Discussion%20Sheets/Art-Loan%20Discussion%20Sheet.docx',
	art_loan_completed_app_checklist:'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Credit%20Application%20Requirement%20Checklists/Art%20Loan%20Completed%20Application%20Checklist.pdf',
	
	//CRE
	cre_personal_finance_statement: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/Personal%20Financial%20Statement%20Form.pdf',
	cre_discussion: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/CRE-Loan%20Discussion%20Sheet%20(1).docx',
	cre_rac_exception_grid_hotels: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/CRE%20RAC%20Exception%20Grid%20Hotels%202011.pdf',
	cre_rac_exception_grid_us_latam: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/CRE%20RAC%20Exception%20Grid%20US-LAM%202011.pdf',
	cre_rac_uhnw: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/CRE%20RAC%20Ultra%20HNW%202011.pdf',
	cre_rac_us: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/CRE%20RAC%20Exception%20Grid%20Hotels%202011.pdf',
	cmbs_red_yellow_green: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/CMBS%20Red%20Yellow%20Green%20Update%20Third%20Quarter%202015%20Assessment%20of%20US%20Proper.pdf',
	cre_repeat_credit_application: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Multiple%20Programs/NAM%20Tailored%20Credit%20Repeat%20Credit%20Application%20-%20Jan%202016.pdf',
	pbs: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/PBS_1015804.xlsx?Web=1',
	cre_appraisal: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/Appendix%202%20-%20US%20CRE%20Appraisal%20Process.pdf',
	//Insurance
	insurance_discussion: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Discussion%20Sheets/Insurance-Loan%20Discussion.docx',
	insurance_completed_app_checklist: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Credit%20Application%20Requirement%20Checklists/Insurance%20Completed%20application%20Checklist.pdf',
	ca_control_checklist:
	'https://icgshare.nam.citi.net/sites/IFP/_layouts/xlviewer.aspx?id=/sites/IFP/Shared%20Documents/NAM/Control%20Checklist/19%20May%2016%20%20LATAM%20Long%20Form%20CA%20Control%20Checklist.xlsx&Source=https%3A%2F%2Fcollaboration%2Ecmb%2Ecitigroup%2Enet%2Fsites%2FIFP%2FSitePages%2FHome%2Easpx%3FRootFolder%3D%252Fsites%252FIFP%252FShared%2520Documents%252FNAM%252FControl%2520Checklist%26FolderCTID%3D0x0120000FCD0C047A3A73468B559C67388885AC%26View%3D%7B62B720E0%2D3C88%2D4B28%2DA8E3%2D92B5A73DEF40%7D%26InitialTabId%3DRibbon%252EDocument%26VisibilityContext%3DWSSTabPersistence&DefaultItemOpen=1&DefaultItemOpen=1',
	cre_term_sheet:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Underwriting/CRE-Loan%20Term%20Sheet%209%20Nov.docx',
	cre_term_sheet_checklist:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Underwriting/CRE%20%20Completed%20Application%20Checklist.pdf',
	ORR_Adjustment:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Underwriting/ORR%20Adjustment.pdf',
	OCA_Request_Form:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Underwriting/OCA%20Request%20for%20Services%2011-14.pdf',
	Portfolio_Request_Form:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Underwriting/Portfolio%20Request%20Form.doc',
	cre_environmental_policy:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/Appendix%203%20-%20US%20CRE%20Environmental%20Policy.pdf',
	cre_remedial_mgmt_policy:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/Appendix%204%20-%20US%20CPB%20Remedial%20Mgmt%20Policy.pdf', 
	cre_regulations:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/Appendix%205%20-%20US%20Reg.%20References.pdf',  
	cre_regulation_requirements: 
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/Appendix%206%20-%20US%20CRE%20Reg.%20Requirements.pdf',
	cre_approved_law_firms:
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/Appendix%207%20-%20Approved%20Law%20Firms.pdf',
	collateral_management_addendum: 
	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Origination/Project%20ATLAS%20-%20Collateral%20Management%20Addendum%20to%20CRE%20PP.pdf', 
	cre_flood_disaster:
	'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/CRE/CRE%20Specific%20Process%20and%20Procedures/Flood%20Disaster%20Procedure%20v16%20FINAL.docx',
	cre_interagency_appraisals_process:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/CRE/CRE%20Specific%20Process%20and%20Procedures/Interagency%20Appraisals%20-%20IF%20Process%20Document%20v11%20-%20FINAL.docx',
	cre_hmda_process:
	'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/3.%20HMDA%20Process%20October%202015%20-%20Final.docx', 
	//MANAGEMENT COMPANY	
	management_company_discussion: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Discussion%20Sheets/Managemnet%20Company%20Loan%20Discussion%20Sheet.docx',
	management_company_completed_app_checklist: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Credit%20Application%20Requirement%20Checklists/Management%20Company%20%20Completed%20Application%20Checklist.pdf',
	
	//MSBF 	//PROGRAM CREDIT
msbf_demand_entity_dis: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/MSBF%20Demand%20Entity%20%20Discussion%20Sheet.docx',
msbf_demand_indv_dis_sheet: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/MSBF%20Demand%20Individual%20Discussion%20Sheet.docx',
msbf_term_entitiy_dis_sheet: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/MSBF%20Term%20Entity%20loan%20Discussion%20Sheet.docx',
msbf_term_indv_dis_sheet: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/MSBF%20Term%20loan%20individual%20Discussion%20Sheet.docx',
msbf_securities_backed_credit_app: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/Securities%20Backed%20Credit%20Application%20May%204%202016.pdf',
msbf_updated_repeated_app: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/Updated%20REPEAT%20MSBF%20Credit%20Application%20March%2014%202016.pdf',
msbf_personal_finance: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/Citi%20PFS%20Form.pdf',
msbf_global_sponsor: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/Global%20Sponsorship%20Form_121815.docx',
msbf_rac: 
'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/MSBF%20RAC.PDF',
msbf_hf_rac: 
'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/Hedge_Fund_RAC%20July%202015.pdf',
msbf_rac_single_issue_ms: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/MSBF%20-%20RAC%20Single%20Issue%20Marketable%20Securities%202008.doc',
msbf_rac_securities: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Origination/MSBF%20-%20RAC%20Securities%20Subject%20to%20Resale%20Limitation%202008.doc',


msbf_appendices_if_risk_org: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%201%20IF%20and%20Risk%20Organization.pdf',
msbf_appendices_rick_rating_method: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%202%20Risk%20Rating%20Methodology.pdf',
msbf_appendices_deliquency: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%203%20Delinquency%20Management%20Portfolio%20Process.pdf',
msbf_appendices_approval_authority_grid_ind_trans: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%204%20MSBF%20Approval%20Authority%20Grid%20for%20Individual%20Transactions.pdf',
msbf_appendices_process_flowchart: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%205%20Process%20Flowchart.pdf',
msbf_appendices_third_party_collateral: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%206%20Third%20Party%20Collateral.pdf',
msbf_appendices_local_product: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%207%20Local%20Product%20Programs%20and%20RACs.pdf',
msbf_appendices_margin_call_deferral: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%208%20Margin%20Call%20Deferral%20Management.pdf',
msbf_appendices_lv_governance: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%209%20LV%20Governance%20Framework.pdf',
msbf_appendices_framework_leding_stock_positions: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%2010%20Framework%20for%20Lending%20Against%20Concentrated%20Stock%20Positions.pdf',
msbf_appendices_account_requirement: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%2011%20Managed%20Account%20Requirement.pdf',
msbf_appendices_gloabl_lending_rules: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Product%20Program%20Appendix/Appendix%2012%20Global%20Rules%20for%20Lending%20to%20Non-Target%20Market%20Entities.pdf',
	
	//UNSECURED
	unsecured_discussion: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Discussion%20Sheets/Unsecured-Loan%20Discussion%20Sheet.docx',
unsecured_completed_app_checklist:'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Credit%20Application%20Requirement%20Checklists/Unsecured%20-%20Completed%20Application%20%20Checklist.pdf',	

	//LAW FIRM
	
	firm_group_credit_app: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Credit%20Applications/Law%20Firm%20Group%20credit%20application.pdf',
law_firm_completed_app_checklist: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Credit%20Application%20Requirement%20Checklists/Law%20Firm-%20Completed%20Application%20Checklist.pdf',

	//LAWYER FIRM
	lawyer_proffesional_credit_app: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Credit%20Applications/Lawyer_%20Professional%20credit%20application.pdf',


	//UNIVERSAL DOCUMENTS
	nam_tailored_credit_repeat_application: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/Credit%20Applications/NAM%20Tailored%20Credit%20Repeat%20Credit%20Application%2023%20November%202015.pdf',
	notice_of_incomplete_app: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Notice_of_Incomplete_Application.docm',
	notice_of_incomplete_app_fraud_alert:'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Notice_of_Incomplete_Application%20with%20fraud%20alert.docm',	
	notice_of_incomplete_app_lawyer_finance:'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Notice_of_Incomplete_Application-Lawyer_Finance_Program_Credit.docm'
	
}


var underwriting = {

//AIRCRAFT

aircraft_risks_and_collateral_guide: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Aviation%20Risks%20and%20Collateral%20Analysis%20Guide%20for%20Underwriting.docx',
AircraftTermSheet_Checklist:
'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Aircraft%20Application%20Checklist.pdf',
RAC_Compliance:'https://icgshare.nam.citi.net/sites/IFP/_layouts/xlviewer.aspx?id=/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/RAC%20Compliance%20Spreadsheet%20v%208.55.xlsm&Source=https%3A%2F%2Fcollaboration%2Ecmb%2Ecitigroup%2Enet%2Fsites%2FIFP%2FSitePages%2FHome%2Easpx%3FRootFolder%3D%252Fsites%252FIFP%252FShared%2520Documents%252FNAM%252FAircraft%252FUnderwriting%26FolderCTID%3D0x0120000FCD0C047A3A73468B559C67388885AC%26View%3D%7B62B720E0%2D3C88%2D4B28%2DA8E3%2D92B5A73DEF40%7D&DefaultItemOpen=1&DefaultItemOpen=1',
schedule_C_inspection_requirements:'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Schedule%20C%20Inspection%20and%20Appraisal%20Requirements.pdf',
aircraft_RAC:
'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/4.2%202016%20-%20AF%20RAC%20v5.3%20Clean%205-10-16.docx',
AF_2013_RAC_Final:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/2013%20AF%20RAC%20Final%20v3.1%20%2010-1-14.docx',
AF_2013_RAC_Grid_section: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/4.1%202016%20-%20AF%20RAC%20Grid%20Section%20I%20v3.1%205-10-16.docx',
CPB_AF_RAC_Product_Program_Changes_Summary:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/CPB-AF%20RAC%20and%20Product%20Program%20-%20Significant%20Changes%20Brief%20Summary.pptx',
schedule_G_registries:'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Schedule%20G%20Acceptable%20Aircraft%20Registries.pdf',
schedule_F_rev:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Schedule%20F%202011.pdf',
aircraft_term_sheet:'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/AircraftTerm%20Sheet.docx',
aircraft_insurance_req:'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/AF%20Insurance%20Requirements%20-%20RAC%20Schedule%20E.docx',
cpb_af_insurance_contacts:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/CPB-AF%20Insurance%20Contacts.docx',
acceptable_aircraft_v2:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Acceptable%20Aircraft.pdf',
q1_2015_teir_make_model_lookup:'https://icgshare.nam.citi.net/sites/IFP/_layouts/xlviewer.aspx?id=/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Q1_2016_Tier%20Make-Model-ValueFactor_Tier%20Lookup.xlsx&Source=https%3A%2F%2Fcollaboration%2Ecmb%2Ecitigroup%2Enet%2Fsites%2FIFP%2FSitePages%2FHome%2Easpx%3FRootFolder%3D%252Fsites%252FIFP%252FShared%2520Documents%252FNAM%252FAircraft%252FUnderwriting%26FolderCTID%3D0x0120000FCD0C047A3A73468B559C67388885AC%26View%3D%7B62B720E0%2D3C88%2D4B28%2DA8E3%2D92B5A73DEF40%7D&DefaultItemOpen=1&DefaultItemOpen=1',
q2_2015_teir_make_model_lookup:'https://collaboration.cmb.citigroup.net/sites/IFP/_layouts/xlviewer.aspx?id=/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Q2_2015_Tier%20Make-Model-ValueFactor_Tier%20Lookup.xlsx&Source=https%3A%2F%2Fcollaboration%2Ecmb%2Ecitigroup%2Enet%2Fsites%2FIFP%2FShared%2520Documents%2FForms%2FAllItems%2Easpx%3FRootFolder%3D%252Fsites%252FIFP%252FShared%2520Documents%252FNAM%252FAircraft%252FUnderwriting%26FolderCTID%3D0x0120000FCD0C047A3A73468B559C67388885AC&DefaultItemOpen=1&DefaultItemOpen=1',
q3_2015_teir_make_model_lookup:'https://collaboration.cmb.citigroup.net/sites/IFP/_layouts/xlviewer.aspx?id=/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Q3_2015_Tier%20Make-Model-ValueFactor_Tier%20Lookup2.xlsx&Source=https%3A%2F%2Fcollaboration%2Ecmb%2Ecitigroup%2Enet%2Fsites%2FIFP%2FShared%2520Documents%2FForms%2FAllItems%2Easpx%3FRootFolder%3D%252Fsites%252FIFP%252FShared%2520Documents%252FNAM%252FAircraft%252FUnderwriting%26FolderCTID%3D0x0120000FCD0C047A3A73468B559C67388885AC&DefaultItemOpen=1&DefaultItemOpen=1',
Approved_Law_Firms: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Law%20Firms_Escrow_Insurance_MgmtCo/AF%20Approved%20Law%20Firms%20v2.2%205-14-14.pdf',
Client_Aviation_LawFirms: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Law%20Firms_Escrow_Insurance_MgmtCo/Client%20Aviation%20Law%20Firms%20v1.1%2011-24-15.docx',
EscrowAgents: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Law%20Firms_Escrow_Insurance_MgmtCo/Escrow%20Agents%20v1.1%2015%20May%2014.pdf',
IF_Insurance_Contacts: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Law%20Firms_Escrow_Insurance_MgmtCo/CPB-AF%20Insurance%20Contacts.docx',
Management_Companies: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Underwriting/Law%20Firms_Escrow_Insurance_MgmtCo/Management%20Companies%20v1.0%20%2015%20May%202014.pdf', 
Aircraftca_control_checklist: 'https://collaboration.cmb.citigroup.net/sites/IFP/_layouts/xlviewer.aspx?id=/sites/IFP/Shared%20Documents/NAM/Control%20Checklist/19%20May%2016%20NAM%20Long%20Form%20CA%20Control%20Checklist.xlsx&Source=https%3A%2F%2Fcollaboration%2Ecmb%2Ecitigroup%2Enet%2Fsites%2FIFP%2FSitePages%2FHome%2Easpx%3FRootFolder%3D%252Fsites%252FIFP%252FShared%2520Documents%252FNAM%252FControl%2520Checklist%26FolderCTID%3D0x0120000FCD0C047A3A73468B559C67388885AC%26View%3D%7B62B720E0%2D3C88%2D4B28%2DA8E3%2D92B5A73DEF40%7D&DefaultItemOpen=1&DefaultItemOpen=1', 
approval_letter: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Approval_Letter_All%20other_programs%20Feb%202016.docm',

counterOffer:
'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Counteroffer_Letter_with_both%20credit_report%20disclosures.docm',

incomplete_application: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Notice_of_Incomplete_Application.docm',

incomplete_application_fraud: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Notice_of_Incomplete_Application%20with%20fraud%20alert.docm',

adverse_action_letter: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Adverse_action_letter_with_both_credit_report_disclosure.docm',


//CRE

cre_new_business_request_form: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/CRE/Underwriting/New%20Business%20Request%20Form.doc',
oca_request_services: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/CRE/Underwriting/OCA%20Request%20for%20Services%2011-14.pdf',
portfolio_request_form: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/CRE/Underwriting/Portfolio%20Request%20Form.doc',

//PECC
pecc_borrowing_base_process: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/PECC%20-%20Sponsorship/Underwriting/PECC%20Borrowing%20Base%20Process%202015-06-30%20v1%205.docx',
pecc_risk_rating: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/PECC%20-%20Sponsorship/Underwriting/PECC%20risk%20rating%20Clarification%20of%201%20notch%20upgrade%20for%20a%20+3%20score.pdf',
pecc_rr_scorecard: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/PECC%20-%20Sponsorship/Underwriting/PECC%20RR%20Scorecard_September%202012.xls',
pesf_global_bb_template: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/PECC%20-%20Sponsorship/Underwriting/PESF%20Global%20BB%20Template%20v3.5.xltx',

//MSBF
	msbf_2014_a1_liquid_pricing: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF%20%20-%202014%20A1%20Liquid%20Pricing%20Grid.pptx',
	msbf_a1_a3_checklist: 'https://icgshare.nam.citi.net/sites/IFP/_layouts/xlviewer.aspx?id=/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF%20A1-Liquid%20CA%20Checklist%20-%20Jan-2013%20NAM%20and%20LATAM%2018%20January%202013.XLSX&Source=https%3A%2F%2Fcollaboration%2Ecmb%2Ecitigroup%2Enet%2Fsites%2FIFP%2FSitePages%2FHome%2Easpx%3FRootFolder%3D%252Fsites%252FIFP%252FShared%2520Documents%252FNAM%252FMSBF%2520and%2520Program%2520Credit%252FUnderwriting%26FolderCTID%3D0x0120000FCD0C047A3A73468B559C67388885AC%26View%3D%7B62B720E0%2D3C88%2D4B28%2DA8E3%2D92B5A73DEF40%7D&DefaultItemOpen=1&DefaultItemOpen=1',
	
	
	msbf_lv_sch: ' https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/LV_Schedule.doc',
	msbf_term_sheet_demand_entity: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF-Demand%20Entity%20Term%20Sheet%2022%20Jan%202016.docx',
	msbf_term_sheet_demand_indv: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF-Demand%20Individual%20Term%20Sheet%2022%20Jan%202016.docx',
	msbf_term_sheet_term_entity: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF-Term%20Entity%20Term%20Sheet%2022%20Jan%202016.docx', 
	msbf_term_sheet_term_indv: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF-Term%20Indidivual%20Term%20Sheet%2022%20Jan%202016.docx',
	
	msbf_non_pro_comp_app_list: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF%20(Non%20Program)%20-%20Completed%20Application%20Template.pdf',
	msbf_prgram_credit_comp_app_list: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF%20Program%20Credit%20%20-%20Completed%20Application%20Template.pdf',
	msbf_ca_control_cl: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Underwriting/MSBF%20A1-Liquid%20CA%20Checklist%20-%20Jan-2013%20NAM%20and%20LATAM%2018%20January%202013.XLSX',
	msbf_ecoa_approval_program_credit: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Approval%20Letter%20%20Latam%20Program%20Credit.docm',
	msbf_ecoa_other_programs: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Approval_Letter_All%20other_programs%20Feb%202016.docm',
	msbf_ecoa_counteroffer_3rdparty: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Counteroffer_Letter%20incld%203rd%20party%20credit%20disclosure%2023%20Nov.docm',
	msbf_ecoa_incomplete_app: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Notice_of_Incomplete_Application.docm',
	msbf_ecoa_adverse_action: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Adverse_action_letter_with_3rd_party_credit_disclosure%2023%20Nov%202015.docm',

//Others
adverse_action_letter_third_party: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Adverse_action_letter_with_3rd_party_credit_disclosure%2023%20Nov%202015.docm',
adverse_action_letter_both_disclousers: '	https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Adverse_action_letter_with_both_credit_report_disclosure.docm',
approval_letter_lawyer_financing: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Approval%20Letter%20%20Lawyer%20Financing.docm',
approval_letter_program_credit: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Approval%20Letter%20%20Program%20Credit.docm',
approval_letter_program_other: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/ECOA%20Letters/Approval_Letter_All%20other_programs%20September%202016.docm',
counteroffer_letter_third_party: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Counteroffer_Letter%20incld%203rd%20party%20credit%20disclosure%2023%20Nov.docm',
conteroffer_letter_both_credit_reports: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Updated%20Std%20Documents%202015/1/ECOA%20Client%20Notification%20Letter%20Templates/Counteroffer_Letter_with_both%20credit_report%20disclosures.docm'
	
}

var process_and_procedures = {
	
ecao_notification_process: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/1.%20ECOA%20-%20Notification%20Process%2010.27.15%20(1).docx',
ecoa_pricing_practices:'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/ECOA%20Pricing%20Practices_FHA%2029%20April%20V4.docx',
hdma_process: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/3.%20HMDA%20Process%20October%202015%20-%20Final.docx',
udaap_procedures: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/UDAAP%20Procedures%20December%2028%202016%20-%20FINAL%20(1).docx',
frca_facta_procedures: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/5.%20FCRA_FACTA%20Procedures%20(1).docx',
governing_if_loan_payment: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/6.%20Procedures%20Governing%20IF%20Loan%20Payment%20Correspondence%20(1).docx',
app_process: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/7.%20Application%20Process%2010.27.15.docx',
spousal_signiture: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/8.%20Spousal%20Signature%2010.27.15%20(1).docx',
	hf_roadmap: 
'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Training/Hedge%20Fund%20Roadmap.pdf',
control_stock_process:
'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/V1.5%20MSBF%20Lending%20on%20Concentrated%20Stock%20Training.pdf',
control_stock_threshold:
'https://icgshare.nam.citi.net/sites/IFP/_layouts/xlviewer.aspx?id=/sites/IFP/Shared%20Documents/NAM/Process%20and%20Procedures%20-%20ALL/IF_MSBF%20Website%20Stock%20Threshold%20Report%208-30-16.xlsx&Source=https%3A%2F%2Fcollaboration%2Ecmb%2Ecit',
aircraft_management:
'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Process%20and%20Procedure/CPB%20Aircraft%20Management%20Company%20Policy%20v0.9%20%207-8-15.docx',
nam_risk_management: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/default.aspx'


	
}

var marketing_materials = {

//AIRCRAFT	
upgrading_aircraft:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/Upgrading%20Your%20Aircraft.ppt',	
aircraft_ownership_deck: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/Aircraft%20Ownership%20Capabilities%20Deck%20Client%20Approved%20June%204%202014.pdf',
aircraft_owenership_sales_tool: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/Aircraft%20Ownership%20Considerations%20Internal%20Sales%20Tool%20June%204%202014.pdf',
aircraft_finance_glance: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/Aircraft_Finance_at_a_Glance_June_2014.pdf',
how_to_sell_aircraft: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/How%20to%20Sell%20Aircraft%20Finance%20Sales%20Bullet%20Points%20v2.1%206-19-15.docx',
	reference_questions_aircraft: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/Quick%20Reference%20Questions%20for%20Aircraft%20Transactions%20v1.1%202-10-14.docx',
	bio_john_basileo: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/John%20Basileo%20-%20Bio.doc',
	bio_john_blackmon: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/John%20Blackmon%20-%20Bio.docx',
	bio_ford_von_weise: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/Ford%20von%20Weise%20-%20Bio.pdf',
	aircraft_market_update_spring_2014: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Marketing%20Materials/AircraftMarketUpdateNewsletterSpring2014.pdf',


//CRE

commercial_real_estate:
'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Marketing%20Materials/Comm_Real_Estate_AAG.pdf',

//MSBF/Program Credit

	third_party_hf: 
'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Training/Lending%203rd%20Party%20HF.ppt',
	lending_against_3rd_party_hf:
'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Marketing%20Materials/Lending%203rdP%20arty%20HF-marketing.ppt',
	margin_securities_backed_glance: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Marketing%20Materials/MSBF%20At%20A%20Glance.pdf',
	liquidity_financial_assets: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Marketing%20Materials/Accessing-liquidity-from-financial-assets.pdf',
	msbf_flyer: 
'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Marketing%20Materials/MSBF_Flyer.pdf',
	margin_securities_backed_ppx: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Training/MSBF%20Level%201%20Training.pptx',
 	msbf_faqs: 
'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Training/MSBF%20FAQs%20v4.pdf',
 	msbf_level_1: 
	'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Training/MSBF%20Level%201%20Training.pptx',
 msbf_product_program_training:
'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Training/PP%20Training%20Make-Up%206_23_2015.pdf',
 msbf_standby_credit: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Training/Stand%20by%20Letter%20of%20Credit.ppt'

}


var annual_reviews = {
	aircraft_annual_rev_checklist: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Annual%20Reviews/AF%20Annual%20Review%20Checklist%20%20v1.2%206-9-14.pdf',
	annual_review_template: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/Aircraft/Annual%20Reviews/Annual%20Review%20Template_v%201%203%208-11-15.docm'
}


var loan_documentation ={
	//MSBF/Program Credit 
	msbf_tp_entity_security: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%203rd%20Party%20Entity%20Security%20Agreement%20with%20Entity%20Borrower%20Grantor%20clean%2003-03-16.doc',
	msbf_entity_discretionary_secured_borrower: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Demand%20Discretionary%20Revolver%20-%20Entity%20Secured-Borrower%20and%203rd%20Pty-clean-3-02-16.docx',
	msbf_entity_discretionary_secured:	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Demand%20Discretionary%20Revolver%20-%20Entity%20Secured-clean-02-22-16.docx',
	msbf_entity_discretionary_secured_tp: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Demand%20Discretionary%20Revolver%20-%20Entity-Secured%20by%20Third%20Party%20Pledgor%20SF-clean-%2002-22-16.docx',
	msbf_trust_discretionary_secured: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Demand%20Discretionary%20Revolver%20-%20Trust-Secured%20by%20Third%20Party%20Pledgor%20-clean-%2002-29-16.docx',
	msbf_trust_discretionary_secured_tp: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Demand%20Discretionary%20Revolver%20-%20Trust-Secured%20by%20Third%20Party%20Pledgor%20-clean-%2002-29-16.docx',
	msbf_entity_multi_discretionary_secured: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Demand%20Discretionary%20Revolver%20Multicurrency%20-%20Entity%20Secured-clean-03-03-16.docx',
	msbf_entity_term_multi_draw_tp:	'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Term-Multi%20Draw%20Committed%20-%20Entity-Secured%20by%20Third%20Party%20Pledgor%20clean-%2003-01-16.docx',
	msbf_entity_term_multi_draw_secured: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Term-Multi%20Draw%20Discretionary%20-%20Entity-Secured%20by%20Third%20Party%20Pledgor%20clean%20-%2003-01-16.docx',
	msbf_entity_term_single_draw: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Term-Single%20Draw%20-%20Entity%20Secured-clean-02-09-2016.docx',
	msbf_entity_term_single_draw_secured_tp: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Entity/FORM%20Term-Single%20Draw%20-%20Entity-Secured%20by%20Third%20Party%20Pledgor%20clean%20-%2003-01-16.docx',
	msbf_indv_demand_secured: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Individual/Individual%20(Single%20or%20Joint)%20DEMAND%20Secured%20NG%20clean%2002-23-16.docx',
	msbf_indv_demand_secured_tp: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Individual/Individual%20(Single%20or%20Joint)%20Demand%20with%20Third%20Party%20Pledgor%20clean%2002.23.16.docx',
	msbf_indv_term_single_unsecured: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Individual/Individual%20(Single%20or%20Joint)%20Term-Single%20Draw%20Committed-Unsecured%20clean%2002.25.16.docx',
	msbf_indv_term_multi_unsecured: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Individual/Individual%20(Single%20or%20Joint)%20Term-Multi%20Draw%20Committed-Unsecured%20clean%2002.25.16.docx',
	msbf_entity_certificate_corp: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Certificates/Certificate%20of%20Corps.doc',
	msbf_entity_certificate_llc: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Certificates/Certificate%20of%20LLC.doc',
	msbf_entity_certificate_LP: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Certificates/Certificate%20of%20LP.docx',
	msbf_entity_certificate_trust: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Certificates/Form%20of%20Trust%20Certificate%2003-01-16.doc',
 pledge_agreement_cash_collat_only: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Pledge%20Agreement/Pledge%20Agreement-Cash%20Collateral%20Only.docx',
	pledge_agreement_cash_collat_only_third_party: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Pledge%20Agreement/Pledge%20Agreement-Cash%20Collateral%20Only-3rd%20Party-clean.docx',
	payoff_agreement_acat: "https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Payoff%20Agreements/Payoff%20Agreement%20ACAT%20Form-Citi%20New%20Lender-11-2014.docx",
	payoff_agreement_exs:	 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Payoff%20Agreements/Payoff%20Agreement%20Form-Citi%20Existing%20Lender-11-2014.docx',
	payoff_agreement_new: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/Payoff%20Agreements/Payoff%20Agreement%20Form-Citi%20New%20Lender-11-2014.docx',
	general_POA: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/01GeneralPowerOfAttorney(CITIBANK).dot',
	notice_cosigner: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/02CoMakerDisclosure(na).dot',
	corporate_general_res:'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/03CorporateGeneralResolution(na).dot',
	corporate_designation_single_person: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/04CorporateDesignation-SinglePersonCorp(na).dot',
	partnership_declar_agreement: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/05Partnership-Declar-And-Agreement(na).dot',
	limited_liability_comp_res: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/06Limited-Liability-Company-Resolution(na).dot',
	stock_and_bond_power: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/07MarketableStockAndBondPower(na).dot',
	assignment_life_insurance: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/08AssignmentOfLifeInsurance.dot',
	assingment_time_deposit: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/MSBF%20and%20Program%20Credit/Loan%20Documentation/09AssignmentOfTimeDeposit.dot'
	
}



var product_programs ={
	aircraft: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/CPBAF/RAC%20%20Product%20Program%20Documents%20%20Global/2013%20Global%20AF%20Product%20Program%20v2.13%202-12-14.docx' ,
	art_finance: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Document%20Library2/Art%20Finance%20Product%20Program%204-1-2015.pdf',
	cre: 'https://icgshare.nam.citi.net/sites/IFP/Shared%20Documents/NAM/CRE/Product%20Program/CRE%20Product%20Program%20Final_v1_Feb%208%202016.pdf',
	unsecured: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Unsecured%20Roland%20Asuan/Unsecured%20Product%20Program%2011-2-2015.pdf',
	management_company: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Letters%20of%20Credit%20Docs/MCCP%20Product%20Program%202013-12-9.pdf',
	msbf: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Letters%20of%20Credit%20Docs/MCCP%20Product%20Program%202013-12-9.pdf',
	pecc: 'https://collaboration.cmb.citigroup.net/sites/IFP/Shared%20Documents/NAM/PECC%20-%20Sponsorship/Product%20Program/PECC%20Product%20Program%202014-09-23.pdf',
	other_secured: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Other%20Secured%20Credit/1/NAM%20Other%20Secured%20Product%20Program.pdf',
	law_firm: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Law%20Firm%20Alan%20Le%20Vine/2014-16%20Law%20Firm%20Financing%20Credit%20Product%20Program.pdf',
	sport_finance: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/Document%20Library11/Sports%20Finance%202014%20Product%20Program.pdf',
	insurance: 'https://collaboration.globalwealthmanagement.citigroup.net/sites/structuredlending/US/MSBF%20%20GIPF%20Steven%20Carr%20%20Dean%20Murdock/CPB%20Global%20Life%20Insurance%20Policy%20Financing%20Product%20Program%208-26-14.pdf'
} 