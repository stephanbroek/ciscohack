function cra_application_link (elementID){
      $(elementID).html('<a target="_blank" style="background-image:url(https://www.privatebank.citigroup.net/common-media/images/icons/pdf.gif);" href="'+cra.application+'">Client Relationship Agreement, Signature Card and Tax Documents</a><span style="font-size: 11px; font-style: italic; padding-left: 20px; color:gray;">(Rev. 04/14 v3)</span>');
}

function cra_application_desc(elementID){
      
      //check for Joint option for Tax ID verbiage
      if(document.getElementById('q_accounte').value=="Individual/Joint"){
        $(elementID).append('<li>Account Title, Ownership Type and Tax ID must be included in the application. For joint accounts, the Tax ID being used must be that of the primary account owner</li>');             
      }  else {
        $(elementID).append('<li>Account Title, Ownership Type and Tax ID must be included in the application</li>');
      }
      
      $(elementID).append('<li>Please ensure the Account Title on the application matches the Signature Card exactly</li>');
      
      $(elementID).append('<li>The mailing address on the application must match the EG address in OneSource</li>');
      
      $(elementID).append('<li>All other fields must be fully completed and signed by account owner(s)</li>');
      
      $(elementID).append('<li><a target="_blank" style="background-image:url(https://www.privatebank.citigroup.net/common-media/images/icons/pdf.gif); font-size: 11px; display:inline;" href="'+cao_portal.tax_training_2013+'">2013 U.S. W9-W8 Requirements Training</a></li>');
      
      $(elementID).append('<li><a target="_blank" style="background-image:url(https://www.privatebank.citigroup.net/common-media/images/global/arrowSingleBlue.gif); font-size: 11px; display:inline;" href="/noam/onboarding/inc/banking/Banking_Order_Latest_CRA.htm">Order Latest CRA/Integrated Account Opening Kit</a></li>');
      
      //$(elementID).append('<li><p><a href="#" style="background-image: url(https://www.privatebank.citigroup.net/common-media/images/global/arrowSingleBlue.gif); display:inline; font-size: 11px; onClick="'+"window.open('/noam/onboarding/inc/banking/Banking_Order_Latest_CRA.htm','Instructions', 'menubar,width=650,height=580'); return false;"+'">Order Latest CRA/Integrated Account Opening Kit</a></p></li>');
      //onClick="window.open('/noam/onboarding/inc/banking/Banking_Order_Latest_CRA.htm','Instructions', 'menubar,width=650,height=580'); return false;" 
}