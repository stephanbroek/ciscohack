function cf_tc_link (elementID){
      $(elementID).html('<a target="_blank" style="background-image:url(https://www.privatebank.citigroup.net/common-media/images/icons/pdf.gif);" href="'+citifolio.terms_and_conditions+'">Citifolio Terms &amp; Conditions</a>');
}

function cf_tc_desc(elementID){
      $(elementID).html('<li>Banking teams must provide a hard copy Terms &amp; Condition to the client at the time of signing the application or prior to account opening.</li>');

}