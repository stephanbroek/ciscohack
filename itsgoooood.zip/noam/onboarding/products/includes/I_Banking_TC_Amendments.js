function banking_tc_amend_link (elementID){
      $(elementID).html('<a target="_blank" style="background-image:url(https://www.privatebank.citigroup.net/common-media/images/icons/pdf.gif); clear: none; display: inline;" href="'+citifolio.compilation_amendments+'">T&amp;C Amendments</a>');
}

function banking_tc_amend_desc(elementID){
      
      $(elementID).html('<li>Terms and conditions are subject to change - at any time - regardless of how recent the new kits are made available. As such, always check to determine if any amendments are required</li>');
      
      $(elementID).append('<li><a target="_blank" style="background-image:url(https://www.privatebank.citigroup.net/common-media/images/icons/pdf.gif); clear: none; display: inline;" href="'+citifolio.compilation_amendments+'">What&#39;s Changed</a></li>');
      
}