var latam_cim = {
	terms_and_conditions:'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/0866_tailored_tc_NY_Intl.pdf',
	discretionary: 'https://www.privatebank.citigroup.net/investments/managed/Latam_Disc_fields.pdf',
	admin_us_form: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/AdminForm_LATAM.pdf',
	tailored_tc: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/TPGLatamTermsConditions.pdf',
	international_managed: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/tpg_latam_app_agree.pdf',
	custom_tdp: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/customportfolios.htm',
	gdp: 'https://www.privatebank.citigroup.net/investments/managed/TailoredGroup_Latam_fields.pdf',
	admin_emea_form: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/TPG-AdminForm.pdf',
	admin_emea_form_old: '/noam/onboarding/common-media/docs/EMEA_Admin_Form_OLD_VERSION.pdf',
	cgmi: 'https://www.privatebank.citibank.com/pdf/cgmi_adv.pdf',
	prospectus: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/citiumbrella_sicav_prospectus.pdf',
	core_app_emea:'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/690999_TPG_EMEA_App.pdf',
	<!--london-->
	sub_app:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/citiumbrella_sicav_subagree.pdf',
	sig_card:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/600_NA_Account_Application_Individuals.pdf',
	questionnaire:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/ClientQstnr.pdf',
	questionnaire_instructions:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/ClientQstnrInstr.pdf',
	open_request:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/newAcctOpeningForm_indiv.pdf',
	aam_faq:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/faqs_for_aam_forms_LondonNA.doc',
	checklist:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/London_Individual_Account_Checklist_Client_Copy.pdf',
	collateral:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/Collateral_Agreement_Ind_NA.pdf',
	elec_consent:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/London_NA_Email_consent.pdf',
	limited_attorney:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/35969.pdf',
	london_power_attorney:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/35088.pdf',
	remittance_instruc:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/CPB_NA_IBAN_settlement.pdf',
	cbc_memorandum:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/cbcMemorandum.pdf',
	bistor_terms:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/BISTOR_NA.pdf',
	bistor_schedule_fee:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/FeeSchedule_BISTOR.pdf',
	rdr_bist:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/RDR_BIST_NA.pdf',
	fee_rdr:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/FeeScheduleRDR.pdf',
	disclosure_booklet:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/Citi_Disclosure_Booklet.pdf',
	fsa_key_facts:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/CPB_keyfacts.pdf',
	order_execution:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/UK_Execution_Policy.pdf',
	ben_author_rep:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/KYC_Appendix_D_1_1.pdf',
	ben_owner:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/KYC_Appendix_D_1_2.pdf',
	ben_fam:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/London-BOD-FamilyFoundation.pdf',
	ben_incorp_entity:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/KYC_Appendix_D_2.pdf',
	ben_partner_entity:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/KYC_Appendix_D_3.pdf',
	ben_trustee:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/KYC_Appendix_D_4.pdf',
	tax_deduction:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/UKTaxDeductionPartnershipDeclaration.pdf',
	compensation_scheme:'https://www.privatebank.citigroup.net/operations/emea/client_services/docs/londonNA/UK-FSCompScheme-NAInteractive.pdf',
	acc_tips:'/noam/onboarding_latam/common-media/docs/cim/emea_portfolios_account_tips_latam.pdf',	
	terms_and_conditions_nyny: 'https://www.privatebank.citigroup.net/noam/onboarding_latam/common-media/docs/cim/terms_and_conditions_nyny.pdf'
};

var cim_optional = {
	managed_account: 'https://www.privatebank.citigroup.net/investments/managed/Transactions_noWINS.pdf',
	account_maintenance:'https://www.privatebank.citigroup.net/investments/managed/0256_SSR.pdf',
	power_attorney: 'https://www.privatebank.citigroup.net/banking/forms/docs/poa-NY.pdf',
	global_check:'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/CIM_GLOBAL_CHECKLIST.docx',	
	gdp_change_form:'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/TPG_Portfolio_Change_Form.pdf',
	close_account: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/common-forms/691862_Closing_Ac.pdf',
	aam_ent: 'https://www.privatebank.citigroup.net/banking/forms/docs/AcctActivityForm_Ent.doc',
	aam_ind:'https://www.privatebank.citigroup.net/banking/forms/docs/AcctActivityForm_Ind.doc',

	third_party:'https://www.privatebank.citigroup.net/investments/managed/cpb_third_party.pdf',
	sec_transfer:'https://www.privatebank.citigroup.net/investments/managed/0256_acttrans.pdf',
	delivery_instructions:'https://www.privatebank.citigroup.net/investments/managed/0256_SEIdelivery-instr.pdf',
	app_requirments:'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/approvalgrid_la.pdf',
	gdp_bundled_trust_fee:'http://www.citigroup.net/privbank/trusts/Documents/Documentations/GDP/GDP.pdf'
};

var latam_msp = {
	terms_and_conditions: 'https://www.privatebank.citigroup.net/noam/kc/pershing/docs/MSP_tc_LATAM.pdf',
	agreement: 'https://www.privatebank.citigroup.net/investments/managed/MSP_Latam_fields.pdf'
};
var msp_optional = {
	rtp_signature:'https://www.privatebank.citigroup.net/noam/kc/latam_procedures_manual/docs/p-t/rtp.PDF',
	rtp_no_signature:'https://www.privatebank.citigroup.net/noam/kc/latam_procedures_manual/docs/p-t/rtp_nosig.PDF'
};

var latam_macs = {
	terms_and_conditions: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/macsUSTeC.pdf',
	cgmi: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/cgmiLatamCIM_Application.pdf',
	agreement: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/macsAccountApp_LATAM.pdf',
	trading_calendar:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/umbr_sicav_cal.pdf',
	pershing_form:'/noam/onboarding_latam/common-media/docs/macs/pershing_broker_dealer_credit_for_mgd_accts.pdf',
	sic_etf_agreement: '/noam/onboarding_latam/common-media/docs/macs/CBNA_MACS_RE.pdf',
	sic_etf_admin: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/AdminForm_Asia_EMEA.pdf',
	sic_etf_tc: '/noam/onboarding_latam/common-media/docs/macs/MacsLatamTeC_CBNA_NY_T_C.pdf'
};

var macs_optional = {
	placement: 'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/MACSPlacemat_LATAM.pdf',
	region_training:'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/MACSTrainingDeck_LATAM.pdf',
	acceptance_letter:'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/MACS_acceptance_Letter.pdf',
	exception_grid:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/MAC_Exceptions_Grid.pdf',
	sicav_nav:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/citiumbrella_sicav_navs.pdf',
	annual_report:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/citiumb_sicav_annualrpt.pdf',
	semi_annual:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/UnauditedSemi-AR.pdf',
	redem_form:'https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/citiumbrella_sicav_redempt-fininstructform.doc',
	rating_report:'https://www.privatebank.citigroup.net/investments/research/ip_riskratings.pdf',
	cip_form:'/noam/onboarding_latam/common-media/docs/macs/fiduciary_acct_opening_memo.pdf',
	appendix_one:"https://www.privatebank.citigroup.net/investments/citi_investment_management/docs/appendix1.pdf"
};

var latam_banking = {
	rdip: 'https://www.privatebank.citigroup.net/banking/forms/docs/cpb-letter.pdf',
	app: 'https://www.privatebank.citigroup.net/banking/forms/docs/Core_application.pdf',
	tc: 'https://www.privatebank.citigroup.net/banking/forms/docs/terms_and_cond.pdf',
	signature_card: 'https://www.privatebank.citigroup.net/banking/forms/docs/application_card.pdf',
	act: 'https://www.privatebank.citigroup.net/banking/forms/docs/open_new_account.pdf',
	tax: 'https://www.privatebank.citigroup.net/noam/kc/us_service/p-t_files/tax_procedures.html',
	engconsent: 'https://www.privatebank.citigroup.net/banking/forms/docs/translations-English.pdf',
	spanconsent: 'https://www.privatebank.citigroup.net/banking/forms/docs/translations-Spanish.pdf',
	porconsent: 'https://www.privatebank.citigroup.net/banking/forms/docs/translations-Portuguese.pdf',
	sec_agree:'https://www.privatebank.citigroup.net/banking/forms/docs/security_agreement.pdf',
	reg_u: 'https://www.privatebank.citigroup.net/banking/forms/docs/statement.pdf',
	ben_own:'https://www.privatebank.citigroup.net/banking/forms/docs/beneficial_ownership.pdf',
	priv_not: 'https://www.privatebank.citigroup.net/banking/forms/docs/privacy_notice.pdf',
	schedule_fee: 'https://www.privatebank.citigroup.net/banking/forms/docs/banking_serv_fees.pdf',
	invest_account: 'https://www.privatebank.citigroup.net/banking/forms/docs/inv_fees.pdf',
	available_funds: 'https://www.privatebank.citigroup.net/banking/forms/docs/funds_availability-ny.pdf',
	aust_red:'https://www.privatebank.citigroup.net/banking/forms/docs/note_australian_resident_clients.pdf',
	activation:'https://www.privatebank.citigroup.net/banking/forms/docs/accountActivation.pdf',
	renmimbi_disclosure:'https://www.privatebank.citigroup.net/banking/docs/renmimbi_disclosure.pdf',
	edelivery: 'https://www.privatebank.citigroup.net/noam/kc/latam_products/docs/df-e-delivery-enrollment-form-09232013.pdf',
	transfer_amend:'https://www.privatebank.citigroup.net/banking/forms/docs/TCchanges_LATAM.pdf',
	w9instructions:'http://www.irs.gov/pub/irs-pdf/iw9.pdf',
	w8instructions:'http://www.irs.gov/pub/irs-pdf/iw8ben.pdf',
	neg_rates:'/noam/onboarding_latam/common-media/docs/banking/negative_rates_amendment.pdf',
	tax_attestation: '/noam/onboarding/common-media/docs/banking/tax_attestation_client.pdf'
	
}

var banking_optional = {
	memo: 'https://www.privatebank.citigroup.net/banking/forms/docs/memo.pdf',
	bill_instructions: 'https://www.privatebank.citigroup.net/banking/forms/docs/Bill_Paying.pdf',
	third_party_access:'https://www.privatebank.citigroup.net/banking/forms/docs/ApptThirdParty.pdf',
	email_consent: 'https://www.privatebank.citigroup.net/banking/forms/docs/consent_form.pdf',
	risk_memo: '/noam/onboarding_latam/common-media/docs/banking/business_risk_memo.pdf',
	risk_memon_policy: '/noam/onboarding_latam/common-media/docs/banking/business_risk_memo_policy.pdf',
	atm_card: '/noam/onboarding_latam/common-media/docs/banking/atm_ao_form.pdf'
}

var latam_aam = {
	guidelines: '/noam/onboarding_latam/common-media/docs/banking/aam_form_guidelines_latam.doc',
	training: '/noam/onboarding_latam/common-media/docs/banking/aam_form_training_latam.pptx',
	aam_additional:'/noam/onboarding_latam/common-media/docs/banking/aam_forms_additional_account_requirements_latam.msg'
}

/*var latam_brokerage = {
	form5521C:'/noam/onboarding_latam/common-media/docs/brokerage/5521C.pdf',
	form5556:'/noam/onboarding_latam/common-media/docs/brokerage/5556.pdf',
	form5966:'/noam/onboarding_latam/common-media/docs/brokerage/5966.pdf',
	form2313:'/noam/onboarding_latam/common-media/docs/brokerage/2313.pdf',
	form2314:'/noam/onboarding_latam/common-media/docs/brokerage/2314.pdf',
	form9240:'/noam/onboarding_latam/common-media/docs/brokerage/9240.pdf',
	wolf_question:'/noam/onboarding_latam/common-media/docs/brokerage/wolf_question.pdf',
	sic_waiver:'/noam/onboarding_latam/common-media/docs/brokerage/sic_waiver.pdf',
	form67131:'/noam/onboarding_latam/common-media/docs/brokerage/67131.pdf'
}*/

var latam_ces = {
	terms_conditions: 'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/0574_CES_tc_LATAM.pdf',
	agreement:'https://www.privatebank.citigroup.net/investments/traditional_investments/docs/0574_CES_App_LATAM.pdf'
}

var latam_hf = {
	terms_conditions_des:'/investments/alternative_investments/docs/CTA_DiscretionaryTC.pdf',
	descretionary:'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CTADiscretionaryApp_LatAm.pdf',
	admin: 'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CTA_GlobalAdminForm.pdf',
	nondescretionary:'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CTA_NonDiscretionaryApp_LatAm.pdf',
	tc_nondescretionary:'/investments/alternative_investments/docs/CTA_NonDiscretionaryTC.pdf',
	approval_requirements:'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CustomHFPortfolios_ApprovalRequirements.pdf'
}
var hf_optional = {
	faq:'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/ProcessGuideAmericas.pdf',
	contact_list:'https://www.privatebank.citigroup.net/investments/alternative_investments/docs/CTAContactList.pdf'
}

var email = {
	marianela_garavi:'mailto:marianela.e.garavi@citi.com',
	maria_espaillat:'mailto:maria.espaillat@citi.com',
	emma_ochoa_olmos:'mailto:emma.ochoa@citi.com',
	ana_pugina:'mailto:ana.pugina@citi.com',
	carmella_dirienzo:'mailto:carmella.dirienzo@citi.com',
	marlene_gonzalez:'mailto:marlene.gonzalez@citi.com',
	juan_jimenez:'mailto:juan.jimenez@citi.com',
	patricia_perry:'mailto:patricia.perry@citi.com',
	mardochee_dorvilien:'mailto:mardochee.dorvilien@citi.com',
	andrea_halili:'mailto:andrea.halili@citi.com',
	sue_tozzoli:'mailto:susan.tozzoli@citi.com',
	felipe_herrmann:'mailto:felipe.herrmann@citi.com',
	kilian_kretschmer:'mailto:kilian.kretschmer@citi.com',
	ever_zambrano:'mailto:ever.zambrano@citi.com',
	latmacimclient:'mailto:*CIM LATAM Client EMEA Account Opening',
	latmacimclientamerica:'mailto:*CPB NAM Americas On-Boarding Team',
	latamcimemeaaccount:'mailto:*CIM LATAM',
	sergio_norena:'mailto:sergio.norena@citi.com',
	latamcimemeafidofficer:'mailto:*CPB CH Controls',
	robert_scherpenzeel:'mailto:robert.vanscherpenzeel@citi.com',
	glen_collins:'mailto:glen.collins@citi.com',
	latamcimemeafunding:'mailto:*CPB CH Securities Middle Office Zurich',
	rita_schuler:'mailto:rita.schuler@citi.com',
	latamcimemeaportassociates:'mailto:*CIM EMEA PAT',
	latamcimemeataxdoc:'mailto:*CPB UK Tax Documentation',
	peter_sinclair:'mailto:peter.sinclair@citi.com',
	latamcimemeataxops:'mailto:*CPB CH Tax Ops',
	ralph_woog:'mailto:ralph.woog@citi.com',
	latamcimemeataxreport:'mailto:*CPB UK Client Tax Reporting',
	santosh_kumar:'mailto:santosh7.kumar@citi.com',
	latamcimemeachaccountopen:'mailto:*CPB CH Account Opening',
	patrick_holenstein:'mailto:Patrick.holenstein@citi.com',
	tom_pirone:'mailto:thomas.pirone@citi.com',
	ricardo_castellari:'mailto:ricardo.castellari@citi.com ',
	cimlondonadu:'mailto:*CPB UK Account Opening',
	caroline_mataruco:'mailto:caroline.mataruco@citi.com',
	dina_canzoneri:'mailto:dina.d.canzoneri@citi.com',
	matt_woodruff:'mailto:matthew.woodruff@citi.com', 
	marta_watson:'mailto:marta.watsonvidot@citi.com',
	elsa_ramirez:'mailto:er67638@imcnam.ssmb.com',
	us_account:'mailto:AlternativesHF@imcnam.ssmb.com',
	uk_us_accounts:'mailto:cpb.europe.funds@citi.com',
	roberto_andrade:'mailto:roberto.deandrade@citi.com',
	giuliana_tenerelli: 'mailto:Giuliana.tenerelli@citi.com'
}