function cra_tc_link (elementID){
      $(elementID).html('<a target="_blank" style="background-image:url(https://www.privatebank.citigroup.net/common-media/images/icons/pdf.gif);" href="'+cra.terms_and_conditions+'">CRA Terms &amp; Conditions</a>');
}

function cra_tc_desc(elementID){
      
      $(elementID).html('<li>Banking teams must provide a hard copy Terms &amp; Condition to the client at the time of signing the application or prior to account opening.</li');
       
}