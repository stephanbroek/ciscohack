function CIM_Individual_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      document.getElementById('I_Tax_Attestation1').style.display = 'inline'
	  document.getElementById('I_CIM_Playback').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';

      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'inline';

      
	  document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';

      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';

      
	  document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';    
	  document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';

      
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      
	  document.getElementById('I_CIM_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}

function CIM_Trust_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
 
       document.getElementById('I_Cim_Trust_Link').style.display = 'none';      
     
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
		document.getElementById('I_Managed_General_App').style.display = 'none';

      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'none';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'inline';
  
        document.getElementById('I_Cim_Trust_Link').style.display = 'none';      
 
      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
		document.getElementById('I_Managed_General_App').style.display = 'none';

      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';

      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
       document.getElementById('I_Cim_Trust_Link').style.display = 'none';      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';

			document.getElementById('I_Managed_General_App').style.display = 'none';

      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = true;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
       document.getElementById('I_Cim_Trust_Link').style.display = 'none';      
			document.getElementById('I_Managed_General_App').style.display = 'inline';

      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
			
	case "trust":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';


      document.getElementById('I_Cim_Trust_Link').style.display = 'inline';      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
		document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
		//document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'none';
      document.getElementById('I_CIM_Admin').style.display = 'none';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'none';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'none';
			break;
			
	} 
}

function CIM_Estate_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'inline';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
         
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}

function CIM_Entity_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';


	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';

	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';

      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
     
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
     
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}

function CIM_Entity_ERISA_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';

      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';

			document.getElementById('I_Managed_General_App').style.display = 'none';

      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';

      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';

			document.getElementById('I_Managed_General_App').style.display = 'inline';

      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';

      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}

function CIM_IRA_US(app_type) {
 
	switch (app_type){
		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectTDP').checked = false;
      
	  document.getElementById('I_Investment_Management_App').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_Managed_Citibank_IRA').style.display = 'inline';
	 //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
    
			break;
      
    case "tdp":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = true;
      
	  document.getElementById('I_Investment_Management_App').style.display = 'none';
	  document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
	  document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_Managed_Citibank_IRA').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
	  //document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}

function CIM_Trust_EMEA(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';

			break;
	} 
}

function CIM_Estate_EMEA(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';

			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';

			break;
	} 
}


function CIM_Entity_EMEA(app_type, acct_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      //document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	        	if(acct_type=="Unincorporated Association"){
		document.getElementById('I_Managed_Organizational_Agreement').style.display = 'none';
	} else {
		document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	}
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';

			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      //document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  if(acct_type=="Unincorporated Association"){
		document.getElementById('I_Managed_Organizational_Agreement').style.display = 'none';
	} else {
		document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	}
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';
			break;
	} 
}

function CIM_Entity_ERISA_EMEA(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
	} 
}

function CIM_Entity_EMEA_CCIFL(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
	document.getElementById('I_CIM_CCIFL_Application').style.display = 'inline';
      document.getElementById('I_CIM_CCIFL_TDP_Application').style.display = 'none';
	  document.getElementById('I_Canada_CCIFL_Core_App_CIM').style.display = 'inline';
      document.getElementById('I_CIM_CCIFL_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9W8_Canada_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Att_CA').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_CCIFL').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
	document.getElementById('I_CIM_CCIFL_Application').style.display = 'inline';
      document.getElementById('I_CIM_CCIFL_TDP_Application').style.display = 'inline';
	  document.getElementById('I_Canada_CCIFL_Core_App_CIM').style.display = 'none';
      document.getElementById('I_CIM_CCIFL_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9W8_Canada_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Att_CA').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_CCIFL').style.display = 'inline';
			break;
	} 
}

function CIM_Individual_EMEA_AO(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_IOS_CIM_EMEA_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Individual').style.display = 'inline';
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';

			break;
	} 
}

function CIM_Individual_IRA_EMEA_AO(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Managed_Citibank_IRA').style.display = 'inline';
      
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Individual').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Individual').style.display = 'inline';
			break;
	} 
}

function show_inc (type) {
	if(type=="Unincorporated Association"){
		document.getElementById('I_Managed_Organizational_Agreement').style.display = 'none';
	} else {
		document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	}
	
}