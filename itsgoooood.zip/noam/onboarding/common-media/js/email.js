// JavaScript Document
function EmailFunctionality(emailSubject,emailBody){
//Reference to Outlook.Application 
var theApp;  
//Outlook.mailItem
var theMailItem; 

//Create a object of Outlook.Application
try {
    //Attach Files to the email
    var attach = "https://www.privatebank.citigroup.net/banking/docs/CertofFidPBG334_1006_B.pdf";
    var theApp = new ActiveXObject("Outlook.Application");
    var objNS = theApp.GetNameSpace('MAPI');
    var theMailItem = theApp.CreateItem(0); // value 0 = MailItem
    //Bind the variables with the email
    //theMailItem.to = (emailTo);
    //theMailItem.cc =(emailCcTo);
    theMailItem.Subject = (emailSubject);
    theMailItem.Body = (emailBody);
    theMailItem.Attachments.add(attach);
    theMailItem.display();
}
catch (err) {
    alert("Outlook configuration error."+err.message );
}
}