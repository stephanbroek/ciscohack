// JavaScript Document
function Brokerage_Individual_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';  
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  /*document.getElementById('req').style.display = 'inline';
	  document.getElementById('instructions1').style.display = 'inline';
	  document.getElementById('optional1').style.display = 'inline';*/
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'none';
	 
	  document.getElementById('I_Brokerage_6949_Question').style.display = 'inline';
	  
	  document.getElementById('reqdocs').innerHTML='Client Relationship Agreement Packet';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';

      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  <!--document.getElementById('I_Tax_At').style.display = 'inline';   
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  /*document.getElementById('req').style.display = 'inline';
	  document.getElementById('instructions1').style.display = 'inline';
	  document.getElementById('optional1').style.display = 'inline';
	  document.getElementById('reqdocs').innerHTML='3026 Application Packet';*/
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'none';
	  
	  document.getElementById('I_Brokerage_6949_Question').style.display = 'inline';
	  
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  /*document.getElementById('req').style.display = 'inline';
	  document.getElementById('instructions1').style.display = 'inline';
	  document.getElementById('optional1').style.display = 'inline';
	  document.getElementById('reqdocs').innerHTML='Playback Packet';*/
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'none';
	  
	  document.getElementById('I_Brokerage_6949_Question').style.display = 'inline';
	  
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	 case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';

      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  /*document.getElementById('I_Tax_At1').style.display = 'inline';*/
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_6949_Question').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
/*	  document.getElementById('req').style.display = 'inline';
	  document.getElementById('instructions1').style.display = 'inline';
	  document.getElementById('optional1').style.display = 'inline';
	  document.getElementById('reqdocs').innerHTML='3026 Application Packet';*/
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}

function Individual_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectba').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_6949_Question').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individ').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectba').checked = false;
      
		document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_6949_Question').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Trade_Execution_Individ').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
		case "brokeadd":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectba').checked = true;
      
		
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_6949_Question').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Trade_Execution_Individ').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
     //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
			case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectba').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individ').style.display = 'inline';
	  <!--document.getElementById('I_Tax_At').style.display = 'inline';-->
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_6949_Question').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	  		break;
	} 
}


function IRA_Brokerage_Retail(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	    //load specific brokerage apps
      Brokerage_Managed_Load_Documents_IRA(document.getElementById('q_business').value);
	  if (url.match(/onboarding_latam/)) {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
		  } else {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'none';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'none';
		  }
		break;
      
    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      document.getElementById('selectSEP').checked = false;
      
	  document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	    //load specific brokerage apps
      Brokerage_Managed_Load_Documents_IRA(document.getElementById('q_business').value);
	  if (url.match(/onboarding_latam/)) {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
		  } else {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'none';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'none';
		  }
			break;
  
  case "sep":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = true;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'inline';
      document.getElementById('I_Brokerage_5305').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	    //load specific brokerage apps
      Brokerage_Managed_Load_Documents_IRA(document.getElementById('q_business').value);
	  if (url.match(/onboarding_latam/)) {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
		  } else {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'none';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'none';
		  }
			break;
	} 
}

function IRA_Brokerage_COD(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
	  reset_Brokerage_COD_Syndicate_Docs();
	  if (url.match(/onboarding_latam/)) {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
		  } else {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'none';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'none';
		  }
			break;
      
    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
	  reset_Brokerage_COD_Syndicate_Docs();
	  if (url.match(/onboarding_latam/)) {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
		  } else {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'none';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'none';
		  }
			break;
  
  case "sep":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = true;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'inline';
      document.getElementById('I_Brokerage_5305').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
	  reset_Brokerage_COD_Syndicate_Docs();
	  if (url.match(/onboarding_latam/)) {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
		  } else {
			 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'none';
	  		 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'none';
		  }
			break;
	} 
	
}

function Trust_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	     document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
	  document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5036').style.display = 'inline';
       document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
	  document.getElementById('LA_W8IMY').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
     // Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}

function Trust_Brokerage_COD(app_type) {

	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
	document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
     document.getElementById('I_W9W8_Trust').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline';*/
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
     //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
     document.getElementById('I_W9W8_Trust').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
     //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
     //reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
     document.getElementById('I_W9W8_Trust').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	 //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "latam":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
     document.getElementById('I_W9W8_Trust').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	 document.getElementById('I_Tax_At').style.display = 'inline';
	 document.getElementById('LA_W8IMY').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	 //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 

}

function Estate_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	     document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5501').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline';  */
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline'; 
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5501').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline';  */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_5501').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
	  document.getElementById('I_Brokerage_5501').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */ 
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5501').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
	  document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
     // Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}

function Estate_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	  
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */  
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */ 
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline';  */
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "latam":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
		document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
     // document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
     // reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}

function Corporation_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_2105').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_2105').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
	  document.getElementById('I_Brokerage_2105').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_2105').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	  document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
      //reset_Brokerage_Managed_Apps();
     // Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}

function Corporation_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline';*/
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	 
	  document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	 case "latam":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
	  document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
	  
	 document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
     //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
     //reset_Brokerage_COD_Syndicate_Docs();
			break;		
	} 
	
}

function GP_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	    document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
	  document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
		document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_2104').style.display = 'inline';
	  
	 document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('LA_W8IMY').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
     //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;		
			
	} 
}

function GP_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
     //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
     //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
	 document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
	
	case "latam":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	  document.getElementById('LA_W8IMY').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}

function LLC_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	    document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	    document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	    document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
	  document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
		case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5466').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;	
	} 
}

function LLC_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
	document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
	 document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	 //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
		 case "latam":
	  document.getElementById('selectCRA').checked = false;
	 document.getElementById('selectAdd').checked = false;
	  document.getElementById('select3026').checked = true;
  
	  
	  document.getElementById('I_CRA_Application').style.display = 'none';
	  document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Brokerage_3026').style.display = 'inline';
	  document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5466').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
	  
	 document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	 document.getElementById('I_Tax_At').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
	  document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
	  //reset_Brokerage_COD_Syndicate_Docs();
			break;	
	} 
	
}

function SP_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline';   */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';;
	  document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */  
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
	  document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline';   */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
		 case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';;
	  document.getElementById('I_Brokerage_3164').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;	
	} 
}

function SP_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
	document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline';   */
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline';   */
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline';   */
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
		case "latam":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
     // document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;	
	} 
	
}

function UN_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = false;
      
	document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
	  document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
		 case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5277').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
     // reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;	
	} 
}

function UN_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
	document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	/* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	 case "latam":
      document.getElementById('selectCRA').checked = false;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Corp_Docs_LA').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
	 document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  //document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      //document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      //reset_Brokerage_COD_Syndicate_Docs();
			break;		
	} 
	
}

function ERISA_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	    document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5502').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5502').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
	  document.getElementById('I_Brokerage_5502').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	 case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
	  document.getElementById('I_Brokerage_5502').style.display = 'inline';
      
	  
	  document.getElementById('I_Brokerage_5521C_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Valid_ID_LA').style.display = 'inline';
	 document.getElementById('I_Brokerage_Approved_CRF_LA').style.display = 'inline';
	 
	  document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      //Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;		
	} 
}
function Custodial_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_Custodial_3026').style.display = 'none';
      document.getElementById('I_Custodial_Addendum').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('req').style.display = 'inline';
	  document.getElementById('instructions1').style.display = 'inline';
	  document.getElementById('optional1').style.display = 'inline';
	  document.getElementById('reqdocs').innerHTML='Client Relationship Agreement Packet';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_Custodial_3026').style.display = 'inline';
      document.getElementById('I_Custodial_Addendum').style.display = 'none';

      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  /*document.getElementById('I_Tax_Attestation1').style.display = 'inline';*/
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('req').style.display = 'inline';
	  document.getElementById('instructions1').style.display = 'inline';
	  document.getElementById('optional1').style.display = 'inline';
	  document.getElementById('reqdocs').innerHTML='3026 Application Packet';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_Custodial_3026').style.display = 'none';
      document.getElementById('I_Custodial_Addendum').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('req').style.display = 'inline';
	  document.getElementById('instructions1').style.display = 'inline';
	  document.getElementById('optional1').style.display = 'inline';
	  document.getElementById('reqdocs').innerHTML='Playback Packet';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	 case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_Custodial_3026').style.display = 'inline';
      document.getElementById('I_Custodial_Addendum').style.display = 'none';

      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	     
	} 
}
function Custodial_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectba').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Brokerage_Custodial_3026').style.display = 'none';
      document.getElementById('I_Custodial_Addendum').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individ').style.display = 'inline';
	  /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectba').checked = false;
      
		document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_Custodial_3026').style.display = 'inline';
      document.getElementById('I_Custodial_Addendum').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individ').style.display = 'inline';
	/*  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
		case "brokeadd":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectba').checked = true;
      
		
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_Custodial_3026').style.display = 'none';
      document.getElementById('I_Custodial_Addendum').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individ').style.display = 'inline';
	 /* document.getElementById('I_Tax_Attestation1').style.display = 'inline'; */
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	 case "latam":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectba').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Brokerage_Custodial_3026').style.display = 'inline';
      document.getElementById('I_Custodial_Addendum').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individ').style.display = 'inline';
	  document.getElementById('I_Tax_At').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      		break;
	} 
}