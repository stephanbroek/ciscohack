function Investor_Individual_HNW(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';

      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	  document.getElementById('I_TC_Amendments').style.display = 'none';    
      
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
       document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
 document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	  document.getElementById('I_TC_Amendments').style.display = 'none';
 
	  document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
       document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
 document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
	  document.getElementById('I_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}
function HNW_Trust_Investor(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	  document.getElementById('I_TC_Amendments').style.display = 'none';
            
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
       document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
 document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	   document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	  document.getElementById('I_TC_Amendments').style.display = 'none';
            
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
       document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
 document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
	  document.getElementById('I_TC_Amendments').style.display = 'inline';
           
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';;
			break;
	} 
}
function Estate_AO_Investor(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';

      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	  document.getElementById('I_TC_Amendments').style.display = 'none';      
      
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
       document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
 document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	  document.getElementById('I_TC_Amendments').style.display = 'none';
            
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
       document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
 document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
	  document.getElementById('I_TC_Amendments').style.display = 'inline';
            
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';;
			break;
	} 
}
function hnweaoinv(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';

      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	   document.getElementById('I_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
  
            
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
       document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
 document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	   document.getElementById('I_TC_Amendments').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
       
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
       document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
 document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
	   document.getElementById('I_TC_Amendments').style.display = 'inline';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}