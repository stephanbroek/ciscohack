function CES_Individual_All(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
			
      document.getElementById('I_W9W8_Individual').style.display = 'none';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_AAM_Individuals').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';

      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_AAM_Individuals').style.display = 'inline';
			break;

		case "ces":
      document.getElementById('selectCES').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
      
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_AAM_Individuals').style.display = 'inline';
			break;
 
	} 
}

function CES_Trust_All(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
	  document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'inline';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "ces":
      document.getElementById('selectCES').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
      
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
   
	} 
}

function CES_Estate_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'inline';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "ces":
      document.getElementById('selectCES').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
	  document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
   
	} 
}

function CES_Entity_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
      document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	   document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'none';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';

      document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	   document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'inline';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "ces":
      document.getElementById('selectCES').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';

      document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	   document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
	  document.getElementById('I_Managed_General_App').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed_Optional').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
	} 
}

function CES_Entity_ERISA(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	   document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Blocked_List').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCES').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_Single_Advisory_Contract').style.display = 'none';
	   document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Blocked_List').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;

		case "ces":
      document.getElementById('selectCES').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Single_Advisory_Contract').style.display = 'inline';
	   document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Blocked_List').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
	  document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_AAM_Entities').style.display = 'inline';
			break;
    
	} 
}

function Ind_IRA_CES(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      
	  document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;


    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      
	  document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';

      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}
