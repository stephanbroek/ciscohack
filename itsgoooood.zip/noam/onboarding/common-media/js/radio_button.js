  // Function added by Ashish Leekha for Expand/Collapse Functionality
function expandCollapse(expId,collId){
	var cssEffect = document.getElementById(collId).style.display;
	if(cssEffect == "none"){
		document.getElementById(expId).className="open";
		document.getElementById(collId).style.display="block";
	}
	if(cssEffect == "block"){
		document.getElementById(expId).className="";
		document.getElementById(collId).style.display="none";
	}
}

function checkManaged(){
  if (document.getElementById('brokerage_managed_checkbox').checked==true){
      document.getElementById('brokerage_dap').style.display = 'block';
      document.getElementById('brokerage_fiduciary').style.display = 'block';
      document.getElementById('brokerage_citiadvisor').style.display = 'block';
      document.getElementById('brokerage_umbrella').style.display = 'block';
  } else{
      document.getElementById('brokerage_dap').style.display = 'none';
      document.getElementById('brokerage_fiduciary').style.display = 'none';
      document.getElementById('brokerage_citiadvisor').style.display = 'none';
      document.getElementById('brokerage_umbrella').style.display = 'none';
      reset_Brokerage_Managed_Apps();
  }

}

function questiontod1(userSelect) {
 if (userSelect=="yes"){
    document.getElementById('state_Yes').checked = true;
	  document.getElementById('state_No').checked = false;
      
    document.getElementById('yes_tod').style.display = 'inline';
	  document.getElementById('no_tod').style.display = 'none';
    
  } else if (userSelect=="no"){     
    document.getElementById('state_Yes').checked = false;
	  document.getElementById('state_No').checked = true;
      
    document.getElementById('yes_tod').style.display = 'none';
	  document.getElementById('no_tod').style.display = 'inline';

	} 
}

function PC_Individual_LFG(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
	    document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
	<!--  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline';  -->
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
			break;
	} 
}

function PC_Trust_LFG(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
	    document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
	<!--  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'none'; 
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;
	} 
}
function LFG_NW3_Estate_Preferred_Custody(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
	    document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';

      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;
	} 
}
/*function Individual_Custodial(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application_Custodial').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Citifolio_Application_Custodial').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application_Custodial').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Citifolio_Application_Custodial').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}*/
/*function Individual_AO_Banking(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
	    document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
	    document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
	    document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
	    document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
	    document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
	    document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}*/
/*function Trust_AO_Banking(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}*/
/*function Estate_AO_Banking(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}*/

/*function Corporation_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}*/

/*function Corporation_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	    document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_2105').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_2105').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	  document.getElementById('I_Brokerage_2105').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}
*/

function ERISA_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5502').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5502').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5502').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}

/*function ERISA_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	    document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_5502').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_5502').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	  document.getElementById('I_Brokerage_5502').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}
*/
/*function Trust_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	     document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	  document.getElementById('I_Brokerage_5036').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}*/

/*function Trust_Brokerage_COD(app_type) {

	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 

}
*/
/*function Estate_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	     document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
	  document.getElementById('I_Brokerage_5501').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
	  document.getElementById('I_Brokerage_5501').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_5501').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
	  document.getElementById('I_Brokerage_5501').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}
*/
/*function Estate_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}
*/
/*function GP_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	    document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	  document.getElementById('I_Brokerage_2104').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}*/

/*function GP_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}*/

/*function LLC_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	    document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	    document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	    document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	  document.getElementById('I_Brokerage_5466').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}*/

/*function LLC_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}
*/
/*function SP_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	  document.getElementById('I_Brokerage_3164').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}
*/
/*function SP_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}*/

/*function UN_Brokerage_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
	  document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	  document.getElementById('I_Brokerage_5277').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}*/

/*function UN_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = false;

      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
	  	  document.getElementById('selectAdd').checked = false;
      document.getElementById('select3026').checked = true;

      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Entity').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}*/

function HNW_Entity_Brokerage_GP(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function hnwaobrlp(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function hnwaobrllc(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}function hnweaobrsp(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function hnweaobrua(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
/*
function hnweaoinv(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
  
            
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
       
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
	  document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/
function PC_Entity_HNW(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
	<!--  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'none'; 
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
	<!--  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	<!--  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
	 document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;
	} 
}

/*function Brokerage_Individual_Retail(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	     document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	     document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectadd').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
			
	case "addendum":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectadd').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      //reset_Brokerage_Managed_Apps();
      Brokerage_Managed_Load_Documents(document.getElementById('q_business').value);
			break;
	} 
}*/

/*function Individual_Brokerage_COD(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectba').checked = false;
      
	  document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
	  document.getElementById('selectba').checked = false;
      
		document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
			
		case "brokeadd":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = false;
	  document.getElementById('selectba').checked = true;
      
		
	document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
      document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
      reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
}*/
/*
function Investor_Individual_HNW(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';

      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/
function PC_Individual_HNW(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
		document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	<!--  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	<!--  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
			break;
	} 
}
/*function DAP_Trust_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "dap":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_DAP_Product_Specific').style.display = 'inline';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/

/*function DAP_Entity_ERISA(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "dap":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_DAP_Product_Specific').style.display = 'inline';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/

/*function MSP_Entity_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';

      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "msp":
      document.getElementById('selectMSP').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';

      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_MSP_Product_Specific').style.display = 'inline';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';

      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/

/*function MSP_Entity_ERISA(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_MSP_SMA_Fees').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Blocked_List').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_MSP_SMA_Fees').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Blocked_List').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "msp":
      document.getElementById('selectMSP').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_MSP_Product_Specific').style.display = 'inline';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_MSP_SMA_Fees').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Blocked_List').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'none';
      document.getElementById('I_MSP_SMA_Fees').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Blocked_List').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/

/*function lfghnwiaocim(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/
/*function DAP_Individual_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

		case "dap":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = true;

			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_DAP_Product_Specific').style.display = 'inline';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/
/*function lfghnwiaomsp(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

		case "msp":
      document.getElementById('selectMSP').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_MSP_Product_Specific').style.display = 'inline';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/
/*function CIM_Trust_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = true;
	  document.getElementById('selectTrust').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
			
	case "trust":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
	  document.getElementById('selectTrust').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Trust_Account_Forms').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'none';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'none';
			break;
			
	} 
}*/

/*function CIM_Estate_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/

function LFG_HNW_Estate_CIM(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
/*function DAP_Estate_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';

      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "dap":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_DAP_Product_Specific').style.display = 'inline';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/
/*function LFG_HNW_Trust_DAP(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectDAP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_DAP_Product_Specific').style.display = 'none';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "dap":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectDAP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_DAP_Playback').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_DAP_Product_Specific').style.display = 'inline';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/

/*function MSP_Estate_ALL(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';;
			break;

		case "msp":
      document.getElementById('selectMSP').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_MSP_Product_Specific').style.display = 'inline';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/
/*function LFG_HNW_Trust_MSP(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'inline';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';;
			break;

		case "msp":
      document.getElementById('selectMSP').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_MSP_Product_Specific').style.display = 'inline';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectMSP').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_MSP_Playback').style.display = 'none';
      document.getElementById('I_MSP_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_MSP_Product_Specific').style.display = 'none';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/
function lfgeaobrco(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2105').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function lfgeaobrgp(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function lfgeaobrlp(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_2104').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function lfgeaobrllc(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5466').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function lfgeaobrsp(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_3164').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function lfgeaobrua(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5277').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function lfgeapinv(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function PC_Entity_LFG(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
           document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
 
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'none'; 
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  
	  
			break;
	} 
}
function lfgpsgeaobr(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5501').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function lfgpsgteaoi(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';;
			break;
	} 
}
function LFG_NW3_Estate_Investor(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';;
			break;
	} 
}
function lsgpsgnw35iaobr(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}
function lfgpsgnw35iaoin(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}
function lfgpsgnw35taobr(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('select3026').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Brokerage_3026').style.display = 'none';
      document.getElementById('I_Brokerage_Addendum').style.display = 'inline';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "3026":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('select3026').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Brokerage_3026').style.display = 'inline';
      document.getElementById('I_Brokerage_Addendum').style.display = 'none';
      document.getElementById('I_Brokerage_5036').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
/*
function Estate_AO_Investor(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
      
      
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
            
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
            
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';;
			break;
	} 
}*/
/*
function HNW_Trust_Investor(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_Investor_Playback').style.display = 'inline';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
            
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectInvestor').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'inline';
      document.getElementById('I_Investor_Agreement').style.display = 'none';
            
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "investor":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectInvestor').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_Investor_Playback').style.display = 'none';
      document.getElementById('I_Investor_Playback_No_Sig').style.display = 'none';
      document.getElementById('I_Investor_Agreement').style.display = 'inline';
           
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_AAM_Entities').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';;
			break;
	} 
}*/

function PC_Estate_HNW(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
          document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
  
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
           document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';
 
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline';  -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
      
      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline'; 
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
	<!--  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline';  -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;
	} 
}
function HNW_Trust_Preferred_Custody(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
 <!--     document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
	  
      document.getElementById('I_W9W8_Trust').style.display = 'none';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';

			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; --> 
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';

			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';

			break;
	} 
}
/*function IRA_Brokerage_COD(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
	  reset_Brokerage_COD_Syndicate_Docs();
			break;
      
    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
	  reset_Brokerage_COD_Syndicate_Docs();
			break;
  
  case "sep":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = true;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'inline';
      document.getElementById('I_Brokerage_5305').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Brokerage_COD_Delivery_Instructions').style.display = 'inline';
	  document.getElementById('I_Brokerage_Trade_Execution_Individual').style.display = 'inline';
      document.getElementById('I_Brokerage_Syndicate_Checkbox').style.display = 'inline';
	  reset_Brokerage_COD_Syndicate_Docs();
			break;
	} 
	
}*/

/*function IRA_Brokerage_Retail(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	    //load specific brokerage apps
      Brokerage_Managed_Load_Documents_IRA(document.getElementById('q_business').value);
			break;
      
    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	    //load specific brokerage apps
      Brokerage_Managed_Load_Documents_IRA(document.getElementById('q_business').value);
			break;
  
  case "sep":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = true;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'inline';
      document.getElementById('I_Brokerage_5305').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
	    //load specific brokerage apps
      Brokerage_Managed_Load_Documents_IRA(document.getElementById('q_business').value);
			break;
	} 
}*/

function IRA_Brokerage_Umbrella(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = false;
      
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';
      document.getElementById('I_Umbrella_Terms_Conditions').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      document.getElementById('selectSEP').checked = false;
      
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';
      document.getElementById('I_Umbrella_Terms_Conditions').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
  
  case "sep":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = true;
      
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'inline';
      document.getElementById('I_Brokerage_5305').style.display = 'inline';
      
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';
      document.getElementById('I_Umbrella_Terms_Conditions').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_Individuals').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}
//old
function Ind_IRA_Brokerage_LFG(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      document.getElementById('selectSEP').checked = false;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'none';
      document.getElementById('I_Brokerage_5305').style.display = 'none';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
  
  case "sep":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = false;
      document.getElementById('selectSEP').checked = true;
      
			document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Brokerage_SEP_Adop').style.display = 'inline';
      document.getElementById('I_Brokerage_5305').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Individual').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}
function Ind_IRA_CES(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CES_Product_Specific').style.display = 'inline';
      document.getElementById('I_CES_3rd_Party_Contract').style.display = 'inline';
      document.getElementById('I_CES_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CES_Product_Specific').style.display = 'inline';
      document.getElementById('I_CES_3rd_Party_Contract').style.display = 'inline';
      document.getElementById('I_CES_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}
/*function Ind_IRA_DAP(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_DAP_Product_Specific').style.display = 'inline';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_DAP_Product_Specific').style.display = 'inline';
      document.getElementById('I_DAP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/
/*function Ind_IRA_MSP(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_MSP_Product_Specific').style.display = 'inline';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;


    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_MSP_Product_Specific').style.display = 'inline';
      document.getElementById('I_MSP_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/
/*function Ind_IRA_Umbrella(app_type) {
	switch (app_type){
		case "traditional":
      document.getElementById('selectTraditional').checked = true;
      document.getElementById('selectRoth').checked = false;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';
      document.getElementById('I_Umbrella_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'inline';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

    case "roth":
      document.getElementById('selectTraditional').checked = false;
      document.getElementById('selectRoth').checked = true;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';
      document.getElementById('I_Umbrella_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Traditional_Adoption').style.display = 'none';
      document.getElementById('I_Managed_Roth_Adoption').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/
/*function Individual_Joint_Minor_Banking(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectCitifolio').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Citifolio_Application').style.display = 'none';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Joint_Minor_Indemnity').style.display = 'inline';
      document.getElementById('I_Joint_Minor_BRM').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      document.getElementById('I_AAM_Form').style.display = 'inline';
      
			break;
      
    case "citifolio":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectCitifolio').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Citifolio_Application').style.display = 'inline';
      document.getElementById('I_Citifolio_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      document.getElementById('I_Banking_Other_Disclosures').style.display = 'inline';
      document.getElementById('I_Joint_Minor_Indemnity').style.display = 'inline';
      document.getElementById('I_Joint_Minor_BRM').style.display = 'inline';
      document.getElementById('I_Banking_Proof_of_Address').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      document.getElementById('I_AAM_Form').style.display = 'inline';
			break;
	} 
}*/


  var underFirm;
  var valueOver;
  var attorney;

function selectFirm(userSelect) {
  if (userSelect=="firm"){
      //radio buttons
      document.getElementById('firm').checked = true;
      document.getElementById('individual').checked = false;
      document.getElementById('greater1mil').checked = false;
      document.getElementById('lessthan1mil').checked = false;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'none';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'none';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'none';
      document.getElementById('tax').style.display = 'none';
      
      //set Firm variable
      underFirm = true;
  } else{
      //radio buttons
      document.getElementById('firm').checked = false;
      document.getElementById('individual').checked = true;
      document.getElementById('greater1mil').checked = false;
      document.getElementById('lessthan1mil').checked = false;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'none';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'none';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'none';
      document.getElementById('tax').style.display = 'none';
      
      //set Firm variable
      underFirm = false;
  }
}

function selectValue(userSelect, varFirm) {
 if (varFirm && userSelect=="yes"){
      //radio buttons
      document.getElementById('firm').checked = true;
      document.getElementById('individual').checked = false;
      document.getElementById('greater1mil').checked = true;
      document.getElementById('lessthan1mil').checked = false;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'none';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'none';
      document.getElementById('tax').style.display = 'none';
      
      valueOver = true;
      underFirm = true;
  } else if (varFirm && userSelect=="no"){
      //radio buttons
      document.getElementById('firm').checked = true;
      document.getElementById('individual').checked = false;
      document.getElementById('greater1mil').checked = false;
      document.getElementById('lessthan1mil').checked = true;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'none';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'none';
      document.getElementById('tax').style.display = 'none';
      
      valueOver = false;
      underFirm = true;
  } else if (!varFirm && userSelect=="yes"){
      //radio buttons
      document.getElementById('firm').checked = false;
      document.getElementById('individual').checked = true;
      document.getElementById('greater1mil').checked = true;
      document.getElementById('lessthan1mil').checked = false;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'none';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'inline';
      
      //grantors
      document.getElementById('L0').style.display = 'inline';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'inline';
      document.getElementById('tax').style.display = 'inline';
      
      valueOver = false;
      underFirm = false;
  } else {
      //radio buttons
      document.getElementById('firm').checked = false;
      document.getElementById('individual').checked = true;
      document.getElementById('greater1mil').checked = false;
      document.getElementById('lessthan1mil').checked = true;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'none';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'none';
      document.getElementById('tax').style.display = 'none';
      
      valueOver = false;
      underFirm = false;
  }
}

function selectAttorney(userSelect, varFirm, varValue) {
 if (varFirm && varValue && userSelect=="yes"){
      //radio buttons
      document.getElementById('firm').checked = true;
      document.getElementById('individual').checked = false;
      document.getElementById('greater1mil').checked = true;
      document.getElementById('lessthan1mil').checked = false;
      document.getElementById('attorney').checked = true;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'inline';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'inline';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'inline';
      document.getElementById('tax').style.display = 'inline';

  } else if (varFirm && varValue && userSelect=="no"){
      //radio buttons
      document.getElementById('firm').checked = true;
      document.getElementById('individual').checked = false;
      document.getElementById('greater1mil').checked = true;
      document.getElementById('lessthan1mil').checked = false;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = true;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'inline';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'inline';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'inline';
      document.getElementById('tax').style.display = 'inline';

  } else if (varFirm && !varValue && userSelect=="yes"){
      //radio buttons
      document.getElementById('firm').checked = true;
      document.getElementById('individual').checked = false;
      document.getElementById('greater1mil').checked = false;
      document.getElementById('lessthan1mil').checked = true;
      document.getElementById('attorney').checked = true;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'inline';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'inline';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'inline';
      document.getElementById('tax').style.display = 'inline';

  } else if (varFirm && !varValue && userSelect=="no"){
      //radio buttons
      document.getElementById('firm').checked = true;
      document.getElementById('individual').checked = false;
      document.getElementById('greater1mil').checked = false;
      document.getElementById('lessthan1mil').checked = true;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = true;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'inline';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'inline';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'inline';
      document.getElementById('tax').style.display = 'inline';

  } else if (!varFirm && !varValue && userSelect=="yes"){
      //radio buttons
      document.getElementById('firm').checked = false;
      document.getElementById('individual').checked = true;
      document.getElementById('greater1mil').checked = false;
      document.getElementById('lessthan1mil').checked = true;
      document.getElementById('attorney').checked = true;
      document.getElementById('nonattorney').checked = false;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'inline';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'inline';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'none';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'inline';
      document.getElementById('tax').style.display = 'inline';

  } else if (!varFirm && !varValue && userSelect=="no"){
      //radio buttons
      document.getElementById('firm').checked = false;
      document.getElementById('individual').checked = true;
      document.getElementById('greater1mil').checked = false;
      document.getElementById('lessthan1mil').checked = true;
      document.getElementById('attorney').checked = false;
      document.getElementById('nonattorney').checked = true;
      
      //questions
      document.getElementById('questionValue').style.display = 'inline';
      document.getElementById('questionAttorney').style.display = 'inline';
      
      //legal existence
      document.getElementById('legal_existence').style.display = 'inline';
      
      //grantors
      document.getElementById('L0').style.display = 'none';
      document.getElementById('L1').style.display = 'none';
      document.getElementById('L4').style.display = 'none';
      document.getElementById('L6').style.display = 'inline';
      
      //executor and tax certification
      document.getElementById('signer').style.display = 'inline';
      document.getElementById('tax').style.display = 'inline';

  }
}

function questionClientState(userSelect) {
 if (userSelect=="yes"){
    document.getElementById('state_Yes').checked = true;
	  document.getElementById('state_No').checked = false;
      
    document.getElementById('dodd_frank').style.display = 'inline';
	  document.getElementById('no_disclosure_dodd').style.display = 'none';
    
  } else if (userSelect=="no"){     
    document.getElementById('state_Yes').checked = false;
	  document.getElementById('state_No').checked = true;
      
    document.getElementById('dodd_frank').style.display = 'none';
	  document.getElementById('no_disclosure_dodd').style.display = 'inline';

	} 
}

function questionClientState_C1(userSelect) {
 if (userSelect=="yes"){
    document.getElementById('state_Yes_C1').checked = true;
	  document.getElementById('state_No_C1').checked = false;
      
    document.getElementById('dodd_frank_C1').style.display = 'inline';
	  document.getElementById('no_disclosure_dodd_C1').style.display = 'none';
    
  } else if (userSelect=="no"){     
    document.getElementById('state_Yes_C1').checked = false;
	  document.getElementById('state_No_C1').checked = true;
      
    document.getElementById('dodd_frank_C1').style.display = 'none';
	  document.getElementById('no_disclosure_dodd_C1').style.display = 'inline';

	} 
}

function questionClientState_C2(userSelect) {
 if (userSelect=="yes"){
    document.getElementById('state_Yes_C2').checked = true;
	  document.getElementById('state_No_C2').checked = false;
      
    document.getElementById('dodd_frank_C2').style.display = 'inline';
	  document.getElementById('no_disclosure_dodd_C2').style.display = 'none';
    
  } else if (userSelect=="no"){     
    document.getElementById('state_Yes_C2').checked = false;
	  document.getElementById('state_No_C2').checked = true;
      
    document.getElementById('dodd_frank_C2').style.display = 'none';
	  document.getElementById('no_disclosure_dodd_C2').style.display = 'inline';

	} 
}

function questionRenminbi(userSelect) {
 if (userSelect=="yes"){
      document.getElementById('multi_Yes').checked = true;
	  document.getElementById('multi_No').checked = false;
	  
      document.getElementById('renminbi').style.display = 'inline';
	  document.getElementById('no_disclosure_renminbi').style.display = 'none';

   } else if (userSelect=="no"){      
    document.getElementById('multi_Yes').checked = false;
	  document.getElementById('multi_No').checked = true;
     
    document.getElementById('renminbi').style.display = 'none';
	  document.getElementById('no_disclosure_renminbi').style.display = 'inline';
	} 
}

function questionRenminbi_C1(userSelect) {
 if (userSelect=="yes"){
      document.getElementById('multi_Yes_C1').checked = true;
	  document.getElementById('multi_No_C1').checked = false;
	  
      document.getElementById('renminbi_C1').style.display = 'inline';
	  document.getElementById('no_disclosure_renminbi_C1').style.display = 'none';

   } else if (userSelect=="no"){      
    document.getElementById('multi_Yes_C1').checked = false;
	  document.getElementById('multi_No_C1').checked = true;
     
    document.getElementById('renminbi_C1').style.display = 'none';
	  document.getElementById('no_disclosure_renminbi_C1').style.display = 'inline';
	} 
}

function questionRenminbi_C2(userSelect) {
 if (userSelect=="yes"){
      document.getElementById('multi_Yes_C2').checked = true;
	  document.getElementById('multi_No_C2').checked = false;
	  
      document.getElementById('renminbi_C2').style.display = 'inline';
	  document.getElementById('no_disclosure_renminbi_C2').style.display = 'none';

   } else if (userSelect=="no"){      
    document.getElementById('multi_Yes_C2').checked = false;
	  document.getElementById('multi_No_C2').checked = true;
     
    document.getElementById('renminbi_C2').style.display = 'none';
	  document.getElementById('no_disclosure_renminbi_C2').style.display = 'inline';
	} 
}

function lfghnwemeacim(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
function lfghnweacim(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}
/*function lfghnwiusaocim(app_type) {
//CIM Individual US
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Individual').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CRA_Application_Individual').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'none';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/
function isErisa(userSelect) {
 if (userSelect=="yes"){
    document.getElementById('erisa_yes').checked = true;
	  document.getElementById('erisa_no').checked = false;
      
    document.getElementById('erisa_not_required').style.display = 'none';
	  document.getElementById('erisa_required').style.display = 'inline';
    
  } else if (userSelect=="no"){     
    document.getElementById('erisa_yes').checked = false;
	  document.getElementById('erisa_no').checked = true;
      
    document.getElementById('erisa_not_required').style.display = 'inline';
	  document.getElementById('erisa_required').style.display = 'none';

	} 
}

function HNW_PC_ERISA(app_type) {
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Entity_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9_ERISA').style.display = 'none';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Entity_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9_ERISA').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Entity_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9_ERISA').style.display = 'inline';
      document.getElementById('I_AAM_HNW_Entity').style.display = 'inline';
			break;
	} 
}


function LFG_PC_ERISA(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'inline';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Entity_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'inline';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9_ERISA').style.display = 'none';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectPC').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'none';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'none'; -->
      document.getElementById('I_Entity_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9_ERISA').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;

		case "preferred_custody":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectPC').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments_CRA').style.display = 'none';
            document.getElementById('I_Preferred_Custody_Checklist').style.display = 'inline';

      document.getElementById('I_Preferred_Custody_Playback_Day1').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Playback').style.display = 'none';
      document.getElementById('I_Preferred_Custody_Application').style.display = 'inline';
<!--	  document.getElementById('I_TC_Amendments').style.display = 'inline'; -->
      document.getElementById('I_Entity_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_Preferred_Custody_Privacy_Notice').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
<!--	  document.getElementById('I_Preferred_Custody_CFTA').style.display = 'inline'; -->
      document.getElementById('I_Volcker_Rule').style.display = 'inline';
     document.getElementById('I_W9_ERISA').style.display = 'inline';
      document.getElementById('I_AAM_LFG_Entity').style.display = 'inline';
			break;
	} 
}

/*function CIM_Individual_EMEA_AO(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Individual').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Individual').style.display = 'inline';
			break;
	} 
}

function CIM_Individual_IRA_EMEA_AO(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Managed_Citibank_IRA').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Individual').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Individuals').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Individual').style.display = 'inline';
			break;
	} 
}*/

/*function CIM_IRA_US(app_type) {
 
	switch (app_type){
		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Citibank_IRA').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
    
			break;
      
    case "tdp":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Citibank_IRA').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_W9_IRA').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Individual').style.display = 'inline';
			break;
	} 
}*/

/*function CIM_Trust_EMEA(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Trust').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
	} 
}

function CIM_Estate_EMEA(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
	} 
}


function CIM_Entity_EMEA(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
	} 
}

function CIM_Entity_ERISA_EMEA(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_EMEA_Application').style.display = 'none';
      document.getElementById('I_CIM_EMEA_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_TC').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Both').style.display = 'inline';
      document.getElementById('I_AAM_CIM_EMEA_Entities').style.display = 'inline';
      document.getElementById('I_W9W8_Individual').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_Entity').style.display = 'inline';
			break;
	} 
}

function CIM_Entity_EMEA_CCIFL(app_type) {
 
	switch (app_type){
		case "emea_portfolio":
      document.getElementById('selectPortfolio').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CIM_CCIFL_Application').style.display = 'inline';
      document.getElementById('I_CIM_CCIFL_TDP_Application').style.display = 'none';
	  document.getElementById('I_Canada_CCIFL_Discretionary_App_CIM').style.display = 'inline';
      document.getElementById('I_CIM_CCIFL_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
     
      document.getElementById('I_AAM_Canada_CCIFL').style.display = 'inline';
      document.getElementById('I_W9W8_Canada_CCIFL').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_CCIFL').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectPortfolio').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CIM_CCIFL_Application').style.display = 'inline';
      document.getElementById('I_CIM_CCIFL_TDP_Application').style.display = 'inline';
	  document.getElementById('I_Canada_CCIFL_Discretionary_App_CIM').style.display = 'none';
      document.getElementById('I_CIM_CCIFL_Admin_EMEA').style.display = 'inline';
      document.getElementById('I_CIM_EMEA_Account_Checklist').style.display = 'inline';
 
      document.getElementById('I_AAM_Canada_CCIFL').style.display = 'inline';
      document.getElementById('I_W9W8_Canada_CCIFL').style.display = 'inline';
      document.getElementById('I_IOS_CIM_EMEA_CCIFL').style.display = 'inline';
			break;
	} 
}*/

function I_Banking_Credit_Cards(app_type) {
	switch (app_type){
		case "Uhnwhnw":
       document.getElementById('selectUhnwhnw').checked = true;
      document.getElementById('selectLfgassociate').checked = false;
	  document.getElementById('selectYoungadult').checked = false;
      document.getElementById('selectFaq').checked = false;
	  document.getElementById('uhnw_hnw_creditcards').style.display = 'inline';
      document.getElementById('lfg_a_creditcard').style.display = 'none';
	  document.getElementById('young_adult_creditcards').style.display = 'none';
      document.getElementById('faq_creditcard').style.display = 'none';
	 
			break;
      
    case "Lfgassociate":
       document.getElementById('selectUhnwhnw').checked = false;
      document.getElementById('selectLfgassociate').checked = true;
	  document.getElementById('selectYoungadult').checked = false;
      document.getElementById('selectFaq').checked = false;
	  document.getElementById('uhnw_hnw_creditcards').style.display = 'none';
      document.getElementById('lfg_a_creditcard').style.display = 'inline';
	  document.getElementById('young_adult_creditcards').style.display = 'none';
      document.getElementById('faq_creditcard').style.display = 'none';
	  
			break;

	case "Youngadult":
       document.getElementById('selectUhnwhnw').checked = false;
      document.getElementById('selectLfgassociate').checked = false;
	  document.getElementById('selectYoungadult').checked = true;
      document.getElementById('selectFaq').checked = false;
	  document.getElementById('uhnw_hnw_creditcards').style.display = 'none';
      document.getElementById('lfg_a_creditcard').style.display = 'none';
	  document.getElementById('young_adult_creditcards').style.display = 'inline';
      document.getElementById('faq_creditcard').style.display = 'none';
		
		break;

	case "Faq":
       document.getElementById('selectUhnwhnw').checked = false;
      document.getElementById('selectLfgassociate').checked = false;
	  document.getElementById('selectYoungadult').checked = false;
      document.getElementById('selectFaq').checked = true;
	  document.getElementById('uhnw_hnw_creditcards').style.display = 'none';
      document.getElementById('lfg_a_creditcard').style.display = 'none';
	  document.getElementById('young_adult_creditcards').style.display = 'none';
      document.getElementById('faq_creditcard').style.display = 'inline';
	}
}


function Brokerage_Managed_Check(app_type){
  switch (app_type){
		case "dap":
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = true;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = false;
    
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none';
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'inline'; 
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'none';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'none';  
      
			break;
      
    case "fiduciary":
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = true;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = false;
    
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none'; 
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'inline'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'inline';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'none';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'none';  
      
			break;

	case "citiadvisor":
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = true;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = false;
    
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none'; 
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'inline'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'none';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'none';  
      
			break;

	case "umbrella":
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = true;
    
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned').style.display = 'none'; 
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';  
      
			break;
      
	}

}

function Brokerage_Managed_Check_IRA(app_type){
  switch (app_type){
		case "dap":
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = true;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = false;
   
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'inline'; 
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'none';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'none';  
      
			break;
      
    case "fiduciary":
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = true;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = false;
    
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'inline'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'inline';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'none';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'none';  
      
			break;

	case "citiadvisor":
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = true;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = false;
    
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'inline'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'none';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'none';  
      
			break;

	case "umbrella":
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = true;
    
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'inline';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'inline';  
      
			break;
      
	}

}

function reset_Brokerage_Managed_Apps(){
      //reset radio button
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = false;
      //reset Forms
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'none';  
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'none';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'none';  
}

function reset_Brokerage_Managed_Apps_IRA(){
      //reset radio button
      document.getElementById('Brokerage_Managed_DAP_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Fiduciary_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_CitiAdvisor_Checkbox').checked = false;
      document.getElementById('Brokerage_Managed_Umbrella_Checkbox').checked = false;
      //reset Forms
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
      //Umbrella
      document.getElementById('I_Managed_CGMI_General_App').style.display = 'none';
      document.getElementById('I_Umbrella_Product_Specific').style.display = 'none';  
}

function Brokerage_COD_Syndicate_Check(){
  if (document.getElementById('Brokerage_COD_Syndicate_Checkbox').checked){
      document.getElementById('I_Brokerage_COD_5130').style.display = 'inline';
      document.getElementById('I_Brokerage_COD_6600').style.display = 'inline'; 
      document.getElementById('I_Brokerage_COD_6601').style.display = 'inline';   
      document.getElementById('I_Brokerage_COD_6610').style.display = 'inline';   
      document.getElementById('I_Brokerage_COD_7610').style.display = 'inline';  
          
  }
  else{
      document.getElementById('I_Brokerage_COD_5130').style.display = 'none';
      document.getElementById('I_Brokerage_COD_6600').style.display = 'none'; 
      document.getElementById('I_Brokerage_COD_6601').style.display = 'none';   
      document.getElementById('I_Brokerage_COD_6610').style.display = 'none';   
      document.getElementById('I_Brokerage_COD_7610').style.display = 'none';
           
      
  }
}

function reset_Brokerage_COD_Syndicate_Docs(){
  //reset checkboxes
  document.getElementById('Brokerage_COD_Syndicate_Checkbox').checked=false;
  //reset Forms
  document.getElementById('I_Brokerage_COD_5130').style.display = 'none';
  document.getElementById('I_Brokerage_COD_6600').style.display = 'none'; 
  document.getElementById('I_Brokerage_COD_6601').style.display = 'none';   
  document.getElementById('I_Brokerage_COD_6610').style.display = 'none';   
  document.getElementById('I_Brokerage_COD_7610').style.display = 'none'; 
  
}


/*function CIM_Entity_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/

/*function CIM_Entity_ERISA_US(app_type) {
 
	switch (app_type){
		case "cra":
      document.getElementById('selectCRA').checked = true;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'inline';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'inline';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'inline';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'none';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "playback":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = true;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'inline';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;

		case "cim":
      document.getElementById('selectCIM').checked = true;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'inline';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
     document.getElementById('I_CIM_Admin').style.display = 'inline';
	   document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "verbal":
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectVerbal').checked = true;
      document.getElementById('selectTDP').checked = false;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'inline';
			document.getElementById('I_Managed_General_App').style.display = 'none';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'none';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'none';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'none';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'inline';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'none';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'inline';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
      
    case "tdp":
      document.getElementById('selectCRA').checked = false;
      document.getElementById('selectPlayback').checked = false;
      document.getElementById('selectCIM').checked = false;
      document.getElementById('selectVerbal').checked = false;
      document.getElementById('selectTDP').checked = true;
      
			document.getElementById('I_CRA_Application').style.display = 'none';
      document.getElementById('I_CRA_Terms_Conditions').style.display = 'none';
document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      document.getElementById('I_Banking_TC_Amendments').style.display = 'none';
      
      document.getElementById('I_CIM_Playback').style.display = 'none';
      document.getElementById('I_CIM_Verbal').style.display = 'none';
			document.getElementById('I_Managed_General_App').style.display = 'inline';
      document.getElementById('I_CIM_Product_Specific').style.display = 'none';
      document.getElementById('I_CIM_US_TDP_Application').style.display = 'inline';
      document.getElementById('I_Managed_ERISA_Disclosure').style.display = 'inline';
      document.getElementById('I_CIM_Terms_Conditions').style.display = 'inline';
      document.getElementById('I_Managed_Organizational_Agreement').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed_CIM').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Unsigned_CIM').style.display = 'none';
      
      document.getElementById('I_CIM_Admin').style.display = 'inline';
	    document.getElementById('I_CIM_Fixed_Income').style.display = 'none';
      document.getElementById('I_CIM_Fixed_Income_TDP').style.display = 'inline';
      document.getElementById('I_W9W8_Entity').style.display = 'inline';
      document.getElementById('I_Managed_Exceptions').style.display = 'none';
      document.getElementById('I_IOS_Entity').style.display = 'inline';
			break;
	} 
}*/
function I_Banking_Applications_Received(app_type) {
	switch (app_type){
	
  case "Current_CRA":
    document.getElementById('selectCurrent_CRA').checked = true;
    document.getElementById('selectOneGeneration_CRA').checked = false;
	  document.getElementById('selectOld_CRA').checked = false;
	  document.getElementById('selectCurrent').checked = false;
    document.getElementById('selectOneGeneration').checked = false;
	  document.getElementById('selectOld').checked = false;
    
	  document.getElementById('app_current_CRA').style.display = 'inline';
	  document.getElementById('app_current').style.display = 'none';    
	  document.getElementById('app_one_generation_CRA').style.display = 'none';
    document.getElementById('app_one_generation').style.display = 'none';
	  document.getElementById('app_old_CRA').style.display = 'none';
	  document.getElementById('app_old').style.display = 'none';
    break;
    
 case "OneGeneration_CRA":
    document.getElementById('selectCurrent_CRA').checked = false;
    document.getElementById('selectOneGeneration_CRA').checked = true;
	  document.getElementById('selectOld_CRA').checked = false;
	  document.getElementById('selectCurrent').checked = false;
    document.getElementById('selectOneGeneration').checked = false;
	  document.getElementById('selectOld').checked = false;
    
	  document.getElementById('app_current_CRA').style.display = 'none';
	  document.getElementById('app_current').style.display = 'none';    
	  document.getElementById('app_one_generation_CRA').style.display = 'inline';
    document.getElementById('app_one_generation').style.display = 'none';
	  document.getElementById('app_old_CRA').style.display = 'none';
	  document.getElementById('app_old').style.display = 'none';
    break;

	case "Old_CRA":
    document.getElementById('selectCurrent_CRA').checked = false;
    document.getElementById('selectOneGeneration_CRA').checked = false;
	  document.getElementById('selectOld_CRA').checked = true;
	  document.getElementById('selectCurrent').checked = false;
    document.getElementById('selectOneGeneration').checked = false;
	  document.getElementById('selectOld').checked = false;
    
	  document.getElementById('app_current_CRA').style.display = 'none';
	  document.getElementById('app_current').style.display = 'none';    
	  document.getElementById('app_one_generation_CRA').style.display = 'none';
    document.getElementById('app_one_generation').style.display = 'none';
	  document.getElementById('app_old_CRA').style.display = 'inline';
	  document.getElementById('app_old').style.display = 'none';
     break;
	 
	 
	 case "Current":
    document.getElementById('selectCurrent_CRA').checked = false;
    document.getElementById('selectOneGeneration_CRA').checked = false;
	  document.getElementById('selectOld_CRA').checked = false;
	  document.getElementById('selectCurrent').checked = true;
    document.getElementById('selectOneGeneration').checked = false;
	  document.getElementById('selectOld').checked = false;
    
	  document.getElementById('app_current_CRA').style.display = 'none';
	  document.getElementById('app_current').style.display = 'inline';    
	  document.getElementById('app_one_generation_CRA').style.display = 'none';
    document.getElementById('app_one_generation').style.display = 'none';
	  document.getElementById('app_old_CRA').style.display = 'none';
	  document.getElementById('app_old').style.display = 'none';
    break;
    
 case "OneGeneration":
    document.getElementById('selectCurrent_CRA').checked = false;
    document.getElementById('selectOneGeneration_CRA').checked = false;
	  document.getElementById('selectOld_CRA').checked = false;
	  document.getElementById('selectCurrent').checked = false;
    document.getElementById('selectOneGeneration').checked = true;
	  document.getElementById('selectOld').checked = false;
    
	  document.getElementById('app_current_CRA').style.display = 'none';
	  document.getElementById('app_current').style.display = 'none';    
	  document.getElementById('app_one_generation_CRA').style.display = 'none';
    document.getElementById('app_one_generation').style.display = 'inline';
	  document.getElementById('app_old_CRA').style.display = 'none';
	  document.getElementById('app_old').style.display = 'none';
    break;

	case "Old":
    document.getElementById('selectCurrent_CRA').checked = false;
    document.getElementById('selectOneGeneration_CRA').checked = false;
	  document.getElementById('selectOld_CRA').checked = false;
	  document.getElementById('selectCurrent').checked = false;
    document.getElementById('selectOneGeneration').checked = false;
	  document.getElementById('selectOld').checked = true;
    
	  document.getElementById('app_current_CRA').style.display = 'none';
	  document.getElementById('app_current').style.display = 'none';    
	  document.getElementById('app_one_generation_CRA').style.display = 'none';
    document.getElementById('app_one_generation').style.display = 'none';
	  document.getElementById('app_old_CRA').style.display = 'none';
	  document.getElementById('app_old').style.display = 'inline';
     break;
	}
}

function I_Banking_Applications_Received_Current(app_type) {
	switch (app_type){
	
  case "CurrentCitifolio":
    document.getElementById('selectCurrentCitiFolio').checked = true;
    document.getElementById('selectCurrentCRA').checked = false;
	  
    document.getElementById('CurrentCitifolio').style.display = 'inline';
    document.getElementById('CurrentCRA').style.display = 'none';
	break;
	
    case "CurrentCRA":
    document.getElementById('selectCurrentCitiFolio').checked = false;
    document.getElementById('selectCurrentCRA').checked = true;
	  
    document.getElementById('CurrentCitifolio').style.display = 'none';
    document.getElementById('CurrentCRA').style.display = 'inline';
	}
}
function I_Banking_Applications_Received_OneGeneration(app_type) {
	switch (app_type){
	
  case "OneGenCitifolio":
    document.getElementById('selectOneGenCitiFolio').checked = true;
    document.getElementById('selectOneGenCRA').checked = false;
	  
    document.getElementById('OneGenCitifolio').style.display = 'inline';
    document.getElementById('OneGenCRA').style.display = 'none';
	break;
	
    case "OneGenCRA":
    document.getElementById('selectOneGenCitiFolio').checked = false;
    document.getElementById('selectOneGenCRA').checked = true;
	  
    document.getElementById('OneGenCitifolio').style.display = 'none';
    document.getElementById('OneGenCRA').style.display = 'inline';
	}
}


//Managed Docs for Banking - tp
function Managed_Resolution_Check (type){
   switch (type){
   
   case "Corporation":
    CallAjax("/noam/onboarding/products/includes/I_Managed_Organizational_Agreement_Corporation.htm","#I_Managed_Organizational_Agreement");	
    break;
  
   case "General Partnership":
    CallAjax("/noam/onboarding/products/includes/I_Managed_Organizational_Agreement_Corporation.htm","#I_Managed_Organizational_Agreement");	
    break;
    
   case "Limited Partnership":
    CallAjax("/noam/onboarding/products/includes/I_Managed_Organizational_Agreement_Corporation.htm","#I_Managed_Organizational_Agreement");	
    break;
    
   case "LLC":
   CallAjax("/noam/onboarding/products/includes/I_Managed_Organizational_Agreement_Corporation.htm","#I_Managed_Organizational_Agreement");	
    break;
    
    case "Sole Proprietorship":
    CallAjax("/noam/onboarding/products/includes/I_Managed_Organizational_Agreement_Sole.htm","#I_Managed_Organizational_Agreement");	
    break;
    
    case "Unincorporated Association":
    CallAjax("/noam/onboarding/products/includes/I_Managed_Organizational_Agreement_Corporation.htm","#I_Managed_Organizational_Agreement");	
    break; 
    
   }
}

//Managed Apps converted to brokerage - tp
function Brokerage_Check (type){
   switch (type){
   
   case "Corporation":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_2105.htm","#I_Managed_Organizational_Agreement");
    break;
  
   case "General Partnership":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_2104.htm","#I_Managed_Organizational_Agreement");
    break;
    
   case "Limited Partnership":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_2104.htm","#I_Managed_Organizational_Agreement");
    break;
    
   case "LLC":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_5466.htm","#I_Managed_Organizational_Agreement");
    break;
    
    case "Sole Proprietorship":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_3164.htm","#I_Managed_Organizational_Agreement");
    break;
    
    case "Unincorporated Association":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_5277.htm","#I_Managed_Organizational_Agreement");
    break; 
	
	case "ERISA":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_5502.htm","#I_Managed_Organizational_Agreement");
    break; 
	
	case "Estate":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_5501.htm","#I_Managed_Organizational_Agreement");
    break; 
	
	case "Trust":
    CallAjax("/noam/onboarding/products/includes/I_Brokerage_5036.htm","#I_Managed_Organizational_Agreement");
    break; 
    
    
    
   }
}



function Brokerage_Managed_Load_Documents(app_type){
  switch (app_type){
		case "Dynamic Allocation Portfolios (DAP)":   
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'inline'; 
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
			break;
      
    case "Fiduciary Services Manager Program":    
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'inline'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'inline';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
			break;

	case "Citi Advisor Agreement":
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'inline'; 
			break;      
	}

}


function Brokerage_Managed_Load_Documents_IRA(app_type){
  switch (app_type){
		case "Dynamic Allocation Portfolios (DAP)":   
      document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'inline'; 
      document.getElementById('I_DAP_Proposal').style.display = 'inline';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
			break;
      
    case "Fiduciary Services Manager Program":   
      document.getElementById('I_Brokerage_5143').style.display = 'inline'; 
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'inline'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'inline';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'inline';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'none'; 
			break;

	case "Citi Advisor Agreement":
      document.getElementById('I_Brokerage_5143').style.display = 'inline';
      document.getElementById('I_Relationship_Team_Page_Signed').style.display = 'inline';
      //DAP
      document.getElementById('I_Brokerage_Managed_6831').style.display = 'none'; 
      document.getElementById('I_DAP_Proposal').style.display = 'none';
      //Fiduciary
      document.getElementById('I_Brokerage_Managed_9841').style.display = 'none'; 
      document.getElementById('I_Brokerage_Managed_5699').style.display = 'none';  
      document.getElementById('I_Brokerage_Managed_9843').style.display = 'none';
	    //Citi Advisor
      document.getElementById('I_Brokerage_Managed_6603').style.display = 'inline'; 
			break; 
	}

}
function I_Banking_Checking_Plus(app_type) {
	switch (app_type){
	
  case "Transmittal":
    document.getElementById('selectTransmittal').checked = true;
    document.getElementById('selectCitiFolio').checked = false;
	  
    document.getElementById('ShowTransmittal').style.display = 'inline';
    document.getElementById('ShowCitiFolio').style.display = 'none';
	break;
	
    case "CitiFolio":
    document.getElementById('selectTransmittal').checked = false;
    document.getElementById('selectCitiFolio').checked = true;
	  
    document.getElementById('ShowTransmittal').style.display = 'none';
    document.getElementById('ShowCitiFolio').style.display = 'inline';
	}
}

function Banking_Business_Cards(answer){
  
  var service;
  var size;
  var age;
  var location; 
 
 if(answer=="Merchantservices"){
	
      document.getElementById('selectCreditcards').checked = false;
	  document.getElementById('selectMerchantservices').checked = true;
      document.getElementById('selectPayroll').checked = false;
	  document.getElementById('selectCC_size_small').checked = false;
      document.getElementById('selectCC_size_large').checked = false;
      //document.getElementById('selectCC_age_below3years').checked = false;
      //document.getElementById('selectCC_age_above3years').checked = false;
	  document.getElementById('select_joint_and_several_dom').checked = false;
	  document.getElementById('select_joint_several_globe').checked = false;
	  document.getElementById('select_corp_liability').checked = false;
	  //document.getElementById('selectCC_location_US').checked = false;
      //document.getElementById('selectCC_location_non_US').checked = false;

      document.getElementById('cc_q_size').style.display = 'none';
      document.getElementById('cc_q_select_app').style.display = 'none';
      //document.getElementById('cc_q_location').style.display = 'none';
	  // Merchant services 
      document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'inline';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	   document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'none';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';

	service = false;
	
	} else if (answer=="Payroll"){
	
      document.getElementById('selectCreditcards').checked = false;
	  document.getElementById('selectMerchantservices').checked = false;
      document.getElementById('selectPayroll').checked = true;
	  
	  document.getElementById('selectCC_size_small').checked = false;
      document.getElementById('selectCC_size_large').checked = false;
      //document.getElementById('selectCC_age_below3years').checked = false;
      //document.getElementById('selectCC_age_above3years').checked = false;
	  document.getElementById('select_joint_and_several_dom').checked = false;
	  document.getElementById('select_joint_several_globe').checked = false;
	  document.getElementById('select_corp_liability').checked = false;
	  //document.getElementById('selectCC_location_US').checked = false;
      //document.getElementById('selectCC_location_non_US').checked = false;
      
	  document.getElementById('cc_q_size').style.display = 'none';
      document.getElementById('cc_q_select_app').style.display = 'none';
      //document.getElementById('cc_q_location').style.display = 'none';
	   // Merchant services 
      document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'inline';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'none';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      
	service = false;
	
	} else if (answer=="Creditcards"){
	
      document.getElementById('selectCreditcards').checked = true;
	  document.getElementById('selectMerchantservices').checked = false;
      document.getElementById('selectPayroll').checked = false;

	  document.getElementById('selectCC_size_small').checked = false;
      document.getElementById('selectCC_size_large').checked = false;
      //document.getElementById('selectCC_age_below3years').checked = false;
      //document.getElementById('selectCC_age_above3years').checked = false;
	  document.getElementById('select_joint_and_several_dom').checked = false;
	  document.getElementById('select_joint_several_globe').checked = false;
	  document.getElementById('select_corp_liability').checked = false;
	  
	  
	  //document.getElementById('selectCC_location_US').checked = false;
      //document.getElementById('selectCC_location_non_US').checked = false;
      document.getElementById('cc_q_size').style.display = 'inline';
      document.getElementById('cc_q_select_app').style.display = 'none';
      //document.getElementById('cc_q_location').style.display = 'none';
	   // Merchant services 
      document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	   document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'none';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
	  
     
	service = true;
		}
	}
	
  function selectCC_Company(answer){
  
    if(answer=="small"){
      document.getElementById('selectCC_size_small').checked = true;
      document.getElementById('selectCC_size_large').checked = false;
      //document.getElementById('selectCC_age_below3years').checked = false;
      //document.getElementById('selectCC_age_above3years').checked = false;
	  document.getElementById('select_joint_and_several_dom').checked = false;
	  document.getElementById('select_joint_several_globe').checked = false;
	  document.getElementById('select_corp_liability').checked = false;
	  //document.getElementById('selectCC_location_US').checked = false;
      //document.getElementById('selectCC_location_non_US').checked = false;
	  
      document.getElementById('cc_q_select_app').style.display = 'inline'; 
      //document.getElementById('cc_q_location').style.display = 'none';
	   // Merchant services 
      document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'none';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'block';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      
      size = true;
      
    } else {
      document.getElementById('selectCC_size_small').checked = false;
      document.getElementById('selectCC_size_large').checked = true;
      //document.getElementById('selectCC_age_below3years').checked = false;
      //document.getElementById('selectCC_age_above3years').checked = false;
	  document.getElementById('select_joint_and_several_dom').checked = false;
	  document.getElementById('select_joint_several_globe').checked = false;
	  document.getElementById('select_corp_liability').checked = false;
	  //document.getElementById('selectCC_location_US').checked = false;
      //document.getElementById('selectCC_location_non_US').checked = false;
	  
      document.getElementById('cc_q_select_app').style.display = 'none';
      //document.getElementById('cc_q_location').style.display = 'none';
	   // Merchant services 
      document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'inline';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	   document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'none';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'none';
	  
      
      size = false;
    }
  } 
  
  
  function select_application(answer){
    if(answer=="jslDom"){
	  document.getElementById('select_joint_and_several_dom').checked = true;
	  document.getElementById('select_joint_several_globe').checked = false;
	  document.getElementById('select_corp_liability').checked = false;
	  
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'inline';
	   document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'none';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
	  
	  } else if (answer=="jslGlobe") {
		  
	  document.getElementById('select_joint_and_several_dom').checked = false;
	  document.getElementById('select_joint_several_globe').checked = true;
	  document.getElementById('select_corp_liability').checked = false;
	  
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	   document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'inline';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
	  		  
	} else if (answer=="clDomGlobe") {
		
	  document.getElementById('select_joint_and_several_dom').checked = false;
	  document.getElementById('select_joint_several_globe').checked = false;
	  document.getElementById('select_corp_liability').checked = true;
	  
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'inline';;
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	   document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'inline';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'inline';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'inline';
		  
		  
		  }
  }
  
  //may be deleeted
  function selectCC_age(answer){
    if(answer=="above3"){
     document.getElementById('selectCC_age_below3years').checked = false;
      document.getElementById('selectCC_age_above3years').checked = true;
	  //document.getElementById('selectCC_location_US').checked = false;
      //document.getElementById('selectCC_location_non_US').checked = false;
	  
      //document.getElementById('cc_q_location').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	   document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'inline';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'none';
	  
      
      age = false;
      
    } else {
      document.getElementById('selectCC_age_below3years').checked = true;
      document.getElementById('selectCC_age_above3years').checked = false;
	  //document.getElementById('selectCC_location_US').checked = false;
      //document.getElementById('selectCC_location_non_US').checked = false;
	  
      //document.getElementById('cc_q_location').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'none';
      document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      age = true;
    }
  } 
  
  function selectCC_Location(answer){
    if(answer=="us" ){
	  //document.getElementById('selectCC_location_US').checked = true;
      //document.getElementById('selectCC_location_non_US').checked = false;
	  
      document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'none';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';
      
    
    } else {
      //document.getElementById('selectCC_location_US').checked = false;
      //document.getElementById('selectCC_location_non_US').checked = true;
	  
      document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Rep').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Referrals_Website').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Merchant_Services_Onepager').style.display = 'none';
	  // Payroll
	  document.getElementById('I_Business_Cards_Payroll_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_Payroll_Service_Overview').style.display = 'none';
	  // Middle Market
	  document.getElementById('I_Business_Cards_Middle_Market_Guideline').style.display = 'none';
	  document.getElementById('I_Business_Cards_Middle_Market_Referral_Wizard').style.display = 'none';
	  // Small Business 
	  document.getElementById('I_Business_Cards_JS_Global_Title').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Domestic_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Title').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_What_Is').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Domestic_Type').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_TY').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_TY_AAdvantage').style.display = 'none';
	  document.getElementById('I_Business_Cards_Product_Overview').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Document_Request').style.display = 'inline';
	  document.getElementById('I_Business_Cards_Corporate_Document_Request').style.display = 'none';
	  document.getElementById('I_Business_Cards_Corporate_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Global_Application').style.display = 'inline';
	  document.getElementById('I_Business_Cards_JS_Domestic_Application').style.display = 'none';
	  document.getElementById('I_Business_Cards_JS_Dom_App').style.display = 'none';
	  document.getElementById('I_Business_Cards_Internal_Use').style.display = 'inline';
	  document.getElementById('I_Small_Business_Table_Business_Cards').style.display = 'none';
	  document.getElementById('I_CRA_Citifolio_T_C').style.display = 'none';

    }
  } 