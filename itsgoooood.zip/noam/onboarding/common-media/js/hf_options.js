function HF_Custom(app_type) {
 
	switch (app_type){
		case "Discretionary":
      document.getElementById('selectDiscretionary').checked = true;
      document.getElementById('selectNon-Discretionary').checked = false;
      
	document.getElementById('I_HF_Discretionary_Application').style.display = 'inline';
      document.getElementById('I_HF_Discretionary_TC').style.display = 'inline';
      document.getElementById('I_HF_Discretionary_Adv_Part2').style.display = 'inline';
      
	 document.getElementById('I_HF_NonDiscretionary_Application').style.display = 'none';
      document.getElementById('I_HF_NonDiscretionary_TC').style.display = 'none';
	  document.getElementById('I_HF_NonDiscretionary_Adv_Part2').style.display = 'none';
      document.getElementById('I_HF_NonDiscretionary_Admin').style.display = 'inline';
	  document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';
	  document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';
	  
	  
			break;
      
    case "Non-Discretionary":
      document.getElementById('selectDiscretionary').checked = false;
      document.getElementById('selectNon-Discretionary').checked = true;
      
	document.getElementById('I_HF_Discretionary_Application').style.display = 'none';
      document.getElementById('I_HF_Discretionary_TC').style.display = 'none';
      document.getElementById('I_HF_Discretionary_Adv_Part2').style.display = 'none';
	  
    document.getElementById('I_HF_NonDiscretionary_Application').style.display = 'inline';
      document.getElementById('I_HF_NonDiscretionary_TC').style.display = 'inline';
	  document.getElementById('I_HF_NonDiscretionary_Adv_Part2').style.display = 'inline';
      document.getElementById('I_HF_NonDiscretionary_Admin').style.display = 'inline';
	  document.getElementById('I_W9W8_Individual').style.display = 'inline';
	  document.getElementById('I_Tax_Attestation1').style.display = 'inline'; 
	  document.getElementById('I_Managed_Exceptions').style.display = 'inline';
	  document.getElementById('I_IOS_Individual').style.display = 'inline';
	  document.getElementById('I_Volcker_Rule').style.display = 'inline';

			break;
	} 
}