//-----------------------------
// list-rss.js 
// Owner: Paul Gueli
// Date: 8/19/2009
// Notes: Do Not Edit
//-----------------------------

var asiaNewsXML 	= "/rss/announcements-asia.xml";
var emeaNewsXML 	= "/rss/announcements-emea.xml";
var latAmNewsXML 	= "/rss/announcements-latAm.xml";
var noAmNewsXML 	= "/rss/announcements-noAm.xml";
var globalNewsXML 	= "/rss/announcements-main.xml";
var globalAdvXML 			= "/adv/adv.xml";
var globalAdvBioURLBase 	= "/adv/bios/";

//PUBLICATIONS
var globalPublicationsXML = "/rss/investments/publications_p.xml";
var globalPublicationsURL = '/investments/quadrant/';

var asiaHomepage 	= "http://portal.citiprivatebank.asia.citigroup.net/ap_home.htm";
var emeaHomepage 	= "http://www.citigroup.net/privbank/europe/";
var latAmHomepage 	= "http://portal.privatebank.citigroup.net/";
var noAmHomepage 	= "/noam/";
var globalHomepage 	= "/";

//var blogJSP 		= "http://cpbswz4radda.nam.nsroot.net:7001/BlogPost/JanesBlogServlet";
var blogJSP 		= "https://portal.privatebank.citigroup.net/BlogPost/JanesBlogServlet";
var globalBlogXML	= '/rss/blogs.xml';
var globalBlogURL	= '/blog/';
var commentEmail	= "";

var gdURL 			= "http://gdir.nam.nsroot.net/globaldir/gdir_resultdetail.asp";
var adURL 			= "https://personal.collaborationtools.consumer.citigroup.net/mysite/Person.aspx";
var jsonURL 		= "/rss/soecache_prod_intranet.txt";
var mainContactFile = "/rss/contactinfo.xml";
var viewRosterIcon  = "/common-media/images/icons/view_banker_roster.gif";

if(!window.cpbns){
    window.cpbns={};
}




function generateList(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, numItems)
{
	var html = '<ul>';
	var count = 0;
	var linkP = "";
	
	if (showFirstItem != 0){
			numItems = numItems - 1;
	}
	

	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(){
			
			var $item = $(this);
			var description = $item.find('description').text();
			var linkP = $item.find('link').text();
			//alert(description);
				
			if ((showFirstItem == 0)&&(count == 0)){
			}else{
				html += "<li>";
				$(this).find("image").each(function(){
					// IMAGE 	
					if (showImage){	html += "<a href='" + linkP + "'><img class='image-main' src='" + getNodeText(this) + "'></a>"; }
				}).end().find("link").each(function(){
						//linkP = getNodeText(this);
						html += "<div class='title'><a href='" + linkP +"'>";
				}).end().find("title").each(function(){
						html += getNodeText(this) + "</a></div>";
				}).end().find("pubDate").each(function(){
					// DATE 	
					if (showDate){	html += "<div class='date'>" + getNodeText(this) + "</div>"; }
				}).end().find("description").each(function(){
					if ((showDesc)&&(description)){	html += "<div class='description'>" + description +"</div>"; }
				});
				html += "<div class='clear'></div></li>";
			}


			if (count == numItems){ return false; }				
			count = count + 1;


		});
		html += "</ul>";
		
		$(divID).html(html).slideDown("slow");
		
	});	

} 








function generateListV2(divID, params)
{

	

	
	//DEFAULTS
	var sys = new Object();
	sys.showDate = 1;
	sys.showDesc = 1;
	sys.showImage = 1;
//    sys.showAuthorImage = 1;
	sys.showFirstItem = 1; 
	sys.showCategory = 1; 
	sys.showSocial = 1;
	sys.showMoreButton = 1;
	sys.numItems = 5; 
	sys.categoryTitle = new Array;
	sys.showAuthor = 0;
	sys.authorName = "";
	sys.showFilter = 0;
	sys.filterCategoryOptions = "";
	sys.divID = divID;
	sys.startingNum = 0;
	sys.callBackFunction = "";

	
	//OPTIONS
	if (params.showFilter != null) sys.showFilter = params.showFilter;
	if (params.showDate != null) sys.showDate = params.showDate;
	if (params.showDesc != null) sys.showDesc = params.showDesc;
	if (params.showImage != null) sys.showImage = params.showImage;
	if (params.showAuthorImage != null) sys.showAuthorImage = params.showAuthorImage;
	if (params.showMoreButton != null) sys.showMoreButton = params.showMoreButton; 
	if (params.showFirstItem != null) sys.showFirstItem = params.showFirstItem; 
	if (params.showCategory != null) sys.showCategory = params.showCategory; 
	if (params.showSocial != null) sys.showSocial = params.showSocial; 
	if (params.numItems) sys.numItems = params.numItems; 
	if (params.categoryTitle != null){
		if (params.categoryTitle.length > 0) sys.categoryTitle	= params.categoryTitle;
	}
	if (params.showAuthor) sys.showAuthor = params.showAuthor;
	if (params.authorName) sys.authorName = params.authorName;
	if (params.xmlFile != null) sys.xmlFile = params.xmlFile;
	if (params.filterCategoryOptions != null) sys.filterCategoryOptions = params.filterCategoryOptions;
	if (params.callBackFunction != null) sys.callBackFunction = params.callBackFunction;
	
	
	var catArray = new Array();
	var moreHTML = "";
	if (sys.showMoreButton)	moreHTML = "<div id=\"moreButton\"><a href=\"javascript:void(0);\">Show More...</a></div>";

	
	
	//SHOW FILTER
	var filterHTML = "";
	
	if (sys.showFilter){
		
		filterHTML += 	'<div class="filter-wrapper">' ;
		filterHTML += 	'<span class="ui-icon-subs">';
		filterHTML += 	'  	<a class="icon icon-filterNotAppl" href="javascript:void(0);"></a>';
		filterHTML += 	'       <div class="filterBlock"><div class="filter">';
		filterHTML += 	'			<ul>';
		filterHTML += 	'           <li><form id="filterForm" name="filterForm">';
		filterHTML += 	'               <ul>';
		
		
		//LOOP THROUGH filterCategory
		for (x in sys.filterCategoryOptions)
		{
			filterHTML += 	'               <li><input type="checkbox" id="'+sys.filterCategoryOptions[x]+'" value="'+sys.filterCategoryOptions[x]+'" name="categories"><label>'+sys.filterCategoryOptions[x]+'</label></li>';
		}
		filterHTML += 	'               </ul></form>';                                    

		filterHTML += 	'           </li>';
		filterHTML += 	'           </ul>';
        
		filterHTML += 	'           <div class="filter-submit">';
		filterHTML += 	'               <a id="filter-cancel" href="javascript:void(0);" class="btnFlexible gray"><span>Cancel</span></a>';
		filterHTML += 	'               <a id="filter-apply" href="javascript:void(0);" class="btnFlexible"><span>Apply</span></a>';
		filterHTML += 	'			</div>';
		filterHTML += 	'   	</div></div>';
		

		
		
		filterHTML += 	'   </span>';
		filterHTML += 	'	<span id="filter-name">';
		if ((sys.categoryTitle == "") || (sys.categoryTitle == "")){ filterHTML += 	'All';}
		else  filterHTML += sys.categoryTitle;
		filterHTML += 	'	</span>';
		filterHTML += 	'</div>';
		filterHTML += 	'<div class="clear"></div>';
	
	}
	//SHOW FILTER
	

	
	$(sys.divID).html(filterHTML + " <ul id='v2List'></ul>" + moreHTML);
	
	$("#moreButton a").click(function() {
		//console.log("getContentAndAppend();");
		getContentAndAppend();												   
	});
	
	
	
	
	if (sys.showFilter){
		
		//alert(sys.showFilter);
		var mouse_is_inside = false;
		var filter_open = false;
		   
		$('.filter ul').hover(function(){ 
			mouse_is_inside=true; 
			//console.log(mouse_is_inside);
		}, function(){ 
			mouse_is_inside=false; 
			//console.log(mouse_is_inside);
		});

		$('a.icon').hover(function(){ 
			mouse_is_inside=true; 
			//console.log(mouse_is_inside);
		}, function(){ 
			mouse_is_inside=false; 
			//console.log(mouse_is_inside);
		});

		$(".filter-wrapper a.icon").click(function(event) {
												   event.stopPropagation();
			//console.log("clicked button");	
			
			mouse_is_inside=true;
			if 	(filter_open){
				//alert("c");
				//$(this).parent().find(".filter").hide();
				$(".filterBlock").hide();
				filter_open=false;
			}else{
				$(this).parent().parent().find(".filterBlock").show();
				filter_open=true;
			}
		});

		
		$("body").click(function(){
								 
				if (filter_open){				 
				   $('.filterBlock').hide();
				}
				
			/*	if(! mouse_is_inside){
				alert("1");
				//console.log("mouse_is_inside: "+mouse_is_inside + " : hiding filter -- filter_open:" +filter_open);
				$('.filterBlock').hide();
				filter_open=false;
			}
			*/
		});		
		
		$('.filter-wrapper').click(function(event){
			event.stopPropagation();
	   });
		
		
		$('#filter-cancel').click(function() {
			$(".filterBlock").hide();
			filter_open=false;
		});	
	
		
		
		
		
		$(divID+ ' #filter-apply').click(function() {
			applyFilter();
		});	

	
	
		function applyFilter(){
	
			params.categoryTitle.length = 0;
			//console.log("clicked apply filter");
			
			$(divID +' input').each(function() {
				
				if ($(this).attr('checked')){
					var par = $(this).attr("value");
					if (par == "All"){
						params.categoryTitle.length = 0;
						return false;
					}else{
						params.categoryTitle.push(par);
					}
					
				}
			});
	
			generateListV2(divID, params);
	
		}
	
	
	} //end IF SHOW FILTER
	
	

	
	
	
	
	
	
	var itemArr = new Array();

	getContentAndAppend();
	

	
	
	
	
	
	
	function getContentAndAppend(){
	
		var count = 1;
		var generalCount = 1;
		itemArr = new Array();
		
		
		$.get(sys.xmlFile, function(xml){
				
				$("item", xml).each(function(){
					
					
					//console.log("checking || generalCount: "+ generalCount + " - count: " + count + " - startingNum: " + sys.startingNum + " - numItems: " + sys.numItems);
						
					
						//START AT STARING NUMBER	
						if (generalCount >= sys.startingNum){
					
									var $item = $(this);
									var story = new Object();
									var itemCatArray = new Array();
									var itemAuthorArray = new Array();
									var itemMatch = 0;
						
									story.itemDesc	 		= $item.find('description').text();
									story.itemLink 			= $item.find('link').text();
									story.itemTitle 		= $item.find('title').text();
									story.itemPubdate 		= $item.find('pubDate').text();
									//story.imageSub		= $item.find('image-sub').text();
									//story.imageMain		= $item.find('image-main').text();			
									story.itemImage			= $item.find('image').text();			
								
									//CATEGORIES
									$item.find('category').each(function(){
										itemCatArray.push($(this).text());
									});
									story.itemCatArray = itemCatArray;

									//AUTHORS
									$item.find('author').each(function(){
										itemAuthorArray.push($(this).text());
									});
									story.itemAuthorArray = itemAuthorArray;


									/* IF ITEM MATCHED *******************************************************************/	
									for (x in itemCatArray){
										for ( var i=0, len=sys.categoryTitle.length; i<len; ++i ){
											if (itemCatArray[x] == sys.categoryTitle[i]) { 
												itemMatch = 1;
											} //end if
										} //end for
									}
									for (x in itemAuthorArray){
										if (itemAuthorArray[x] == sys.authorName) { 
											itemMatch = 1;
										} //end if
									}									
									
									
									if ( ((sys.categoryTitle == null) || (sys.categoryTitle == "")) && ((sys.authorName == null) || (sys.authorName == "")) )itemMatch = 1;

									
									
									/* IF ITEM MATCHED *******************************************************************/	
									
									
										
									//Add to arr is matched
									if (itemMatch == 1){
										itemArr.push(story);
										
										if (count == sys.numItems){ 
											return false;
										}				
										//console.log("generalCount: "+ generalCount + " - count: " + count + " - numItems: " + sys.numItems);
										count = count + 1;
									}//end if matched
									/* IF ITEM MATCHED ************************/		
					
							
						}
						generalCount = generalCount + 1;
							
					
				}); //END EACH
				
				sys.startingNum = generalCount + 1;
				// OUTPUT -----------
				genOutput();
				
				
			}); //END GET	
			
			
		
		} //end fucntion getContentAndAppend
		
		
		
		




	// OUTPUT----------------------------------------------------------------------------
	function genOutput(){
		
		
		for (x in itemArr)
		{
			if (x == 0) classFirst = "class='first'";
			else classFirst = "";

			var storyHTML	= 		"<li "+classFirst+">";
				storyHTML	+= 		"<div class='hd'>";
				storyHTML	+= 		"	<div class=\"title\"><a href=\""+itemArr[x].itemLink+"\">"+itemArr[x].itemTitle+"</a></div>";
				if (sys.showDate) 	storyHTML	+= 		"	<div class=\"date\">"+itemArr[x].itemPubdate+"</div>";
				
				if (sys.showAuthor){
					var itemAuthorHTML = "";
					for (j in itemArr[x].itemAuthorArray){
						if (j != 0) itemAuthorHTML += ", ";
						itemAuthorHTML += "<a href='?author=" + itemArr[x].itemAuthorArray[j] + "'>"+itemArr[x].itemAuthorArray[j] + "</a>";
					}
					itemAuthorHTML = "Author: "+itemAuthorHTML;
				 	storyHTML	+= 		"	<div class='author'>by "+itemAuthorHTML+"</div>";
				}
				storyHTML	+= 		"</div>"; //
				
				if (sys.showImage) 		storyHTML	+=		"<div class='story-image'><img src='"+itemArr[x].itemImage+"'></div>";		
				if (sys.showDesc) 		storyHTML	+= 		"	<div class=\"description\">"+itemArr[x].itemDesc+"</div>";
				if (sys.showCategory){
					var itemCategoryHTML = "";
					for (j in itemArr[x].itemCatArray){
						if (j != 0) itemCategoryHTML += ", ";
						itemCategoryHTML += "<a href='?cat=" + itemArr[x].itemCatArray[j] + "'>"+itemArr[x].itemCatArray[j] + "</a>";
					}
					itemCategoryHTML = "Category: "+itemCategoryHTML;
					storyHTML	+= 		"	<div class=\"category\">"+itemCategoryHTML+"</div>";
				}
				storyHTML	+= 		"<div class='clear'></div>";				
				storyHTML	+= 		"</li>";
				
				
			$(storyHTML).hide().appendTo("#v2List").fadeIn(500);
			//var lli = $(sys.divID).find("ul").append("<li>"+storyHTML+"</li>").fadeIn(1000);
		}
		
		
		//CALLBACK
		//alert(sys.callBackFunction);
		if (params.callBackFunction != null){
			sys.callBackFunction();
		}
		
		//timeout = setTimeout(sys.callBackFunction, 100);

		
		
		
	} //end Function
	// OUTPUT----------------------------------------------------------------------------








} // END FUNCTION 
















function generatePubPage(divID, params)
{
	
	
	//DEFAULTS
	var sys = new Object();
	sys.showDate = 1;
	sys.showDesc = 1;
	sys.showImage = 1;
	sys.showFirstItem = 1; 
	sys.showCategory = 1; 
	sys.showSocial = 1;
	sys.numItems = 5; 
	sys.categoryTitle = "";
	sys.authorName = "";

	
	//OPTIONS
	if (params.showDate != null) sys.showDate = params.showDate;
	if (params.showDesc != null) sys.showDesc = params.showDesc;
	if (params.showImage != null) sys.showImage = params.showImage;
	if (params.showFirstItem != null) sys.showFirstItem = params.showFirstItem; 
	if (params.showCategory != null) sys.showCategory = params.showCategory; 
	if (params.showSocial != null) sys.showSocial = params.showSocial; 
	if (params.numItems) sys.numItems = params.numItems; 
	if (params.categoryTitle) sys.categoryTitle	= params.categoryTitle;
	if (params.authorName) sys.authorName = params.authorName;

		
	var html = '';
	var catTitleHTML = '';
	sys.numItems = sys.numItems + 1 ;

	if (sys.authorName){
		catTitleHTML = "<h2>Author: "+sys.authorName+"</h2>";
	}else if (sys.categoryTitle == null){
		sys.categoryTitle = "";
		//catTitleHTML = "<h2>Category: All</h2>";
	}else{	
		catTitleHTML = "<h2>Category: "+sys.categoryTitle+"</h2>";
	}
	
	html += '<ul>';
	var count = 0;
	var linkP = "";

	
	if (sys.showFirstItem != 0){ sys.numItems = sys.numItems - 1; }
	

	$.get(globalPublicationsXML, function(xml){
	

		$("item", xml).each(function(k){
			
			
			
			var $item = $(this);
			
			var itemMatch = 0;
			var author = $item.find('author').text();
			var description = $item.find('description').text();
			var blogUserImage = $item.find('blogUserImage').text();
			var itemTitle = $item.find('title').text();
			var publicationTitle = $item.find('publication title').text();
			var issueTitle = $item.find('issue title').text();
			var pubdate = $item.find('pubDate').text();
			var categoryDiv = "";
			var authorDiv = "";			
			var commentCountHTML = "";			
			var commentCount = 0;
			var likeCount = 0;
			var pdfTitleArray = new Array();
			var pdfLinkArray = new Array();
			var downloadString = "";
	
			
			
			
 
			//alert("authorName: "+authorName);
			if ((sys.categoryTitle == "") && (!sys.authorName)) itemMatch = 1;
				
			// CATEGORY
			$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if (categoryDiv) categoryDiv += "; ";	
					categoryDiv += "<a href='"+globalPublicationsURL+"?cat="+itemCategoryName+"'>"+itemCategoryName+"</a>"; 
					
					if (sys.categoryTitle == itemCategoryName){
						itemMatch = 1;
					}
					
			});			
			// END CATEGORY


			// AUTHOR 
			$(this).find("author").each(function(){
					itemAuthorName = getNodeText(this);							   
					if (authorDiv) authorDiv += ", ";	
					
					authorDiv += "<a href='"+globalPublicationsURL+"?author="+itemAuthorName+"'>" + itemAuthorName + "</a>"; 
					
					if (sys.authorName == itemAuthorName){
						itemMatch = 1;
					}
					
			});	
			// END AUTHOR

			
			
			
			
			
			
			//DOWNLOADS
			

			
			var count = 0;
			$(this).find("download").each(function(){
				if ($(this).attr("docType") == "pdf"){
					pdfLinkArray[count] 	= $(this).find("link").text();
					pdfTitleArray[count] 	= $(this).find("title").text();
					++count;
				}
			});		
			
			
			
			

			// COMMENTS 
			/*
			$(this).find("comment").each(function(){
					++commentCount;
			});	
			var coms = "Comments";
			if (commentCount == 1) coms = "Comment";
			commentCountHTML = "<span class='commentCount'><a href=\""+globalBlogURL+"?blogID="+blogID+"#comments\">(" + commentCount + ") "+coms+"</a></span>"; 
			// END comments
				*/

			
			//var linkP = $item.find('link').text();
			//alert(description);
				
			if ( ((sys.showFirstItem == 0)&&(count == 0)) || (itemMatch == 0) ){
			}else{
				
				
				

        


				//alert(likeHTML);


				html += "<li>";

				html += "	<div class=\"hd\">";
				html += "		<div class='publication'><div class='title'>"+publicationTitle+"</div></div>";
				//if (sys.showDate) html += "		<div class='date'>" + pubdate +  "</div>";
				
				
				
				//DOWNLOADS
				downloadString = "<ul class='downloads'>";
				
					//PDF
					downloadString += "<li>";
					if (pdfTitleArray.length == 1){
						downloadString += "<a href='"+pdfLinkArray[i]+"'>PDF</a>";
					}else{
						//if multiple pdf downloads
						downloadString += "<span class='ui-icon-subs'>";
						downloadString += "<a class='icon icon-download' href='#'>PDF</a>";
						downloadString += "<ul class='subnav2'>";
						for ( var i=0, len=pdfTitleArray.length; i<len; ++i ){
							downloadString += "<li><a href='"+pdfLinkArray[i]+"'>"+pdfTitleArray[i]+"</a></li>";
						}
						downloadString += "</ul>";
					}
					downloadString += "</li>";
					
					//PPT
				
				downloadString += "</ul>";
				//DOWNLOADS
				
				
				
				html += downloadString;
				
				html += "		<div class='issue'><div class='title'>"+issueTitle+"</div><div class='author'>by " + authorDiv + "</div></div>";
			
				//if (sys.showSocial) html += "		<div class='social'><div class='rr-middle'><div class='rr-right'>" + commentCountHTML +" "+ "<span class='iLikeCount-off' id='iLike-"+blogID+"'></span></div></div></div>";
				html += "	</div>";
				if (sys.showDesc) html += "	<div class='description'>" + description +"</div>"; 
				html += "</div>"; 
	
				//CATEGORY
				if ((sys.showCategory)&&(categoryDiv)){ html += "<div class='category'>Category: " + categoryDiv + "</div>"; }
				
				
				html += "<div class='clear'></div>";
				html += "</li>";

				count = count + 1;
				
			}

			
			if (count == sys.numItems){ return false; }				


		});

		html += "</ul>";
		$(divID).html(html).slideDown("slow");

		generateDropDown();
		


	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}




function generatePubList(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, numItems, monthID, yearID)
{
	var html = '<ul>';
	var linkP = "";
	
	if (showFirstItem != 0){
			numItems = numItems - 1;
	}
	

	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(){

			var itemP = $(this);
			
			if ((showFirstItem == 0)&&(count == 0)){
				// nothing
			}else{
				var pub 	= itemP.find('publication');
				var issue 	= itemP.find('issue');
				
				var publicationMonth = pub.find('month').text();
				var publicationYear = pub.find('year').text();
				
				if ((monthID==null)||(yearID==null)){
					monthID = pub.find('month').text();
					yearID = pub.find('year').text();
				}
				
				//IF right date
				if ((publicationMonth==monthID)&&(publicationYear==yearID)){
					

						html += "<li>";
						html += "<div class='containerGray469-A1'>";
						html += "<div class='topCurve'>Top Curve</div>";
						
						issue.find("image").each(function(){
							// IMAGE 	
							if (showImage){	html += "<a href='" + linkP + "'><img class='image-main' src='" + getNodeText(this) + "'></a>"; }
						});
		
		
						html += "<div class='date-1'>"+getMonthName(pub.find('month').text())+" "+pub.find('year').text()+"</div>";
		
						
		
						//LINK AND TITLE
						var issueLink = issue.find('link').text();
						var issueTitle = issue.find('title').text();
						var issueAuthor = issue.find('author').text();
						var issueDescription = issue.find('description').text();
						
						issue.find("author").text()
						
						if (issueLink){
							html += "<div class='title'><a href='" + issueLink +"'>";
							if (issueTitle){
								html += issueTitle;
							}
							html += "</a></div>";
						}else{
							if (issueTitle){
								html += "<div class='title'>"+issueTitle+"</div>";
							}
						
						}
						
						// DATE	
						if (issue.find("pubDate").text() && (showDate)){
							html += "<div class='date'>" + issue.find("pubDate").text() + "</div>"; 
						}
						
						if (issueAuthor){
							html += "<div class='author'>By "+issueAuthor+"</div>";
						}
						
						
						
						
						
						//DOWNLOADS
						itemP.find("downloads:first").each(function(){
							html += "<div class='downloads'>";
							html += "	<h3>Downloads:</h3>";
			
							var pdfArray = new Array();
							var pptArray = new Array();
							var emailArray = new Array();
							var pdfArrayCount = 0;
							var pptArrayCount = 0;
							var emailArrayCount = 0;
							
							$(this).find("download").each(function(){
								if ($(this).attr("docType") == "pdf"){
									pdfArray[pdfArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
									++pdfArrayCount;
								}else if ($(this).attr("docType") == "ppt"){
									pptArray[pptArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
									++pptArrayCount;
								}else if ($(this).attr("docType") == "email"){
									emailArray[emailArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
									++emailArrayCount;
								}							
		
								//alert($(this).attr("docType"));
		//						pdfArray[arrayCount] = itemP.find("dTitle").text();
								//++arrayCount;
							});
							
							//display the pdf download block
							if (pdfArrayCount > 0){
								html += "<div class='downloadBlock-pdf'>";
								html += "<form><select name='file'>";
								html += "<option value=''>---------- select ----------</option>";
								$.each(pdfArray, function() {
									html += this;
								});
								html += "</select>";
								html += "<input type='image' onclick=\"getFile(this.form)\" src='/common-media/images/download_pdf.gif' name='image' width='64px' height='22px' />";
								html += "</form></div>";
							}
							//display the ppt download block
							if (pptArrayCount > 0){
								html += "<div class='downloadBlock-ppt'>";
								html += "<form><select name='file'>";
								html += "<option value=''>---------- select ----------</option>";
								$.each(pptArray, function() {
									html += this;
								});
								html += "</select>";
								html += "<input type='image' onclick=\"getFile(this.form)\" src='/common-media/images/download_ppt.gif' name='image' width='64px' height='22px' />";
								html += "</form></div>";
							}
							//display the email download block
							if (emailArrayCount > 0){
								html += "<div class='downloadBlock-email'>";
								html += "<form><select name='file'>";
								html += "<option value=''>---------- select ----------</option>";
								$.each(emailArray, function() {
									html += this;
								});
									html += "</select>";
								html += "<input type='image' onclick=\"getFile(this.form)\" src='/common-media/images/download_msg.gif' name='image' width='64px' height='22px' />";
								html += "</form></div>";

							}
							
						html += "</div>";	
						});
						//END DOWNLOADS
						
						
						//DESCRIPTION
						if (issueDescription){
							if ((showDesc)&&(issueDescription)){	html += "<div class='description'>" + issueDescription +"</div>"; }
						}
						
						
						//RECOMMENDATIONS
						itemP.find("recommendations").each(function(){
							html += "<div class='recommendations list-A2'>";
							html += "	<h3 class='first'>Quadrant Recommendations:</h3>";
			
							html += "	<ul>";
							itemP.find("recommendation").each(function(){
								html += "	<li>"+getNodeText(this)+"</li>";
							});
							html += "	</ul>";
							html += "</div>";
						});
						
						
						
				
						
						

						html += "<div class='clear'></div>";
						html += "</li>";
						//----------------------------------------------				
						
						
						//UPDATES
						itemP.find("update").each(function(){
							html += "<li>";
							
								var aname = getGoodString($(this).find('title:first').text());
								
								html += "<a name=\""+aname+"\"></a>";
								html += "<div class='date-1'>"+getMonthName(pub.find('month').text())+" "+pub.find('year').text()+" Update</div>";
								html += "<div class='title'>"+$(this).find('title:first').text()+"</div>";
								html += "<div class='author'>By "+$(this).find('author').text()+"</div>";
						
										
								//DOWNLOADS
								$(this).find("downloads:first").each(function(){
									html += "<div class='downloads'>";
									html += "	<h3>Downloads:</h3>";
					
									var pdfArray = new Array();
									var pptArray = new Array();
									var emailArray = new Array();
									var pdfArrayCount = 0;
									var pptArrayCount = 0;
									var emailArrayCount = 0;
									
									$(this).find("download").each(function(){
										if ($(this).attr("docType") == "pdf"){
											pdfArray[pdfArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
											++pdfArrayCount;
										}else if ($(this).attr("docType") == "ppt"){
											pptArray[pptArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
											++pptArrayCount;
										}else if ($(this).attr("docType") == "email"){
											emailArray[emailArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
											++emailArrayCount;
										}							
				
										//alert($(this).attr("docType"));
				//						pdfArray[arrayCount] = itemP.find("dTitle").text();
										//++arrayCount;
									});
									
									//display the pdf download block
									if (pdfArrayCount > 0){
										html += "<div class='downloadBlock-pdf'>";
										html += "<form><select name='file'>";
										html += "<option value=''>---------- select ----------</option>";
										$.each(pdfArray, function() {
											html += this;
										});
										html += "</select>";
										html += "<input type='image' onclick=\"getFile(this.form)\" src='/common-media/images/download_pdf.gif' name='image' width='64px' height='22px' />";
										html += "</form></div>";
									}
									//display the ppt download block
									if (pptArrayCount > 0){
										html += "<div class='downloadBlock-ppt'>";
										html += "<form><select name='file'>";
										html += "<option value=''>---------- select ----------</option>";
										$.each(pptArray, function() {
											html += this;
										});
										html += "</select>";
										html += "<input type='image' onclick=\"getFile(this.form)\" src='/common-media/images/download_ppt.gif' name='image' width='64px' height='22px' />";
										html += "</form></div>";
									}
									//display the email download block
									if (emailArrayCount > 0){
										html += "<div class='downloadBlock-email'>";
										html += "<form><select name='file'>";
										html += "<option value=''>---------- select ----------</option>";
										$.each(emailArray, function() {
											html += this;
										});
											html += "</select>";
										html += "<input type='image' onclick=\"getFile(this.form)\" src='/common-media/images/download_msg.gif' name='image' width='64px' height='22px' />";
										html += "</form></div>";
		
									}
									
								html += "<div class='clear'></div>";
								html += "</div>";	
								});
								//END DOWNLOADS						
						
						
								html += "<div class='description'>"+$(this).find('description').text()+"</div>";
						
						
							html += "<div class='clear'></div>";
							html += "</li>";							   
						});
						
						html += "</li>";

				}
				// end if right date
	

			}




		});
		html += "</ul>";
		
		$(divID).html(html).slideDown("slow");
	});
} 




function generateOffices(xmlFile, divID, region)    
{
	var officeTableHTML 	=  "<table class='display table' id='officeTable'>";
	officeTableHTML 	+= "<thead><tr>";
	officeTableHTML 	+= "<th>Office</th>";
	officeTableHTML 	+= "<th>Country</th>";
	officeTableHTML 	+= "<th>Region</th>";
	officeTableHTML 	+= "<th>Phone</th>";
	officeTableHTML 	+= "<th>Address</th>";
	officeTableHTML 	+= "</tr></thead>";
	

	$.get(xmlFile, function(xml){

		$("region", xml).each(function(){
			var regionP = $(this);
			var regionName = regionP.attr("name");
			
			//html += "<li><div class='region'>"+regionName+"</div>";	

			
			
			//COUNTRY ***************************************
			//var country 	= region.find('country');
			//var countryName = country.attr("name");

			//html += "<ul>";

			regionP.find('country').each(function(){
				var country  = $(this);
				
				// fix the recursive country issues
				var hasChildren = country.children().length > 0;
				if (hasChildren){
					var countryName = country.attr("name");
					//html += "<li><div class='country'>"+countryName+"</div>";
				

					//OFFICES
					country.find("offices:first").each(function(){
						//html += "<ul>";
	
						//Each office
						$(this).find("office").each(function(){
							
							//if office region  = region  
							if ( (region == regionName)	|| (region == null) || (region == "All")){					 
								var office = $(this);						 	
								var officeName = office.attr("name");
								var urlOfficeName = officeName; //escape(officeName);
								var officeAddressHTML = "";
								var officePhoneHTML = "";
								
								var address1 	= office.find('address1').text();
								var address2 	= office.find('address2').text();
								var address3 	= office.find('address3').text();
								var address4 	= office.find('address4').text();
								var city 		= office.find('city').text();
								var state 		= office.find('state').text();
								var postalcode  = office.find('postalcode').text();
								var country 	= office.find('country').text();							
								
								var phone1	 	= office.find('phone1').text();							
								var phone2	 	= office.find('phone2').text();							
								
								if (address1) { officeAddressHTML += "<div>"+address1+"</div>"; }
								if (address2) { officeAddressHTML += "<div>"+address2+"</div>"; }
								if (address3) { officeAddressHTML += "<div>"+address3+"</div>"; }
								if (address4) { officeAddressHTML += "<div>"+address4+"</div>"; }
								if (city) { officeAddressHTML += "<div>"+city+"</div>"; }
								if (state) { officeAddressHTML += "<div>"+state+"</div>"; }
								if (postalcode) { officeAddressHTML += "<div>"+postalcode+"</div>"; }
								if (country) { officeAddressHTML += "<div>"+country+"</div>"; }
	
								if (phone1) { officePhoneHTML += "<div>"+phone1+"</div>"; }
								if (phone2) { officePhoneHTML += "<div>"+phone2+"</div>"; }
								
								
								officeTableHTML 	+= "<tr>";
								officeTableHTML 	+= "<td><a href='/contactUs/office.htm?office="+urlOfficeName+"'>"+officeName+"</a></td>";
								officeTableHTML 	+= "<td>"+countryName+"</td>";
								officeTableHTML 	+= "<td>"+regionName+"</td>";
								officeTableHTML 	+= "<td>"+officePhoneHTML+"</td>";
								officeTableHTML 	+= "<td>"+officeAddressHTML+"</td>";
								officeTableHTML 	+= "</tr>";
						 	} // end if region
							
							
							//html += "<li><div class='office'><a href='/contactUs/office.htm?office="+urlOfficeName+"'>"+officeName+"</a></div></li>";
						});
						//end each office
						
						//html += "</ul>";
					});
					//END OFFICES



					//html += "</li>";
				} // end has children
			});



			//html += "</ul>";
			//END COUNTRY************************************	
			
			
		
			
			//html += "</li>";
		});
		//end each region
		
		//html += "</ul>";
		
		
		officeTableHTML += "</table>";
		
		
		$(divID).html(officeTableHTML).slideDown("slow");
		$('#officeTable').dataTable({
			"bPaginate": false,
			"bStateSave": true
		});
		$("input#dataTableSearch").labelify({labelledClass: "labelinside"});
		
		
		$('input#dataTableSearch').focus(function() {
			if ($('#searchX').length == 0) {
				$(".input").append("<div id='searchX'></div>")
				$('#searchX').click(function() {
					resetDataTable();
				});
				
			}
		});		
		
		
		
		
		

	});
} 



function generateCountriesWithData(xmlFile, divID, region)    
{

	var tableHTML 	=  "<table class='display table' id='countryTable'>";
	tableHTML 	+= "<thead><tr>";
	tableHTML 	+= "<th>Country</th>";
	tableHTML 	+= "<th>CCO</th>";
	tableHTML 	+= "<th nowrap>Assistant CCO</th>";
	tableHTML 	+= "<th nowrap>Regional Head</th>";
	tableHTML 	+= "<th>Misc</th>";
	
	tableHTML 	+= "</tr></thead>";
	

	$.get(xmlFile, function(xml){
		
		$("country", xml).each(function(){
		
			var countryP = $(this);
			var countryName = countryP.attr("name");
			
			var cco_bio	= countryP.find('cco_bio').text();
			var gts_profile	= countryP.find('gts_profile').text();
			var emea_profile	= countryP.find('emea_profile').text();
			
			
			var miscHTML = "<ul>";
			var cco_bioHTML = "";
			
			if (cco_bio)  		cco_bioHTML = " <a href='"+cco_bio+"' target='_new'>(Bio)</a>";
			if (gts_profile)  	miscHTML += "<li><a href='"+gts_profile+"' target='_new'>GTS Profile</a></li>";
			if (emea_profile)  	miscHTML += "<li><a href='"+emea_profile+"' target='_new'>EMEA Profile</a></li>";
			miscHTML += "</ul>";
			
			
			
			countryP.find("employee").each(function(){			
				var employee = $(this);
				var employeeName 	= employee.attr("name");
				var employeeRole 	= employee.attr("role");
				var employeewebGEID = employee.attr("webGEID");
				
				var employeeHTML = "<a href='"+gdURL+"?webGEID="+employeewebGEID+"'>"+employeeName+"</a>";
				
				
				if (employeeRole == "cco") 			ccoHTML = employeeHTML + cco_bioHTML;
				if (employeeRole == "cco_assist") 	cco_assistHTML = employeeHTML;
				if (employeeRole == "region_head") 	region_headHTML = employeeHTML;
				
				
			
			});
			
			
			tableHTML += "<tr>";
			tableHTML += "<td>"+countryName+"</td>";
			tableHTML += "<td>"+ccoHTML+"</td>";
			tableHTML += "<td>"+cco_assistHTML+"</td>";
			tableHTML += "<td>"+region_headHTML+"</td>";
			tableHTML += "<td>"+miscHTML+"</td>";
			tableHTML += "</tr>";
			
		});
		//END COUNTRY************************************	
	
		
		tableHTML += "</table>";
		
		
		$(divID).html(tableHTML).slideDown("slow");
		$('#countryTable').dataTable({
			"sPaginationType": "full_numbers",
			"bStateSave": true
		});
		$("input#dataTableSearch").labelify({labelledClass: "labelinside"});
		
		
		$('input#dataTableSearch').focus(function() {
			if ($('#searchX').length == 0) {
				$(".input").append("<div id='searchX'></div>")
				$('#searchX').click(function() {
					resetDataTable();
				});
				
			}
		});		
		
		
		
		
		

	});
	// end GET
} 





function generateEmployeeDetails(geid, nameID, overviewID, dirID)
{
		

	
	var tableHTML 	=  "<table>";

	$.get(mainContactFile, function(xml){
		
		var assocBankerArray = new Array();
		var analystArray = new Array();
		var caoArray = new Array();
		var csoArray = new Array();
		var icArray = new Array();
		//var officeName = officeLocation;
		var employeeName = "";
		var employeeDetailHTML = "";
		var employeeArray = new Array();
		var empNum = 0;
		var supportTeams = new Array();
		var supportHTML = "";

		$("office", xml).each(function(){
			

		
			var officeP = $(this);
			var officeName = officeP.attr("name");
			

				
				
				officeP.find("employee").each(function(){
					var employeeP = $(this);
					var employeeGEID = employeeP.attr("webGEID");
							
								
								
					if (geid == employeeGEID){
						//FOR EACH EMPLOYEE IN XML THAT MATCHES GEID (CREATE A NEW ELEMENT FOR EACH NEW ROLE)
						foundRole = 0;
						tempRole  = employeeP.attr("role");
						
						//loop to see if role exists
						for (x in employeeArray){
							if (tempRole == employeeArray[x].role){
								employeeArray[x].office.push(officeName);
								foundRole = 1;
								
								/*-------- ROSTER -----------------------------------------------*/
								if (employeeArray[x].role == 'banker'){
									stNum = supportTeams.length;
									supportTeams[stNum] 		= new supportTeamObj();
									supportTeams[stNum].office 	= officeName;
									
										employeeP.find("roster:first").each(function(){
								
												$(this).find("teammember").each(function(){
													var tm = $(this);
													tm_name = tm.attr("name");
													tm_role = tm.attr("role");
													tm_geid = tm.attr("webGEID");
													
												
													if (tm_role == "ba-assoc-banker"){
														newNum = supportTeams[stNum].assocBanker.length + 1;
														supportTeams[stNum].assocBanker[newNum] = new employeeObj();
														supportTeams[stNum].assocBanker[newNum].name = tm_name;
														supportTeams[stNum].assocBanker[newNum].geid = tm_geid;
													}else if (tm_role == "analyst"){
														newNum = supportTeams[stNum].analyst.length + 1;
														supportTeams[stNum].analyst[newNum] = new employeeObj();
														supportTeams[stNum].analyst[newNum].name = tm_name;
														supportTeams[stNum].analyst[newNum].geid = tm_geid;
													}else if (tm_role == "cao"){
														newNum = supportTeams[stNum].cao.length + 1;
														supportTeams[stNum].cao[newNum] = new employeeObj();
														supportTeams[stNum].cao[newNum].name = tm_name;
														supportTeams[stNum].cao[newNum].geid = tm_geid;
													}else if (tm_role == "cso"){
														newNum = supportTeams[stNum].cso.length + 1;
														supportTeams[stNum].cso[newNum] = new employeeObj();
														supportTeams[stNum].cso[newNum].name = tm_name;
														supportTeams[stNum].cso[newNum].geid = tm_geid;
													}else if (tm_role == "ic"){
														newNum = supportTeams[stNum].ic.length + 1;
														supportTeams[stNum].ic[newNum] = new employeeObj();
														supportTeams[stNum].ic[newNum].name = tm_name;
														supportTeams[stNum].ic[newNum].geid = tm_geid;
													}
							
							
												}); //end each teammember
							
							
												
											}); //end roster
		
								}// end if banker
								/*-------- ROSTER -----------------------------------------------*/								
								
								
								
								return false;  // DROP OUT OF LOOP
							}
						}
						
						
						
						
						
						
						if (foundRole == 0){
							employeeArray[empNum] = new employeeObj();
							employeeArray[empNum].name   	= employeeP.attr("name");
							employeeArray[empNum].geid   	= employeeP.attr("webGEID");
							employeeArray[empNum].role   	= employeeP.attr("role");
							employeeArray[empNum].office 	= new Array;
							
							employeeArray[empNum].office[0] = officeName;  // need to make this an array
							
							/*-------- ROSTER -----------------------------------------------*/
							if (employeeArray[empNum].role == 'banker'){
								
								supportTeams[0] 		= new supportTeamObj();
								supportTeams[0].office 	= officeName;
								
								
											employeeP.find("roster:first").each(function(){
									
								
													$(this).find("teammember").each(function(){
														var tm = $(this);
														tm_name = tm.attr("name");
														tm_role = tm.attr("role");
														tm_geid = tm.attr("webGEID");
														
													
														if (tm_role == "ba-assoc-banker"){
															newNum = supportTeams[0].assocBanker.length + 1;
															supportTeams[0].assocBanker[newNum] = new employeeObj();
															supportTeams[0].assocBanker[newNum].name = tm_name;
															supportTeams[0].assocBanker[newNum].geid = tm_geid;
														}else if (tm_role == "analyst"){
															newNum = supportTeams[0].analyst.length + 1;
															supportTeams[0].analyst[newNum] = new employeeObj();
															supportTeams[0].analyst[newNum].name = tm_name;
															supportTeams[0].analyst[newNum].geid = tm_geid;
														}else if (tm_role == "cao"){
															newNum = supportTeams[0].cao.length + 1;
															supportTeams[0].cao[newNum] = new employeeObj();
															supportTeams[0].cao[newNum].name = tm_name;
															supportTeams[0].cao[newNum].geid = tm_geid;
														}else if (tm_role == "cso"){
															newNum = supportTeams[0].cso.length + 1;
															supportTeams[0].cso[newNum] = new employeeObj();
															supportTeams[0].cso[newNum].name = tm_name;
															supportTeams[0].cso[newNum].geid = tm_geid;
														}else if (tm_role == "ic"){
															newNum = supportTeams[0].ic.length + 1;
															supportTeams[0].ic[newNum] = new employeeObj();
															supportTeams[0].ic[newNum].name = tm_name;
															supportTeams[0].ic[newNum].geid = tm_geid;
														}
								
								
													}); //end each teammember
								
								
													
												}); //end roster
	
							}// end if banker
							/*-------- ROSTER -----------------------------------------------*/
							
							
						}else{ // IF found ROLE = 0 / 1
						
							alert("found role");
						}
						

						empNum = employeeArray.length + 1;

					}// end if geids match
								
				
				}); //end employee
				

		}); // end for each office
			
		
		
		
		
		


		rolesHTML 	=  "<table class='table stripe'>";
		rolesHTML 	+= "<thead><tr>";
		rolesHTML 	+= "<th class='columnOne'>Role</th>";
		rolesHTML 	+= "<th>Office(s)</th>";
		rolesHTML 	+= "</tr></thead>";



		for (x in employeeArray){
			
			rolesHTML 	+= "<tr><td>"+getRoleRealName(employeeArray[x].role)+"</td><td><ul>";
			for (y in employeeArray[x].office){
				rolesHTML 	+= "<li>"+employeeArray[x].office[y]+"</li>";
			}
			rolesHTML 	+= "</ul></td></tr>"	
		
		
		
		}
				
		rolesHTML 	+= "</table>";
		
		
		
		if (employeeArray[0].role == "banker"){
			supportHTML = "";
			for (i in supportTeams){
				supportHTML += getSupportTeamHTMLFromObj(supportTeams[i]);
			}
		}
		
		//GET OTHER DETAILS FROM JSON
		//var otherInfo  = "<div id='"+dirID+"'><p>Loading Employee Data...</p></div>";
		
		



		//DISPLAY
		$("#"+nameID).html(employeeArray[0].name).slideDown("slow");
		$("#"+overviewID).html(rolesHTML+supportHTML).slideDown("slow");
		
		generateEmployeeDetailsFromJSON(employeeArray[0].geid, dirID);
		$(".stripe tr:even").addClass("alt");
		
		
	});
	// end GET
	
} // end function


function loadEmployeeDetailsFromJSON(){
	$.getJSON(jsonURL ,function(jsonData) { 
		 window['jsonData'] = jsonData; //global
	});
} //end function



function generateEmployeeDetailsFromJSON(geid, divID){
	$.getJSON(jsonURL ,function(jsonData) { 

		var jsonKey = "x" + geid;
		var jsonString = "jsonData."+jsonKey;
		
		var jsonEmployee = eval(jsonString);
		
		

		jsonHTML 	= "<table class='table stripe1'>";
//		jsonHTML 	+= "<thead><tr>";
//		jsonHTML 	+= "<th class='columnOne'>&nbsp;</th>";
//		jsonHTML 	+= "<th></th>";
//		jsonHTML 	+= "</tr></thead>";
			
		jsonHTML 	+= "<tr><td>Officer Title</td><td>"+jsonEmployee.officertitle+"</td></tr>";
		jsonHTML 	+= "<tr><td>Job Title</td><td>"+jsonEmployee.jobtitle+"</td></tr>";
		jsonHTML 	+= "<tr><td>Phone</td><td>"+jsonEmployee.phone+"</td></tr>";
		jsonHTML 	+= "<tr><td>Email</td><td><a href='mailto:"+jsonEmployee.email+"'>"+jsonEmployee.email+"</a></td></tr>";

//		jsonHTML 	+= "<tr><td>Department</td><td>"+jsonEmployee.department+"</td></tr>";
//		jsonHTML 	+= "<tr><td>SOEID</td><td>"+jsonEmployee.soeid+"</td></tr>";
		jsonHTML 	+= "<tr><td>Location</td><td><ul>";
			if ((jsonEmployee.city) || (jsonEmployee.state)){
				jsonHTML += "<li>";
					if (jsonEmployee.city) jsonHTML	+= jsonEmployee.city;
					if ((jsonEmployee.city)&&(jsonEmployee.state)) jsonHTML	+= ", ";
					if (jsonEmployee.state) jsonHTML += jsonEmployee.state;				
				jsonHTML += "</li>";
			}
			if (jsonEmployee.countryname) jsonHTML	+= "<li>"+jsonEmployee.countryname+"</li>";
		jsonHTML 	+= "</ul></td></tr>";
		//jsonHTML 	+= "<tr><td>GEID</td><td>"+jsonEmployee.geid+"</td></tr>";
		
		jsonHTML 	+= "<tr><td>Directory Links</td><td>";
		jsonHTML 	+= "<ul>";
		jsonHTML 	+= "<li><a target='_new' href='"+gdURL+"?geid="+jsonEmployee.geid+"'>Global Directory</a></li>";
		jsonHTML 	+= "<li><a target='_new' href='"+adURL+"?accountname="+jsonEmployee.soeid+"'>Active Directory</a></li>";
		jsonHTML 	+= "</ul>";
		jsonHTML 	+= "</td></tr>";
		




		jsonHTML 	+= "</table>";
		
		$("#"+divID).html(jsonHTML).slideDown("slow");
		$(".stripe1 tr").mouseover(function() {$(this).addClass("over");}).mouseout(function() {$(this).removeClass("over");});
		$(".stripe1 tr:even").addClass("alt");
		
		
	});
	
	
} //end function



function testLoad(){
	var temp = "x0000906725";
	namep = "data."+temp;
	alert(namep);	
	tempa = eval(namep);
	alert(tempa.name);
	alert(tempa.department);	
}


function getSupportTeamHTMLFromObj(supportTeamObj){
	
	supportTeamHTML		 = "<h3>"+supportTeamObj.office+"</h3>";
	supportTeamHTML 	+= "<table class='table stripe' id='supportTable'>";
	supportTeamHTML 	+= "<thead><tr>";
	supportTeamHTML 	+= "<th class='columnOne'>Role</th>";
	supportTeamHTML 	+= "<th>Name(s)</th>";
	supportTeamHTML 	+= "</tr></thead>";



		supportTeamHTML 	+= "<tr><td>BA/Associate Banker</td><td>";
		supportTeamHTML 	+= "<ul>";
		for (x in supportTeamObj.assocBanker) supportTeamHTML += "<li><a target='_new' href='"+gdURL+"?geid="+supportTeamObj.assocBanker[x].geid+"'>"+supportTeamObj.assocBanker[x].name+"</a></li>";		
		supportTeamHTML 	+= "</ul>";
		supportTeamHTML 	+= "</td></tr>";


		supportTeamHTML 	+= "<tr><td>Analyst</td><td>";
		supportTeamHTML 	+= "<ul>";
		for (x in supportTeamObj.analyst) supportTeamHTML += "<li><a target='_new' href='"+gdURL+"?geid="+supportTeamObj.analyst[x].geid+"'>"+supportTeamObj.analyst[x].name+"</a></li>";		
		supportTeamHTML 	+= "</ul>";
		supportTeamHTML 	+= "</td></tr>";
		
		supportTeamHTML 	+= "<tr><td>Chief Administrative Officer</td><td>";
		supportTeamHTML 	+= "<ul>";
		for (x in supportTeamObj.cao) supportTeamHTML += "<li><a target='_new' href='"+gdURL+"?geid="+supportTeamObj.cao[x].geid+"'>"+supportTeamObj.cao[x].name+"</a></li>";		
		supportTeamHTML 	+= "</ul>";
		supportTeamHTML 	+= "</td></tr>";		
		
		supportTeamHTML 	+= "<tr><td>Client Service Officer</td><td>";
		supportTeamHTML 	+= "<ul>";
		for (x in supportTeamObj.cso)	supportTeamHTML += "<li><a target='_new' href='"+gdURL+"?geid="+supportTeamObj.cso[x].geid+"'>"+supportTeamObj.cso[x].name+"</a></li>";		
		supportTeamHTML 	+= "</ul>";
		supportTeamHTML 	+= "</td></tr>";	
		
		supportTeamHTML 	+= "<tr><td>Investment Counselor</td><td>";
		supportTeamHTML += "<ul>";
		for (x in supportTeamObj.ic) supportTeamHTML += "<li><a target='_new' href='"+gdURL+"?geid="+supportTeamObj.ic[x].geid+"'>"+supportTeamObj.ic[x].name+"</a></li>";		
		supportTeamHTML += "</ul>";
		supportTeamHTML 	+= "</td></tr>";	




	supportTeamHTML 	+= "</table>";	
	
	return supportTeamHTML;
}





function getSupportTeam(geid, officeLocation, divID)    
{
		
	xmlFile = "/rss/contactinfo.xml";
	
	var tableHTML 	=  "<table>";

	$.get(xmlFile, function(xml){
		
		var assocBankerArray = new Array();
		var analystArray = new Array();
		var caoArray = new Array();
		var csoArray = new Array();
		var icArray = new Array();
		var officeName = officeLocation;
		var bankerName = "";
		var supportTeamHTML = "";
		

		$("office", xml).each(function(){
			

		
			var officeP = $(this);
			var officeName = officeP.attr("name");
			
			if (officeName == officeLocation){
				
				
				officeP.find("employee").each(function(){
					var employeeP = $(this);
					var employeeGEID = employeeP.attr("webGEID");
							
								
								
					if (geid == employeeGEID){
						bankerName	= employeeP.attr("name");
						
												employeeP.find("roster:first").each(function(){
									
								
													$(this).find("teammember").each(function(){
														var tm = $(this);
														tm_name = tm.attr("name");
														tm_role = tm.attr("role");
														tm_geid = tm.attr("webGEID");
													
													
														if (tm_role == "ba-assoc-banker"){
															newNum = assocBankerArray.length + 1;
															assocBankerArray[newNum] = new employeeObj();
															assocBankerArray[newNum].name = tm_name;
															assocBankerArray[newNum].geid = tm_geid;
														}else if (tm_role == "analyst"){
															newNum = analystArray.length + 1;
															analystArray[newNum] = new employeeObj();
															analystArray[newNum].name = tm_name;
															analystArray[newNum].geid = tm_geid;
														}else if (tm_role == "cao"){
															newNum = caoArray.length + 1;
															caoArray[newNum] = new employeeObj();
															caoArray[newNum].name = tm_name;
															caoArray[newNum].geid = tm_geid;
														}else if (tm_role == "cso"){
															newNum = caoArray.length + 1;
															csoArray[newNum] = new employeeObj();
															csoArray[newNum].name = tm_name;
															csoArray[newNum].geid = tm_geid;
														}else if (tm_role == "ic"){
															newNum = caoArray.length + 1;
															icArray[newNum] = new employeeObj();
															icArray[newNum].name = tm_name;
															icArray[newNum].geid = tm_geid;
														}
								
								
													}); //end each teammember
								
								
													
												}); //end roster
								
							
							return false; //break out of .each loop if found

						}// end if geids match
								
								
								
								
				
				
					}); //end employee
				

							
							
							
					
							
							
				

			}
		}); // end for each office
			
		
		supportTeamHTML 	=  "<h3>"+officeName.toUpperCase()+"</h3>";
		supportTeamHTML 	+= "<h2>"+bankerName+"</h2>";

		supportTeamHTML 	+=  "<table class='table stripe' id='supportTable'>";
		supportTeamHTML 	+= "<thead><tr>";
		supportTeamHTML 	+= "<th>Role</th>";
		supportTeamHTML 	+= "<th>Name(s)</th>";
		supportTeamHTML 	+= "</tr></thead>";


		supportTeamHTML 	+= "<tr><td>BA/Associate Banker</td><td>";
			supportTeamHTML += "<ul>";
			for (x in assocBankerArray)	supportTeamHTML += "<li><a href='"+assocBankerArray[x].geid+"'>"+assocBankerArray[x].name+"</a></li>";		
			supportTeamHTML += "</ul>";
		supportTeamHTML 	+= "</td></tr>";


		supportTeamHTML 	+= "<tr><td>Analyst</td><td>";
			supportTeamHTML += "<ul>";
			for (x in analystArray)	supportTeamHTML += "<li><a href='"+analystArray[x].geid+"'>"+analystArray[x].name+"</a></li>";		
			supportTeamHTML += "</ul>";
		supportTeamHTML 	+= "</td></tr>";
		
		supportTeamHTML 	+= "<tr><td>Chief Administrative Officer</td><td>";
			supportTeamHTML += "<ul>";
			for (x in caoArray)	supportTeamHTML += "<li><a href='"+caoArray[x].geid+"'>"+caoArray[x].name+"</a></li>";		
			supportTeamHTML += "</ul>";
		supportTeamHTML 	+= "</td></tr>";		
		
		supportTeamHTML 	+= "<tr><td>Client Service Officer</td><td>";
			supportTeamHTML += "<ul>";
			for (x in csoArray)	supportTeamHTML += "<li><a href='"+csoArray[x].geid+"'>"+csoArray[x].name+"</a></li>";		
			supportTeamHTML += "</ul>";
		supportTeamHTML 	+= "</td></tr>";	
		
		supportTeamHTML 	+= "<tr><td>Investment Counselor</td><td>";
			supportTeamHTML += "<ul>";
			for (x in icArray)	supportTeamHTML += "<li><a href='"+icArray[x].geid+"'>"+icArray[x].name+"</a></li>";		
			supportTeamHTML += "</ul>";
		supportTeamHTML 	+= "</td></tr>";			

		
		
		supportTeamHTML 	+= "</table>";
		
		
		
		//DISPLAY
		$("#"+divID).html(supportTeamHTML).slideDown("slow");
		
		$('#supportTable').dataTable({
			"bStateSave": true,
			"bPaginate": false,
			"bInfo": false,
			"bFilter": false
		});
		
	});
	// end GET
	
} // end function





function generateOfficesByType(xmlFile, divID, type)    
{
	var officeTableHTML 	=  "<table class='display table' id='officeTable'>";
	officeTableHTML 	+= "<thead><tr>";
	officeTableHTML 	+= "<th>Office</th>";
	officeTableHTML 	+= "<th>Type</th>";
	officeTableHTML 	+= "<th>Country</th>";
	officeTableHTML 	+= "<th>Region</th>";
	officeTableHTML 	+= "<th>Phone</th>";
	officeTableHTML 	+= "<th>Address</th>";
	officeTableHTML 	+= "</tr></thead>";
	

	$.get(xmlFile, function(xml){

		$("region", xml).each(function(){
			var regionP = $(this);
			var regionName = regionP.attr("name");
			
			//html += "<li><div class='region'>"+regionName+"</div>";	

			
			
			//COUNTRY ***************************************
			//var country 	= region.find('country');
			//var countryName = country.attr("name");

			//html += "<ul>";

			regionP.find('country').each(function(){
				var country  = $(this);
				
				// fix the recursive country issues
				var hasChildren = country.children().length > 0;
				if (hasChildren){
					var countryName = country.attr("name");
					//html += "<li><div class='country'>"+countryName+"</div>";
				

					//OFFICES
					country.find("offices:first").each(function(){
						//html += "<ul>";
	
						//Each office
						$(this).find("office").each(function(){
							var office    = $(this);
							var typeinXML = office.find('type').text()
							
							//if office type  = type requested
							if ( (type == typeinXML) || (type == null) || (type == "All")){					 
														 	
								var officeName = office.attr("name");
								var urlOfficeName = officeName; //escape(officeName);
								var officeAddressHTML = "";
								var officePhoneHTML = "";
								
								var address1 	= office.find('address1').text();
								var address2 	= office.find('address2').text();
								var address3 	= office.find('address3').text();
								var address4 	= office.find('address4').text();
								var city 		= office.find('city').text();
								var state 		= office.find('state').text();
								var postalcode  = office.find('postalcode').text();
								var country 	= office.find('country').text();							
								
								var phone1	 	= office.find('phone1').text();							
								var phone2	 	= office.find('phone2').text();							
								
								if (address1) { officeAddressHTML += "<div>"+address1+"</div>"; }
								if (address2) { officeAddressHTML += "<div>"+address2+"</div>"; }
								if (address3) { officeAddressHTML += "<div>"+address3+"</div>"; }
								if (address4) { officeAddressHTML += "<div>"+address4+"</div>"; }
								if (city) { officeAddressHTML += "<div>"+city+"</div>"; }
								if (state) { officeAddressHTML += "<div>"+state+"</div>"; }
								if (postalcode) { officeAddressHTML += "<div>"+postalcode+"</div>"; }
								if (country) { officeAddressHTML += "<div>"+country+"</div>"; }
	
								if (phone1) { officePhoneHTML += "<div>"+phone1+"</div>"; }
								if (phone2) { officePhoneHTML += "<div>"+phone2+"</div>"; }
								
								
								officeTableHTML 	+= "<tr>";
								officeTableHTML 	+= "<td><a href='/contactUs/office.htm?office="+urlOfficeName+"'>"+officeName+"</a></td>";
								officeTableHTML 	+= "<td>"+typeinXML+"</td>";
								officeTableHTML 	+= "<td>"+countryName+"</td>";
								officeTableHTML 	+= "<td>"+regionName+"</td>";
								officeTableHTML 	+= "<td>"+officePhoneHTML+"</td>";
								officeTableHTML 	+= "<td>"+officeAddressHTML+"</td>";
								officeTableHTML 	+= "</tr>";
						 	} // end if region
							
							
							//html += "<li><div class='office'><a href='/contactUs/office.htm?office="+urlOfficeName+"'>"+officeName+"</a></div></li>";
						});
						//end each office
						
						//html += "</ul>";
					});
					//END OFFICES



					//html += "</li>";
				} // end has children
			});



			//html += "</ul>";
			//END COUNTRY************************************	
			
			
		
			
			//html += "</li>";
		});
		//end each region
		
		//html += "</ul>";
		
		
		officeTableHTML += "</table>";
		
		
		$(divID).html(officeTableHTML).slideDown("slow");
		$('#officeTable').dataTable({
			"bPaginate": false,
			"bStateSave": true
		});
		$("input#dataTableSearch").labelify({labelledClass: "labelinside"});



		$('input#dataTableSearch').focus(function() {
			if ($('#searchX').length == 0) {
				$(".input").append("<div id='searchX'></div>")
				$('#searchX').click(function() {
					
		  			$('input#dataTableSearch').val("");
					$('input#dataTableSearch').keyup();
					$('#searchX').remove();
					$("input#dataTableSearch").labelify({labelledClass: "labelinside"});

				});
			}
		});
		
		
		
		

	});
} 


function generateOfficeDetails(xmlFile, divID, officeRequest)
{
	var bankersHTML 				= "";
	var gmmHTML 					= "";
	var regionalMDHTML 				= "";
	var serviceManagerHTML 			= "";
	var serviceDirectorHTML			= "";
	var headServiceHTML 			= "";
	var businessManagerHTML			= "";
	var investmentFinanceSpecHTML 	= "";
	var mortgageSpecHTML 			= "";
	var sp24HTML 					= "";
	var desktopSaHTML 				= "";
	

	

	$.get(xmlFile, function(xml){

		$("region", xml).each(function(){
			var regionP = $(this);
			var regionName = regionP.attr("name");
			
			
			
			//COUNTRY ***************************************

			regionP.find('country').each(function(){
				var country  = $(this);
				
				// fix the recursive country issues
				var hasChildren = country.children().length > 0;
				if (hasChildren){
					var countryName = country.attr("name");
				

					//OFFICES
					country.find("offices:first").each(function(){
	
						//Each office
						$(this).find("office").each(function(){
							var office = $(this);						 	
							var officeName = office.attr("name");

							if (officeName == officeRequest){  // CORRECT OFFICE
							
								var officeAddressHTML = "";
								var address1 	= office.find('address1').text();
								var address2 	= office.find('address2').text();
								var address3 	= office.find('address3').text();
								var address4 	= office.find('address4').text();
								var city 		= office.find('city').text();
								var state 		= office.find('state').text();
								var postalcode  = office.find('postalcode').text();
								var country 	= office.find('country').text();
								var mapHTML		= office.find('map-address').text();
								var ll			= office.find('ll').text();
								
								
								//var mapWidth	= "433";
								//var mapHeight	= "150";
								//var mapHTML		= "<iframe width='"+mapWidth+"' height='"+mapHeight+"' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='"+mapURL+"'></iframe><br /><small><a href='"+mapURL+"' style='color:#0000FF;text-align:left'>View Larger Map</a></small>";
								//alert(mapURL);
      <!--<iframe width="433" height="150" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=300+Crescent+Court,+Suite+950,+Dallas,+Texas+75201&amp;sll=32.793534,-96.804614&amp;sspn=0.006476,0.008047&amp;ie=UTF8&amp;hq=&amp;hnear=300+Crescent+Ct+%23950,+Dallas,+Texas+75201&amp;z=14&amp;ll=32.793534,-96.804614&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=300+Crescent+Court,+Suite+950,+Dallas,+Texas+75201&amp;sll=32.793534,-96.804614&amp;sspn=0.006476,0.008047&amp;ie=UTF8&amp;hq=&amp;hnear=300+Crescent+Ct+%23950,+Dallas,+Texas+75201&amp;z=14&amp;ll=32.793534,-96.804614" style="color:#0000FF;text-align:left">View Larger Map</a></small>
								
								
								
								if (address1) { officeAddressHTML += "<div>"+address1+"</div>"; }
								if (address2) { officeAddressHTML += "<div>"+address2+"</div>"; }
								if (address3) { officeAddressHTML += "<div>"+address3+"</div>"; }
								if (address4) { officeAddressHTML += "<div>"+address4+"</div>"; }
								if (city) { officeAddressHTML += "<div>"+city+"</div>"; }
								if (state) { officeAddressHTML += "<div>"+state+"</div>"; }
								if (postalcode) { officeAddressHTML += "<div>"+postalcode+"</div>"; }
								if (country) { officeAddressHTML += "<div>"+country+"</div>"; }
								
								
								var officeMapHTML = "<iframe width='655' height='550' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q="+mapHTML+"&amp;sll=[ll]&amp;sspn="+ll+"&amp;ie=UTF8&amp;z=14&amp;ll="+ll+"&amp;output=embed'></iframe>";
								
								
								$("#officeAddress").html(officeAddressHTML).slideDown("slow");
								if (mapHTML) { 
									$("#officeMap").html(officeMapHTML).slideDown("slow");
								}
								
								//EMPLOYEE
								office.find("employees:first").each(function(){
				
									//Each employee
									$(this).find("employee").each(function(){
										var employee = $(this);						 	
										var supportLink = "";
										
										var employeeName = employee.attr("name");
										var employeeRole = employee.attr("role");
										
										var employeeGEID = employee.attr("webGEID");
											
										//if (employeeRole == "banker"){
										//	supportLink += " <a href=\"javascript:callModal('/contactUs/employee.htm?geid="+employeeGEID+"&loc="+officeName+"');\"><img src='"+viewRosterIcon+"' alt='View Banker Roster' title='View Banker Roster' /></a>";
										//}	
											
										employeeLI = "<li><a href=\"javascript:callModal('/contactUs/_full/employee.htm?geid="+employeeGEID+"&loc="+officeName+"');\">"+employeeName+"</a>"+supportLink+"</li>";

										if (employeeRole == "banker"){ bankersHTML += employeeLI; }
										if (employeeRole == "gmm"){ gmmHTML += employeeLI; }
										if (employeeRole == "regionalMD-teamlead"){ regionalMDHTML += employeeLI; }
										if (employeeRole == "service-manager"){ serviceManagerHTML += employeeLI; }
										if (employeeRole == "service-director"){ serviceDirectorHTML += employeeLI; }
										if (employeeRole == "head-service"){ headServiceHTML += employeeLI; }
										if (employeeRole == "business-manager"){ businessManagerHTML += employeeLI; }
										if (employeeRole == "investment-finance-spec"){ investmentFinanceSpecHTML += employeeLI; }
										if (employeeRole == "mortgage-spec"){ mortgageSpecHTML += employeeLI; }
										if (employeeRole == "sp24"){ sp24HTML += employeeLI; }
										if (employeeRole == "desktop-sa"){ desktopSaHTML += employeeLI; }
										
										
										
										
														
										
									});
									//end each employee
									
								});
								//END EMPLOYEES								
								
								
								
								
								
							}// END CORRECT OFFICE
							
							
						});
						//end each office
						
					});
					//END OFFICES



				} // end has children
			});


			//END COUNTRY************************************	
			
			
		});
		//end each region
		





		
		//PUSH===============
		$("#table-bankers").html("<ul>"+bankersHTML+"</ul>").slideDown("slow");
		$("#table-gmm").html("<ul>"+gmmHTML+"</ul>").slideDown("slow");
		$("#table-regionalMD-teamlead").html("<ul>"+regionalMDHTML+"</ul>").slideDown("slow");
		$("#table-service-manager").html("<ul>"+serviceManagerHTML+"</ul>").slideDown("slow");
		$("#table-service-director").html("<ul>"+serviceDirectorHTML+"</ul>").slideDown("slow");
		$("#table-head-service").html("<ul>"+headServiceHTML+"</ul>").slideDown("slow");
		$("#table-business-manager").html("<ul>"+businessManagerHTML+"</ul>").slideDown("slow");
		$("#table-investment-finance-spec").html("<ul>"+investmentFinanceSpecHTML+"</ul>").slideDown("slow");
		$("#table-mortgage-spec").html("<ul>"+mortgageSpecHTML+"</ul>").slideDown("slow");
		$("#table-sp24").html("<ul>"+sp24HTML+"</ul>").slideDown("slow");
		$("#table-desktop-sa").html("<ul>"+desktopSaHTML+"</ul>").slideDown("slow");
		
		

		
	});
} 

function generateOfficeDetailsSimple(xmlFile, divID, officeRequest)
{
	var contactHTML 				= "";

	$.get(xmlFile, function(xml){

		$("region", xml).each(function(){
			var regionP = $(this);
			var regionName = regionP.attr("name");

			//COUNTRY ***************************************

			regionP.find('country').each(function(){
				var country  = $(this);
				
				// fix the recursive country issues
				var hasChildren = country.children().length > 0;
				if (hasChildren){
					var countryName = country.attr("name");
				

					//OFFICES
					country.find("offices:first").each(function(){
	
						//Each office
						$(this).find("office").each(function(){
							var office = $(this);						 	
							var officeName = office.attr("name");

							if (officeName == officeRequest){  // CORRECT OFFICE
							
								var officeAddressHTML = "";
								var address1 	= office.find('address1').text();
								var address2 	= office.find('address2').text();
								var address3 	= office.find('address3').text();
								var address4 	= office.find('address4').text();
								var city 		= office.find('city').text();
								var state 		= office.find('state').text();
								var postalcode  = office.find('postalcode').text();
								var country 	= office.find('country').text();
								var phone	 	= office.find('phone1').text();
								var mapHTML		= office.find('map-address').text();
								var ll			= office.find('ll').text();
								
								if (address1) { officeAddressHTML += "<div>"+address1+"</div>"; }
								if (address2) { officeAddressHTML += "<div>"+address2+"</div>"; }
								if (address3) { officeAddressHTML += "<div>"+address3+"</div>"; }
								if (address4) { officeAddressHTML += "<div>"+address4+"</div>"; }
								if (city) { officeAddressHTML += "<div>"+city+"</div>"; }
								if (state) { officeAddressHTML += "<div>"+state+"</div>"; }
								if (postalcode) { officeAddressHTML += "<div>"+postalcode+"</div>"; }
								if (country) { officeAddressHTML += "<div>"+country+"</div>"; }
								
								
								//var officeMapHTML = "<iframe width='655' height='550' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q="+mapHTML+"&amp;sll=[ll]&amp;sspn="+ll+"&amp;ie=UTF8&amp;z=14&amp;ll="+ll+"&amp;output=embed'></iframe>";
								
								var officeMapHTML = "<p><a href='http://maps.google.com/?q="+mapHTML+"' target=_blank>View an Interactive Map</a></p><img src='https://maps.googleapis.com/maps/api/staticmap?center="+mapHTML+"&zoom=14&size=655x550&maptype=roadmap&markers=color:green|"+mapHTML+"&sensor=false' />";
								
								$("#officeAddress").html(officeAddressHTML).slideDown("slow");
								$("#officePhone").html(phone).slideDown("slow");
								if (mapHTML) { 
									$("#officeMap").html(officeMapHTML).slideDown("slow");
								}
								
								//EMPLOYEE
								office.find("employees:first").each(function(){
				
									//Each employee
									$(this).find("employee").each(function(){
										var employee = $(this);						 	
										var supportLink = "";
										
										var employeeName = employee.attr("name");
										var employeeRole = employee.attr("role");
										
										var employeeGEID = employee.attr("webGEID");
											
										employeeLI = "<li><a target=_blank href='http://gdir.nam.nsroot.net/globaldir/gdir_resultdetail.asp?geid="+employeeGEID+"'>"+employeeName+"</a>"+supportLink+"</li>";

										if (employeeRole == "key-contact"){ contactHTML += employeeLI; }
										
									});
									//end each employee
								});
								//END EMPLOYEES								
							}// END CORRECT OFFICE
						});
						//end each office
					});
					//END OFFICES
				} // end has children
			});
			//END COUNTRY************************************	
		});
		//end each region
		
		//PUSH===============
		if (contactHTML)
		$("#table-key-contact").html("<ul>"+contactHTML+"</ul>").slideDown("slow");
	});
} 



function employeeObj(){
	this.name = "";
	this.geid = "";
	this.role = "";
	this.office = "";
}


function supportTeamObj(){
	this.office = "";
	this.assocBanker = new Array();
	this.analyst  = new Array();
	this.cao  = new Array();
	this.cso  = new Array();
	this.ic  = new Array();
}

function generateEmployeesCombined(xmlFile, divID, roleRequest)
{
	var employeeTableHTML 	=  "<table class='table stripe' id='employeesTable' >";
	employeeTableHTML 	+= "<thead><tr>";
	employeeTableHTML 	+= "<th nowrap='nowrap'>Name</th>";
	employeeTableHTML 	+= "<th>Role</th>";
	employeeTableHTML 	+= "<th>Office</th>";
	//employeeTableHTML 	+= "<th style='width:30px' width='30'></th>";
	employeeTableHTML 	+= "</tr></thead>";

	var empCount = 0;
	var empFound = 0;
	var emp = new Array();

	

	
	$.get(xmlFile, function(xml){

		$("region", xml).each(function(){
			var regionP = $(this);
			var regionName = regionP.attr("name");
			
			
			
			//COUNTRY ***************************************

			regionP.find('country').each(function(){
				var country  = $(this);
				
				// fix the recursive country issues
				var hasChildren = country.children().length > 0;
				if (hasChildren){
					var countryName = country.attr("name");
				

					//OFFICES
					country.find("offices:first").each(function(){
	
						//Each office
						$(this).find("office").each(function(){
							var office = $(this);						 	
							var officeName = office.attr("name");

								
							//EMPLOYEE
							office.find("employees:first").each(function(){
			
								//Each employee
								$(this).find("employee").each(function(){
																	   
									var employee = $(this);						 	
									empFound = 0;	
									var employeeRole = employee.attr("role");
												
									if ((employeeRole == roleRequest) || (roleRequest == null) ){
										var employeeName = employee.attr("name");
										var employeeGEID = employee.attr("webGEID");
										var realRole  = getRoleRealName(employeeRole);
										
										//for each new employee name in the xml loop through the employee array to see if there is a match
										for (x in emp){
											//officeFound = 0;
											
											if (emp[x].name == employeeName){
												empFound = 1;
												
												//see if role = role in xml
												if (emp[x].role == employeeRole){
													
													//add office to the office array
													newNumOffice = emp[x].office.length + 1;
													emp[x].office[newNumOffice] = officeName;
													//console.log(officeName);
													break;
												}else{ // END IF role found
													empFound = 0; //reset the  found flag to 0 to create a new entry
												}
												
											}
										}

										//if i didnt find the employee in the emp array create a new entry
										if (empFound == 0){
												newNum = emp.length + 1;
												//console.log(employeeName);
												
												emp[newNum] = new employeeObj();
												emp[newNum].name 		= employeeName;
												emp[newNum].geid 		= employeeGEID;
												emp[newNum].role 		= employeeRole;
												emp[newNum].office 		= new Array();
												emp[newNum].office[0] 	= officeName;
										}
										

										
									}


									
									
									
													
									
								});
								//end each employee
								
							});
							//END EMPLOYEES								
								
								
								
							
							
						});
						//end each office
						
					});
					//END OFFICES



				} // end has children
			});


			//END COUNTRY************************************	
			
			
		});
		//end each region
		
		
		//alert(emp.length);
		
		for (y in emp){

			officeH = "<ul>";
			for (k in emp[y].office){
				officeH += "<li><a href='/contactUs/office.htm?office="+emp[y].office[k]+"'>"+emp[y].office[k]+"</a>";
				// IF BANKER AND ATTACHED TO LOCATION
				//if (emp[y].role == "banker"){
				//	officeH += " <a href=\"javascript:callModal('/contactUs/employee.htm?geid="+emp[y].geid+"&loc="+emp[y].office[k]+"');\"><img src='"+viewRosterIcon+"' alt='View Banker Roster' title='View Banker Roster' /></a>";
				//}

				officeH += "</li>";

			}
			officeH += "</ul>";
			
			
					
			if (emp[y].geid){

				
				employeeHTML = "<a href=\"javascript:callModal('/contactUs/employee.htm?name="+emp[y].name+"&geid="+emp[y].geid+"');\">"+emp[y].name+"</a>";
			}else{
				employeeHTML = emp[y].name;
			}
			
			
			
			employeeTableHTML += "<tr><td>"+employeeHTML+"</td><td>"+getRoleRealName(emp[y].role)+"</td><td>"+officeH+"</td></tr>";

		}
		employeeTableHTML += "</table>";

		$("#employeesTableDiv").html(employeeTableHTML).slideDown("slow");
		
		$('#employeesTable').dataTable({
			 /*
			"bPaginate": true,
			"bLengthChange": true,
			"bFilter": false,
			"bStateSave": false
			*/
			"bLengthChange": false,
			"iDisplayLength": 20,
			"sPaginationType": "full_numbers"
		});


		$("#hiddenclicker").fancybox({
			'width'				: 450,
			'height'			: 450,
			'autoScale'     	: true,
			'transitionIn'		: 'none',
			'transitionOut'		: 'none',
			'type'				: 'iframe'
		});

		$("input#dataTableSearch").labelify({labelledClass: "labelinside"});


		
		$('input#dataTableSearch').focus(function() {
			if ($('#searchX').length == 0) {
				$(".input").append("<div id='searchX'></div>")
				$('#searchX').click(function() {
		  			resetDataTable();
				});
			}

		});
		



		
		


		
		
		
	});
	

} 




function callModal(my_href) {
	var j1 = document.getElementById("hiddenclicker");
	j1.href = my_href;
	$('#hiddenclicker').trigger('click');
}





function generateEmployees(xmlFile, divID, roleRequest)
{
	var employeeTableHTML 	=  "<table class='table stripe' id='employeesTable' >";
	employeeTableHTML 	+= "<thead><tr>";
	employeeTableHTML 	+= "<th nowrap='nowrap'>Name</th>";
	employeeTableHTML 	+= "<th>Role</th>";
	employeeTableHTML 	+= "<th>Office</th>";
	//employeeTableHTML 	+= "<th style='width:30px' width='30'></th>";
	employeeTableHTML 	+= "</tr></thead>";


	

	
	$.get(xmlFile, function(xml){

		$("region", xml).each(function(){
			var regionP = $(this);
			var regionName = regionP.attr("name");
			
			
			
			//COUNTRY ***************************************

			regionP.find('country').each(function(){
				var country  = $(this);
				
				// fix the recursive country issues
				var hasChildren = country.children().length > 0;
				if (hasChildren){
					var countryName = country.attr("name");
				

					//OFFICES
					country.find("offices:first").each(function(){
	
						//Each office
						$(this).find("office").each(function(){
							var office = $(this);						 	
							var officeName = office.attr("name");

								
							//EMPLOYEE
							office.find("employees:first").each(function(){
			
								//Each employee
								$(this).find("employee").each(function(){
																	   
									var employee = $(this);						 	
									empFound = 0;	
									var employeeRole = employee.attr("role");
												
									if ((employeeRole == roleRequest) || (roleRequest == null) ){
										var employeeName = employee.attr("name");
										var employeeGEID = employee.attr("webGEID");
										var realRole  = getRoleRealName(employeeRole);
										
										var officeHTML = "<a href='/contactUs/office.htm?office="+officeName+"'>"+officeName+"</a>";
										if (employeeGEID){
											employeeHTML = "<a target='_new' href='"+gdURL+"?name="+employeeName+"&webGEID="+employeeGEID+"'>"+employeeName+"</a>";
											//contactHTML = "<a target='_new' href='"+gdURL+employeeGEID+"'><img src='/common-media/images/contact-card.gif'></a>";
										}else{
											employeeHTML = employeeName;
											//contactHTML = "";
										}
										
										employeeTableHTML += "<tr><td>"+employeeHTML+"</td><td>"+realRole+"</td><td>"+officeHTML+"</td></tr>";

										
									}


									
									
									
													
									
								});
								//end each employee
								
							});
							//END EMPLOYEES								
								
								
								
							
							
						});
						//end each office
						
					});
					//END OFFICES



				} // end has children
			});


			//END COUNTRY************************************	
			
			
		});
		//end each region
		
		
		//alert(emp.length);
		
	
		
		
		employeeTableHTML += "</table>";
		$("#employeesTableDiv").html(employeeTableHTML).slideDown("slow");
		
		$('#employeesTable').dataTable({
			 /*
			"bPaginate": true,
			"bLengthChange": true,
			"bFilter": false,
			"bStateSave": false
			*/
			"bLengthChange": false,
			"iDisplayLength": 20,
			"sPaginationType": "full_numbers"
		});

		$("input#dataTableSearch").labelify({labelledClass: "labelinside"});


		
		$('input#dataTableSearch').focus(function() {
			if ($('#searchX').length == 0) {
				$(".input").append("<div id='searchX'></div>")
				$('#searchX').click(function() {
		  			resetDataTable();
				});
			}

		});
		
		


		
		
		
	});
	

} 


function resetDataTable(){
	$('input#dataTableSearch').val("");
	$('input#dataTableSearch').keyup();
	$('#searchX').remove();
	$("input#dataTableSearch").labelify({labelledClass: "labelinside"});
}




function getRoleRealName(role){
	switch (role) {
		case "banker": result = 'Banker'; break;
		case "gmm": result = 'GMM'; break;
		case "regionalMD-teamlead": result = 'Regional MD or Team Lead'; break;
		case "service-manager": result = 'Service Manager'; break;
		case "service-director": result = 'Service Director'; break;
		case "head-service": result = 'Head of Service'; break;
		case "business-manager": result = 'Business Manager'; break;
		case "investment-finance-spec": result = 'Investment Finance Specialist'; break;
		case "mortgage-spec": result = 'Mortgage Specialist'; break;
		case "sp24": result = 'SP 24'; break;
		case "desktop-sa": result = 'Desktop SA'; break;
		default: result = 'All';
	}
	return result;

}

function getLocRealName(location){
	if (location){
		result  = location;
	}else{
		result  = "All";
	}
	
	return result;

}




function generatePubLinkList(xmlFile, divID, basePage)
{
	var allHtml = "";
	var currentLink = "";
	//var quadrantLink = "/investments/quadrant/";
	var html = "<select onchange='window.location.href=this.options[this.selectedIndex].value;'>";
	html += "<option>- Archive -</option>";
	

	$.get(xmlFile, function(xml){

		$("item", xml).each(function(){
			var itemP = $(this);
			var pub	  = itemP.find('publication');
			var publicationMonth = pub.find('month').text();
			var publicationYear = pub.find('year').text();
			
			if (currentLink == ""){
				currentLink = "<a href='"+basePage+"?monthID="+publicationMonth+"&yearID="+publicationYear+"'>Current Issue ("+getMonthName(publicationMonth)+" "+publicationYear+")</a>";
			}
			
			html += "<option value='"+basePage+"?monthID="+publicationMonth+"&yearID="+publicationYear+"'>"+getMonthName(publicationMonth)+" "+publicationYear+"</option>";
		});
		html += "</select>";
		
		allHtml = currentLink +"<br />"+ html;
		$(divID).html(allHtml).slideDown("slow");
	});
} 





function getCategoryHTML(catID){
	// NOT GOING TO USE THIS
	var cat_1 = "Attract, develop and retain top talent";
	var cat_2 = "Focus on UHNW client segment";
	var cat_3 = "World class product platform";
	var cat_4 = "Consistent client proposition and experience";
	var cat_5 = "Repositioning the US franchise";
	
	if (catID == 1) catHTML = cat_1;
	if (catID == 2) catHTML = cat_2;
	if (catID == 3) catHTML = cat_3;
	if (catID == 4) catHTML = cat_4;
	if (catID == 5) catHTML = cat_5;
	
	return catHTML;
}


function generateListTest(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, showCategory, numItems, categoryTitle)
{
	var html = '';
	var catTitleHTML = '';

	if (categoryTitle == null){
		var categoryTitle = "";
	}else{	
		catTitleHTML = "<h2>Category: "+categoryTitle+"</h2>";
	}
	
	html += '<ul>';
	var count = 0;
	var linkP = "";
	
	if (showFirstItem != 0){
			numItems = numItems - 1;
	}
	
	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");
		$("item", xml).each(function(){
			
			var $item = $(this);
			var categoryMatch = 0;
			var description = $item.find('description').text();
			var categoryDiv = "";

			if (categoryTitle == "") categoryMatch = 1;
				
			// CATEGORY
			$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if (categoryDiv) categoryDiv += ", ";	
					catLink = "generateListTest(\""+xmlFile+"\",\""+divID+"\","+showDate+","+showDesc+","+showImage+","+showFirstItem+","+showCategory+",999,\""+itemCategoryName+"\")";
					categoryDiv += "<a href='javascript:"+catLink+"'>"+itemCategoryName+"</a>"; 
					
					if (categoryTitle == itemCategoryName){
						categoryMatch = 1;
					}
			});			

			var linkP = $item.find('link').text();
			//alert(description);
				
			if ( ((showFirstItem == 0)&&(count == 0)) || (categoryMatch == 0) ){
			}else{
				html += "<li>";
				$(this).find("image").each(function(){
					// IMAGE 	
					if (showImage){	html += "<a href='" + linkP + "'><img class='image-main' src='" + getNodeText(this) + "'></a>"; }
				}).end().find("link").each(function(){
						//linkP = getNodeText(this);
						html += "<div class='title'><a href='" + linkP +"'>";
				}).end().find("title").each(function(){
						html += getNodeText(this) + "</a></div>";
				}).end().find("pubDate").each(function(){
					// DATE 	
					if (showDate){	html += "<div class='date'>" + getNodeText(this) + "</div>"; }
				}).end().find("description").each(function(){
					// DECRIPTION
					if ((showDesc)&&(description)){	html += "<div class='description'>" + description +"</div>"; }
				});
				
				//CATEGORY
				if ((showCategory)&&(categoryDiv)){ html += "<div class='category'>Category: " + categoryDiv + "</div>"; }
		
				html += "<div class='clear'></div></li>";
			}


			if (count == numItems){ return false; }				
			count = count + 1;


		});
		html += "</ul>";
		
		$(divID).html(html).slideDown("slow");
		$("#catTitle").html(catTitleHTML).slideDown("slow");
	});
} 



function generateListAll(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, showCategory, numItems, categoryTitle, authorName)
{
	// This function is used on the announcement index pages
		
	var html = '';
	var catTitleHTML = '';


	if (authorName){
		catTitleHTML = "<h2>Author: "+authorName+"</h2>";
	}else if (categoryTitle == null){
		var categoryTitle = "";
		catTitleHTML = "<h2>Category: All</h2>";
	}else{	
		catTitleHTML = "<h2>Category: "+categoryTitle+"</h2>";
	}
	
	html += '<ul>';
	var count = 0;
	var linkP = "";
	

	
	if (showFirstItem != 0){
			numItems = numItems - 1;
	}
	

	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(){
			
			var $item = $(this);
			var itemMatch = 0;
			//var author = $item.find('author').text();
			var description = $item.find('description').text();
			var categoryDiv = "";
			var authorDiv = "";			

			if (categoryTitle == "") itemMatch = 1;
				
			// CATEGORY
			$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if (categoryDiv) categoryDiv += "; ";	
					catLink = "generateListAll(\""+xmlFile+"\",\""+divID+"\","+showDate+","+showDesc+","+showImage+","+showFirstItem+","+showCategory+",999,\""+itemCategoryName+"\")";
					categoryDiv += "<a href='javascript:"+catLink+"'>"+itemCategoryName+"</a>"; 
					
					if (categoryTitle == itemCategoryName){
						itemMatch = 1;
					}
					
			});			
			// END CATEGORY


			// AUTHOR 
			$(this).find("author").each(function(){
					itemAuthorName = getNodeText(this);							   
					if (authorDiv) authorDiv += ", ";	
					
					authorDiv += "<a href=\"?author="+itemAuthorName+"\"> " + itemAuthorName + "</a>"; 
					
					if (authorName == itemAuthorName){
						itemMatch = 1;
					}
					
			});	
			// END AUTHOR


			
			var linkP = $item.find('link').text();
			//alert(description);
				
			if ( ((showFirstItem == 0)&&(count == 0)) || (itemMatch == 0) ){
			}else{
				html += "<li>";
			
				html += "<div>";
			
					$(this).find("link").each(function(){
							//linkP = getNodeText(this);
							html += "<div class='title'><a href='" + linkP +"'>";
					}).end().find("title").each(function(){
							html += getNodeText(this) + "</a></div>";
					}).end().find("pubDate").each(function(){
						// DATE 	
						if (showDate){	html += "<div class='date'>" + getNodeText(this) + "</div>"; }
					});
					
					//AUTHOR
					if (authorDiv){ html += "<div class='author'>by " + authorDiv + "</div>"; }
					
				
				html += "</div>";
				
				$(this).find("image").each(function(){
					// IMAGE
					if (showImage){	html += "<a href='" + linkP + "'><div class=\"story-thumb-wrapper\"><div class=\"story-thumb\"><img src='" + getNodeText(this) + "'></div></div></a>"; }
				}).end().find("description").each(function(){
					// DECRIPTION
					if ((showDesc)&&(description)){	html += "<div class='description'>" + description +"</div>"; }
				});
				
				//CATEGORY
				if ((showCategory)&&(categoryDiv)){ html += "<div class='category'>Category: " + categoryDiv + "</div>"; }
		
				html += "<div class='clear'></div></li>";
	
				count = count + 1;

			}

			if (count == numItems){ return false; }				


		});
		html += "</ul>";
		
		$(divID).html(html).slideDown("slow");
		$(".story-thumb").corner("8px cc:#ffffff");
		//$(".story-thumb").css("border", "solid 1px red");
		$("#catTitle").html(catTitleHTML).slideDown("slow");

	});
} 





//function generateListBlogs(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, showCategory, numItems, categoryTitle, authorName)
function generateListBlogs(divID, params)
{
	
	//DEFAULTS
	var sys = new Object();
	sys.showDate = 1;
	sys.showDesc = 1;
	sys.showImage = 1;
    sys.showAuthorImage = 1;
	sys.showFirstItem = 1; 
	sys.showCategory = 1; 
	sys.showSocial = 1;
	sys.numItems = 5; 
	sys.categoryTitle = "";
	sys.authorName = "";
    sys.isBlogHP = 0;

	
	//OPTIONS
	if (params.showDate != null) sys.showDate = params.showDate;
	if (params.showDesc != null) sys.showDesc = params.showDesc;
	if (params.showImage != null) sys.showImage = params.showImage;
	if (params.showAuthorImage != null) sys.showAuthorImage = params.showAuthorImage;
	if (params.showFirstItem != null) sys.showFirstItem = params.showFirstItem; 
	if (params.showCategory != null) sys.showCategory = params.showCategory; 
	if (params.showSocial != null) sys.showSocial = params.showSocial; 
	if (params.numItems) sys.numItems = params.numItems; 
	if (params.categoryTitle) sys.categoryTitle	= params.categoryTitle;
	if (params.authorName) sys.authorName = params.authorName;
    if (params.isBlogHP != null) sys.isBlogHP = params.isBlogHP; 

// This function is used on the announcement index pages
		
	var html = '';
	var catTitleHTML = '';
	sys.numItems = sys.numItems + 1 ;

	if (sys.authorName){
		catTitleHTML = "<h2>Author: "+sys.authorName+"</h2>";
	}else if (sys.categoryTitle == null){
		sys.categoryTitle = "";
		//catTitleHTML = "<h2>Category: All</h2>";
	}else{	
		catTitleHTML = "<h2>Category: "+sys.categoryTitle+"</h2>";
	}
	
	html += '<ul class="blog-long">';
	var count = 0;
	var linkP = "";
	var blogIDArray = new Array;
	
	if (sys.showFirstItem != 0){ sys.numItems = sys.numItems - 1; }
	

	$.get(globalBlogXML, function(xml){
		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(k){
			
			
			
			var $item = $(this);
			var blogID = $item.attr("blogID");
			blogIDArray[k] = blogID;
			var itemMatch = 0;
			//var author = $item.find('author').text();
			var description = $item.find('description').text();
			var blogUserImage = $item.find('blogUserImage').text();
			var itemTitle = $item.find('title').text();
			var pubdate = $item.find('pubDate').text();
			var categoryDiv = "";
			var authorDiv = "";			
			var commentCountHTML = "";			
			var commentCount = 0;
			var likeCount = 0;
//			var likeHTML = getLikesCount(blogID);
			
//			alert(likeHTML);

 
			//alert("authorName: "+authorName);
			if ((sys.categoryTitle == "") && (!sys.authorName)) itemMatch = 1;
				
			// CATEGORY
			$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if (categoryDiv) categoryDiv += "; ";	
					categoryDiv += "<a href='"+globalBlogURL+"?cat="+itemCategoryName+"'>"+itemCategoryName+"</a>"; 
					
					if (sys.categoryTitle == itemCategoryName){
						itemMatch = 1;
					}
					
			});			
			// END CATEGORY


			// AUTHOR 
			$(this).find("author").each(function(){
					itemAuthorName = getNodeText(this);							   
					if (authorDiv) authorDiv += ", ";	
					
					authorDiv += "<a href='"+globalBlogURL+"?author="+itemAuthorName+"'>" + itemAuthorName + "</a>"; 
					
					if (sys.authorName == itemAuthorName){
						itemMatch = 1;
					}
					
			});	
			// END AUTHOR


			// COMMENTS 
			$(this).find("comment").each(function(){
					++commentCount;
			});	
			var coms = "Comments";
			if (commentCount == 1) coms = "Comment";
			commentCountHTML = "<span class='commentCount'><a href=\""+globalBlogURL+"?blogID="+blogID+"#comments\">(" + commentCount + ") "+coms+"</a></span>"; 
			// END comments

			//LIKES
			

			
			//var linkP = $item.find('link').text();
			//alert(description);
				
			if ( ((sys.showFirstItem == 0)&&(count == 0)) || (itemMatch == 0) ){
			}else{
				
				
				

	


				//alert(likeHTML);


				html += "<li id='blog-"+blogID+"'>";

				if (sys.showImage) html += "<div class=\"blogUserImage\"><a href=\"?author="+itemAuthorName+"\"><img src='"+blogUserImage+"' /></a></div>";
				if (sys.showAuthorImage){
                    html += "<div class=\"blogContent\">";
                }else{
                    html += "<div class=\"blogContentWOAI\">";
                }
				html += "	<div class=\"hd\">";
				html += "		<div class='title'><a href='"+globalBlogURL+"?blogID="+blogID+"'>"+itemTitle+"</a></div>";
				if (sys.showDate) html += "		<div class='date'>" + pubdate +  "</div>";
				html += "		<div class='author'>by " + authorDiv + "</div>";
				if (sys.showSocial) html += "		<div class='social'><div class='rr-middle'><div class='rr-right'>" + commentCountHTML +" "+ "<span class='iLikeCount-off' id='iLike-"+blogID+"'></span></div></div></div>";
				html += "	</div>";
				if (sys.showDesc) html += "	<div class='description'>" + description +"</div>"; 
				html += "</div>"; 
	
				//CATEGORY
				if ((sys.showCategory)&&(categoryDiv)){ html += "<div class='category'>Category: " + categoryDiv + "</div>"; }
				
				
				html += "<div class='clear'></div>";
				html += "</li>";

				count = count + 1;
				
			}

			
			if (count == sys.numItems){ return false; }				


		});

		html += "</ul>";
		$(divID).html(html).slideDown("slow");

		if (sys.isBlogHP) $("#content-hd").append("<div id='catTitle'>"+catTitleHTML+"</div>");
		
		$.each(blogIDArray, function() { 
  			//alert(this); 
			getLikesCount(this);
			
		});
		
		


	});
} 



function generateBlog(xmlFile, divID, blogID)
{
	var html = '';

	$.get(xmlFile, function(xml){
		var itemMatch = 0;

		$("item", xml).each(function(){
			

			if ($(this).attr("blogID")==blogID){
			// IN BLOGID *************************************************************************

				var $item = $(this);
				var itemTitle = $item.find('title').text();
				var pubdate = $item.find('pubDate').text();
				var description = $item.find('description').text();
				var blogUserImage = $item.find('blogUserImage').text();
				var categoryDiv = "";
				var authorDiv = "";			
				var commentCountHTML = "";			
				var commentCount = 0;
				var commentsHTML = "";			
				itemMatch = 1;
					
				// CATEGORY ------------------------------------------------------
				$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if (categoryDiv) categoryDiv += "; ";	
					categoryDiv += "<a href='?cat="+itemCategoryName+"'>"+itemCategoryName+"</a>"; 
				});			
				// END CATEGORY ---------------------------------------------------
	
				// AUTHOR ---------------------------------------------------------
				$(this).find("author").each(function(){
					itemAuthorName = getNodeText(this);							   
					if (authorDiv) authorDiv += ", ";	
					
					authorDiv += "<a href=\"?author="+itemAuthorName+"\"> " + itemAuthorName + "</a>"; 
				});	
				// END AUTHOR -----------------------------------------------------
	
				// COMMENTS -------------------------------------------------------
				commentsHTML = "<div class='list-comments'>";
				commentsHTML += "<ul>";
				$(this).find("comment").each(function(){
					commentsHTML += "<li>";
					commentsHTML += "	<div class='commentAuthor'><span class='authorName'>"+ $(this).attr("author") + "</span> says:</div>"
					commentsHTML += "	<div class='commentDescription'>"+ getNodeText(this) +"</div>";
					commentsHTML += "</li>";
					++commentCount;
				});	
				commentsHTML += "</ul>";
				commentsHTML += "</div>";
				
				//
				
				var coms = "Comments";
				if (commentCount == 1) coms = "Comment";				
				commentCountHTML = "<span class='commentCount'><a href=\"#comments\">(" + commentCount + ") "+coms+"</a></span>"; 
				// END comments ---------------------------------------------------

				html += "<ul>";
				html += "<li>";
				html += "<div class=\"blogUserImage\"><a href=\"?author="+itemAuthorName+"\"><img src='"+blogUserImage+"' /></a></div>";
				html += "<div class=\"blogContent\">";

/*				html += "	<div class=\"hd\">";
				html += "		<div class='title'>"+itemTitle+"</div>";
				html += "		<div class='date'>" + pubdate + " "+ commentCountHTML +" "+ "<span class='iLikeCount-off' id='iLike-"+blogID+"'></span> </div>"; 

				html += "		<div class='author'>by " + authorDiv + "</div>"; 
				html += "	</div>";
*/
				html += "	<div class=\"hd\">";
				html += "		<div class='title'><a href='?blogID="+blogID+"'>"+itemTitle+"</a></div>";
				html += "		<div class='date'>" + pubdate +  "</div>";
				html += "		<div class='author'>by " + authorDiv + "</div>";
				html += "		<div class='social'><div class='rr-middle'><div class='rr-right'>" + commentCountHTML +" "+ "<span class='iLikeCount-off' id='iLike-"+blogID+"'></span></div></div></div>";
				html += "	</div>";

				html += "	<div class='description'>" + description +"</div>";
				html += "	<div class='category'>Category: " + categoryDiv + "</div>";

				html += "	<a name='comments'></a>";
				html += "	<div class='commentsHead'>";
				html += "		"+commentCount+" "+coms+"&nbsp;&nbsp;<a href='#commentsAdd' id='addac'>(Add a comment)</a>";
				/*	
				html += "		<span style='padding:0px 6px'>|</span>";

				html += "		<span id='iLikeThisCount-"+blogID+"'></span>";
				html += "		<span class='iLikeThis-off'  id='iLikeThis-"+blogID+"'>";
				html += "			<a href='javascript:iLikeIt("+blogID+");'>(Like this post)</a>";
				html += "		</span>";
				*/
				html += "	</div>"; 
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				if (commentCount > 0) html += "<a name='comments'></a><div class='comments'>" + commentsHTML + "</div>";
				
				html += "	<a name='commentsAdd'></a>";
				html += "	<div class='commentsAdd'>";
				html += "		<h3>Add a comment</h3>";
				//html += "		<p>NOTE: When you submit a comment, it will not appear immediately, so please check back later. Once it appears, it will be viewable by all Private Bank employees globally who visit this site.By submitting a comment, you are agreeing to the <a href='/common-media/blog-terms-conditions.pdf#page=1' target='_blank'>terms and conditions</a> for this site. Please exercise good judgment and common sense when commenting<!-- -here are some <a href='/common-media/blog-terms-conditions.pdf#page=3' target='_blank'>best practices</a> to guide you-->.</p>";
				html += "		<p>NOTE: When you submit a comment, it will not appear immediately, so please check back later. Content submitted will be monitored and reviewed; inappropriate, offensive or unlawful content will not be posted and/or will be removed from the site. Posted content will be viewable by all users globally who visit this site. Please exercise good judgment and common sense when commenting. Only comments submitted by CPB employees will be considered for posting.</p>";
				html += "		<div id=\"commentBlock\">";
				html += "			<form name=\"commentForm\" id=\"commentForm\" method=\"post\" enctype=\"text/plain\"> ";
				//html += "				<div class='formFieldTitle'>Name</div>";
				//html += "				<input type='text' size='30' id='comment-name' />";
				html += "				<div class='formFieldTitle'><div class='fmt-l'>Comment <img src=\"/common-media/images/icon-comment-sm-r.gif\"></div>  <div class='fmt-r'><span id='word-count-wrap'><span id='word-count'>200</span> words left</span></div>  </div>";
				html += "				<textarea onkeypress='checkWordLen(this);' cols='60' rows='12' name='comment' id='comment-text'></textarea>";
				html += "				<input type='hidden' name='Post Title' value='"+itemTitle+" \n'>";
				
				html += "				<div class='formFieldTitle'>Terms and Conditions</div>";
				html += "				<iframe class=\"tandcFrame\" src=\"/blog/tandc.htm\" width=\"500px\" height=\"140px\">Please review the Terms and Conditions</iframe>";
				html += "				<div class=\"tnc\"><input type=\"checkbox\" name=\"termsAndConditions\" value=\"accepted\"> I've read and accept these Terms and Conditions <span class=\"required\">*</span></div>";
				//html += "				<div id='commentButton'><input onclick=\"submitBlogComment();\" type='submit' value='Submit' id='comment-submit'></div>";
				
				html += "				<a href='javascript:void(0);' onclick=\"submitBlogComment("+blogID+");\" class=\"btnFlexible comment-submit\"><span>Submit Comment</span></a>";
				
				html += "			</form>";
				html += "		</div>";
				html += "	</div>";
				html += "</div>";
				html += "</li>";
				html += "</ul>";
		
		


		
				$(divID).html(html).slideDown("slow");		
				getLikesCount(blogID);
			
			} // END IF BLOG ID




			if (itemMatch == 1){ return false; }	 // BREAK OUT OF ITEM LOOP		
	
		}); // END ITEM LOOP
		






		//$(".story-thumb").corner("8px cc:#ffffff");
		//$(".story-thumb").css("border", "solid 1px red");
		//$("#catTitle").html(catTitleHTML).slideDown("slow");

	});
} 



//function generateListBlogsSimple(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, showCategory, numItems, categoryTitle, authorName)
function generateListBlogsSimple(divID, params)
{

	//DEFAULTS
	var sys = new Object();
	var firstItem = 0;
	
	
	sys.showFirstItem = 1; 
	
	sys.showFirstItem_Date = 1;
	sys.showFirstItem_Desc = 1;
	sys.showFirstItem_Image = 1;
	sys.showFirstItem_Teaser = 1;
    sys.showFirstItem_AuthorImage = 1;
    sys.showFirstItem_Author = 1;
	sys.showFirstItem_FirstItem = 1; 
	sys.showFirstItem_Category = 1; 
	sys.showFirstItem_Social = 1;
	sys.showFirstItem_Comments = 1;
	
	sys.showDate  = 0;
	sys.showDesc = 0;
	sys.showImage = 0;
    sys.showAuthorImage = 0;
	sys.showTeaser = 0;
    sys.showAuthor = 0;
	sys.showComments = 0;

	sys.showCategory = 0; 
	sys.showSocial = 0;
	
	sys.numItems = 5; 
	sys.categoryTitle = "";
	sys.authorName = "";
    
	
	//OPTIONS
	if (params.showFirstItem != null) sys.showFirstItem = params.showFirstItem; 
	
	if (params.showFirstItem_Date != null) sys.showFirstItem_Date = params.showFirstItem_Date;
	if (params.showFirstItem_Desc != null) sys.showFirstItem_Desc = params.showFirstItem_Desc;
	if (params.showFirstItem_Image != null) sys.showFirstItem_Image = params.showFirstItem_Image;
	if (params.showFirstItem_AuthorImage != null) sys.showFirstItem_AuthorImage = params.showFirstItem_AuthorImage;
	if (params.showFirstItem_Author != null) sys.showFirstItem_Author = params.showFirstItem_Author;
	if (params.showFirstItem_Social != null) sys.showFirstItem_Social = params.showFirstItem_Social; 
	if (params.showFirstItem_Category != null) sys.showFirstItem_Category = params.showFirstItem_Category; 
	if (params.showFirstItem_Teaser != null) sys.showFirstItem_Teaser = params.showFirstItem_Teaser; 
	if (params.showFirstItem_Comments!= null) sys.showFirstItem_Comments = params.showFirstItem_Comments; 
	
	if (params.showDate != null) sys.showDate = params.showDate;
	if (params.showDesc != null) sys.showDesc = params.showDesc;
	if (params.showImage != null) sys.showImage = params.showImage;
	if (params.showAuthorImage != null) sys.showAuthorImage = params.showAuthorImage;
	if (params.showAuthor != null) sys.showAuthor = params.showAuthor;
	if (params.showSocial != null) sys.showSocial = params.showSocial; 
	if (params.showCategory != null) sys.showCategory = params.showCategory; 
	if (params.showTeaser != null) sys.showTeaser = params.showTeaser; 
	if (params.showComments != null) sys.showComments = params.showComments; 

	if (params.numItems) sys.numItems = params.numItems; 
	if (params.categoryTitle) sys.categoryTitle	= params.categoryTitle;
	if (params.authorName) sys.authorName = params.authorName;

	
	
	
	// This function is used on the announcement index pages
		
	var html = '';
	var catTitleHTML = '';


	if (sys.authorName){
		catTitleHTML = "<h2>Author: "+sys.authorName+"</h2>";
	}else if (sys.categoryTitle == null){
		 sys.categoryTitle = "";
		//catTitleHTML = "<h2>Category: All</h2>";
	}else{	
		catTitleHTML = "<h2>Category: "+sys.categoryTitle+"</h2>";
	}
	
	html += '<ul>';
	var count = 0;
	var linkP = "";
	var blogIDArray = new Array;
	
	if (sys.showFirstItem != 0){ sys.numItems = sys.numItems - 1; }
	$.get(globalBlogXML, function(xml){
		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(k){
			
			var $item = $(this);
			var blogID = $item.attr("blogID");
			blogIDArray[k] = blogID;
			var itemMatch = 0;
			//var author = $item.find('author').text();
			var teaser = $item.find('teaser').text();
			//var description = $item.find('description').text();
			//var blogUserImage = $item.find('blogUserImage').text();
			var itemTitle = $item.find('title').text();
			var pubdate = $item.find('pubDate').text();
			var categoryDiv = "";
			var authorDiv = "";			
			var commentCountHTML = "";			
			var commentCount = 0;
			var likeCount = 0;
//			var likeHTML = getLikesCount(blogID);
			
//			alert(likeHTML);

 

			if (sys.categoryTitle == "") itemMatch = 1;
				
				
			// CATEGORY
			$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if (categoryDiv) categoryDiv += "; ";	
					categoryDiv += "<a href='/blog/?cat="+itemCategoryName+"'>"+itemCategoryName+"</a>"; 
					
					if (sys.categoryTitle == itemCategoryName){
						itemMatch = 1;
					}
					
			});			
			// END CATEGORY


			// AUTHOR 
			$(this).find("author").each(function(){
					itemAuthorName = getNodeText(this);							   
					if (authorDiv) authorDiv += ", ";	
					
					authorDiv += "<a href=\"/blog/?author="+itemAuthorName+"\">" + itemAuthorName + "</a>"; 
					
					if (sys.authorName == itemAuthorName){
						itemMatch = 1;
					}
					
			});	
			// END AUTHOR


			// COMMENTS 
			$(this).find("comment").each(function(){
					++commentCount;
			});	
			var coms = "Comments";
			if (commentCount == 1) coms = "Comment";
			commentCountHTML = "<span class='commentCount'><a href=\"/blog/?blogID="+blogID+"#comments\">(" + commentCount + ") "+coms+"</a></span>"; 
			// END comments

			//LIKES
			
			
			if (itemMatch && count==0) firstItem = 1;
			else firstItem = 0;

			
				
			if ( ((sys.showFirstItem == 0)&&(firstItem)) || (itemMatch == 0) ){
			}else{
				
				
				

	


				//alert(likeHTML);


				
				
				
				//FIRST FOUND ITEM
				if (firstItem){
					
					html += "<li class='firstItem' id='blog-"+blogID+"'>";
					//html += "<div class=\"blogUserImage\"><a href=\"?author="+itemAuthorName+"\"><img src='"+blogUserImage+"' /></a></div>";
					html += "<div class=\"blogContent\">";
					html += "	<div class=\"hd\">";
					html += "		<div class='title'><a href='/blog/?blogID="+blogID+"'>"+itemTitle+"</a></div>";
					if (sys.showFirstItem_Date) html += "		<div class='date'>" + pubdate +  "</div>";
					if (sys.showFirstItem_Author)html += "		<div class='author'>by " + authorDiv + "</div>";
					//html += "		<div class='social'><div class='rr-middle'><div class='rr-right'>" + commentCountHTML +" "+ "<span class='iLikeCount-off' id='iLike-"+blogID+"'></span></div></div></div>";
					html += "	</div>";
					if (sys.showFirstItem_Teaser) html += "	<div class='description'>" + teaser +"...</div>"; 
					html += "</div>"; 
		
					if (sys.showFirstItem_Comments) html += "		<div class=\"comments\">" + commentCountHTML +"</div>";
					//CATEGORY
					//if ((showCategory)&&(categoryDiv)){ html += "<div class='category'>Category: " + categoryDiv + "</div>"; }
					html += "<div class='clear'></div>";
					html += "</li>";
					

				}else{
				
					html += "<li class='restItem' id='blog-"+blogID+"'>";
					//html += "<div class=\"blogUserImage\"><a href=\"?author="+itemAuthorName+"\"><img src='"+blogUserImage+"' /></a></div>";
					html += "<div class=\"blogContent\">";
					html += "	<div class=\"hd\">";
					html += "		<div class='title'><a href='/blog/?blogID="+blogID+"'>"+itemTitle+"</a></div>";
					if (sys.showDate) html += "		<div class='date'>" + pubdate +  "</div>";
					if (sys.showAuthor) html += "		<div class='author'>by " + authorDiv + "</div>";
					//html += "		<div class='social'><div class='rr-middle'><div class='rr-right'>" + commentCountHTML +" "+ "<span class='iLikeCount-off' id='iLike-"+blogID+"'></span></div></div></div>";
					html += "	</div>";
					if (sys.showTeaser) html += "	<div class='description'>" + teaser +"...</div>"; 
					html += "</div>"; 
		
					if (sys.showComments) html += "		<div class=\"comments\">" + commentCountHTML +"</div>";
					//CATEGORY
					//if ((showCategory)&&(categoryDiv)){ html += "<div class='category'>Category: " + categoryDiv + "</div>"; }
					html += "<div class='clear'></div>";
					html += "</li>";
				
				}
				//end first item
				
				
				
				
				
				

				
			}

			
			if (count == sys.numItems){ return false; }				
			
			if (itemMatch) count = count + 1;


		});

		html += "</ul>";
		$(divID).html(html).slideDown("slow");

		$("#content-hd").append("<div id='catTitle'>"+catTitleHTML+"</div>");
		
		/*$.each(blogIDArray, function() { 
  			//alert(this); 
			getLikesCount(this);
			
		});
		*/
		


	});
} 






function generatePoliciesList(xmlFile, divID, categoryTitle, section)
{
	// Assumptions
	// Only 4 sections (Initiating, Transacting, Maintaining, Closing)
	
	var allHtml = "<ul>";


	$.get(xmlFile, function(xml){

		$("item", xml).each(function(){
									 
			var categoryMatch 	= 0;				 
			var sectionMatch 	= 0;				 
			
			if (categoryTitle == "") categoryMatch = 1;

			var itemP 		= $(this);

			// CATEGORY
			itemP.find("category").each(function(){
				itemCategoryName = getNodeText(this);							   
				//if (categoryDiv) categoryDiv += ", ";	
				if (categoryTitle == itemCategoryName){
					categoryMatch = 1;
				}
			});											 
									 
			// Section
			itemP.find("sections:first").each(function(){			
												
									
				$(this).find("section").each(function(){
					itemSectionName = getNodeText(this);							   
					if (section == itemSectionName){
						sectionMatch = 1;
					}
				});		
				
			});	
			
			
			if (categoryMatch && sectionMatch){
				
				var title		= itemP.find('title').text();
				var linkP		= itemP.find('link').text();
				var subTitle	= itemP.find('subTitle').text();
	
				if (subTitle) subTitleHtml = "<span class=\"sub-info\">"+subTitle+"</span>";
				else subTitleHtml = "";
				
				allHtml += "<li><a href=\""+linkP+"\">"+ title +"</a>" + subTitleHtml + "</li>";
			}
			

		});
		allHtml += "</ul>";
		

		$(divID).html(allHtml).slideDown("slow");
	});
} 












function getLikesCount(blogID){
	likesCount = 0;
//	jURL = "http://169.188.198.190/json.php?postid="+blogID+"&jsoncallback=?";
	jURL = blogJSP+"?requestType=1&postId="+blogID+"&jsoncallback=?";
	
	//alert(jURL);
	
	$.getJSON(jURL ,function(dataP) { 
	
		$.each(dataP.posts, function(i,itemP){
				
				$.each(itemP, function(j,postP){
					
					if (postP['postid'] == blogID){
						
						likesLinkHTML = "<a class='helpful' href=\"javascript:iLikeIt("+postP['postid']+")\"> I find this helpful</a>";
						
						
						// if cookie exists change the class to the on state
						if ($.cookie('iLike-'+blogID)){

							likesLinkHTML = "including you";

							$("#iLike-"+blogID).removeClass('iLikeCount-off').addClass('iLikeCount-on');
							//$("#iLikeThis-"+blogID).removeClass('iLikeThis-off').addClass('iLikeThis-on');
							
						}
	
						likesCount = "<span>("+postP['postcounter']+") People found this helpful</span> - "+likesLinkHTML;
						likesCountNoLink = postP['postcounter']+" Likes";

						$("#iLike-"+blogID).html(likesCount).slideDown("slow");
						//$("#iLikeThisCount-"+blogID).html(likesCountNoLink).slideDown("slow");
						
	

						//alert($.cookie('iLike-'+blogID));
					}
					
				});
			});
	

//	alert("in");

	});
			
	return likesCount;
}


function iLikeIt(blogID){
	if ($.cookie('iLike-'+blogID)){
		alert("You already like this post.");
	}else{


		jURL = blogJSP+"?requestType=2&postId="+blogID+"&jsoncallback=?";
		
		//alert(jURL);
		
		$.getJSON(jURL ,function(dataP) { 
		
			$.each(dataP.posts, function(i,itemP){
					
					$.each(itemP, function(j,postP){
						
						if (postP['postid'] == blogID){
							
							likesLinkHTML = "Including you";
							//likesCount = "<a href=\"?blogID="+blogID+"#comments\">("+postP['postcounter']+") Likes</a>";
							likesCount = "<span style='color:#333;'>("+postP['postcounter']+") People found this helpful.</span> - "+likesLinkHTML;

							
							$("#iLike-"+blogID).html(likesCount).slideDown("slow");
							//$("#iLikeThisCount-"+blogID).html(likesCount).slideDown("slow");
							/*
							// if cookie exists change the class to the on state
							if ($.cookie('iLike-'+blogID)){
								$("#iLike-"+blogID).removeClass('iLikeCount-off').addClass('iLikeCount-on');
								$("#iLikeThis-"+blogID).removeClass('iLikeThis-off').addClass('iLikeThis-on');
							}
	
							//alert($.cookie('iLike-'+blogID));
							*/
						}
						
					});
				});
		
	
		});



		$.cookie('iLike-'+blogID, '1', {expires: 270});
		$("#iLike-"+blogID).removeClass('iLikeCount-off').addClass('iLikeCount-on');
		$("#iLikeThis-"+blogID).removeClass('iLikeThis-off').addClass('iLikeThis-on');
	}
}





function generateListKetStrat(xmlFile, divID, categoryTitle)
{
	var html = '';
	var title = '';
	var description = '';
	var linkP = '';
	var image = '';
	var keyStratID='';

	
	var keyStratArray=new Array(); 
	keyStratArray[0]="Attract, develop and retain top talent"; 
	keyStratArray[1]="Focus on UHNW client segment";
	keyStratArray[2]="World class product platform";
	keyStratArray[3]="Consistent client proposition and experience";
	keyStratArray[4]="Globalize the operating model";
	keyStratArray[5]="Repositioning the US franchise";
	
	
	
	$.get(xmlFile, function(xml){

		$("item", xml).each(function(){
			var $item = $(this);
			var categoryMatch = 0;
			
			

			if ($(this).attr("keyHighlight")=="1"){
			// IN KEY HIGHLIGHT ***********************

				//var itemCategoryName = $item.find('category').text();

				// CATEGORY
				if ((categoryTitle == "mostRecent")&&(keyStratID == '')){
						
					//console.log("mostRecentKeyStratID: "+mostRecentKeyStratID);	
					$(this).find("category").each(function(){
							itemCategoryName = getNodeText(this);							   
	
							var i=0;
							for (i=0;i<=5;i++)
							{
								if (itemCategoryName == keyStratArray[i]){
									categoryMatch = 1;
									keyStratID = i;
									//console.log(mostRecentKeyStratID);
								}
							}
					});								
							
				}else{
					$(this).find("category").each(function(){
							itemCategoryName = getNodeText(this);							   
	
							if (categoryTitle == itemCategoryName){
								
								var i=0;
								for (i=0;i<=5;i++)
								{
									if (itemCategoryName == keyStratArray[i]){
										keyStratID = i;
									}
								}								
								
								categoryMatch = 1;
							}
							
					});						
				}
				
				


				if (categoryMatch == 1){
				// found both category and keyHighlight
					title 		= $item.find('title').text();
					description = $item.find('description').text();
					linkP 		= $item.find('link').text();
					image = $item.find('image').text();

					/*if (image){
					}else{
						image = "/common-media/images/generic-announcement.jpg";
					}*/
					
					//html += "<a href=\""+linkP+"\">";
					
					html =  "<div>\n";
					html += "	<div id=\"capslide_img_cont\" class=\"ic_container\">\n";
					html += "		<div style=\"height:280px; width:383px; overflow:hidden;\"><img src=\""+image+"\" width=\"383\" height=\"281\" alt=\"\"/></div>\n";
					html += "		<div class=\"overlay\" style=\"display:none;\"></div>\n";
					html += "		<div class=\"ic_caption\">\n";

					//html += "			<p class=\"ic_category\">Category</p>\n";
					html += "			<div class=\"ic_bg\"></div>\n";	

					html += "			<a href=\""+linkP+"\">\n";					
					html += "			<div class=\"ic_title\">"+title+"</div>\n";
					html += "			<div class=\"ic_text\">"+description+"</div>\n";
					html += "			</a>\n";
					
					
					html += "		</div>\n";
					
					
					html += "	</div>\n";
					html += "</div>\n";

			
					
					
				// end found both category and keyHighlight
				}

			// IN KEY HIGHLIGHT ***********************
			}
		});
		
		

		$(divID).html(html).slideDown("slow");
		
		
		$("#accordion").accordion({ active: keyStratID }).css("visibility", "visible");
		
                $("#capslide_img_cont").capslide({
                    caption_color	: 'white',
                    caption_bgcolor	: '',
                    overlay_bgcolor : '',
                    border			: '',
                    showcaption	    : false
                });
				$("#capslide_img_cont").corner("10px cc:#ECECEC");

				
				/*
                $("#capslide_img_cont2").capslide({
                    caption_color	: 'black',
                    caption_bgcolor	: '#E6E79C',
                    overlay_bgcolor : '#E6E79C',
                    border			: '',
                    showcaption	    : true
                });
                $("#capslide_img_cont3").capslide({
                    caption_color	: '#fff',
                    caption_bgcolor	: '#000',
                    overlay_bgcolor : 'blue',
                    border			: '',
                    showcaption	    : true
                });		
				*/
		
		
	});
} 



function generateListKeyStrat2(xmlFile, divID, categoryTitle)
{
	var html = '';
	var title = '';
	var description = '';
	var linkP = '';
	var image = '';
	var keyStratID='';
	var regionID = getRegionCook(); // Needs jquery.cookie
	var fullRegionName = "";
	fullRegionName = getCategoryNameRegion(regionID);
	//alert(categoryCheck);
	
	
	var keyStratArray=new Array(); 
	keyStratArray[0]="Attract, develop and retain top talent"; 
	keyStratArray[1]="Focus on UHNW client segment";
	keyStratArray[2]="World class product platform";
	keyStratArray[3]="Consistent client proposition and experience";
	keyStratArray[4]="Globalize the operating model";
	keyStratArray[5]="Repositioning the US franchise";
	
	
	var itemMatch = 0;
	
	$.get(xmlFile, function(xml){

		$("item", xml).each(function(){
			var $item = $(this);
			var categoryMatch = 0;
			var regionMatch = 0;
			
			
			

			if (($(this).attr("keyHighlight")=="1")&&(itemMatch == 0)){
			// IN KEY HIGHLIGHT ***********************


				// CATEGORY
				if (categoryTitle == "mostRecent"){
						
					$(this).find("category").each(function(){
							itemCategoryName = getNodeText(this);							   
							
							// CHECK TO SEE IF REGIONS MATCH
							if ((itemCategoryName == fullRegionName) || (regionID==0) || (itemCategoryName=="Global")){
								//alert($item.find('title').text() + " - "+itemCategoryName);
								regionMatch = 1;
							}

							// loop to see if any cat matches key Strat
							var i=0;
							for (i=0;i<=5;i++)	{
								if ((itemCategoryName == keyStratArray[i]) && (categoryMatch == 0)){
									categoryMatch = 1;
									keyStratID = i;
								}
							}
							// end loop to see if matches any one of the key strats
							
					});								
					// end looping through each category
						
					//if ((categoryMatch == 1) && (regionMatch == 1)){
					if (regionMatch == 1){
						itemMatch = 1;
					}
						 

				}else{
					$(this).find("category").each(function(){
							itemCategoryName = getNodeText(this);							   
	
							// CHECK TO SEE IF REGIONS MATCH
							if ((itemCategoryName == fullRegionName) || (regionID==0) || (itemCategoryName=="Global")){
								//alert($item.find('title').text() + " - "+itemCategoryName);
								regionMatch = 1;
							}	
	
	
							if (categoryTitle == itemCategoryName){
								
								var i=0;
								for (i=0;i<=5;i++)
								{
									if (itemCategoryName == keyStratArray[i]){
										keyStratID = i;
									}
								}								
								categoryMatch = 1;
							}
							
					});						

					if ((categoryMatch == 1) && (regionMatch == 1)){
						itemMatch = 1;
					}


				}
				
				


				if (itemMatch == 1){
				// found both category and keyHighlight
					title 		= $item.find('title').text();
					
					description = $item.find('description').text();
					linkP 		= $item.find('link').text();
					image = $item.find('image').text();

					/*if (image){
					}else{
						image = "/common-media/images/generic-announcement.jpg";
					}*/
					
					//html += "<a href=\""+linkP+"\">";
					
					html =  "<div>\n";
					html += "	<div id=\"capslide_img_cont\" class=\"ic_container\">\n";
					html += "		<div style=\"height:280px; width:383px; overflow:hidden;\"><img src=\""+image+"\" width=\"383\" height=\"281\" alt=\"\"/></div>\n";
					html += "		<div class=\"overlay\" style=\"display:none;\"></div>\n";
					html += "		<div class=\"ic_caption\">\n";

					//html += "			<p class=\"ic_category\">Category</p>\n";
					html += "			<div class=\"ic_bg\"></div>\n";	

					html += "			<a href=\""+linkP+"\">\n";					
					html += "			<div class=\"ic_title\">"+title+"</div>\n";
					html += "			<div class=\"ic_text\">"+description+"</div>\n";
					html += "			</a>\n";
					
					
					html += "		</div>\n";
					
					
					html += "	</div>\n";
					html += "</div>\n";

			
					
					
				// end found both category and keyHighlight
				}

			// IN KEY HIGHLIGHT ***********************
			}
		});
		
		

		$(divID).html(html).slideDown("slow");
		
		
		//$("#accordion").accordion({ active: keyStratID }).css("visibility", "visible");
		
                $("#capslide_img_cont").capslide({
                    caption_color	: 'white',
                    caption_bgcolor	: '',
                    overlay_bgcolor : '',
                    border			: '',
                    showcaption	    : false
                });
				//$("#capslide_img_cont").corner("10px cc:#ECECEC");
				$("#capslide_img_cont").corner("10px cc:#FFFFFF");
				
				$("#six-key-all-strats ul li a").removeClass('on');
				$("#strat-"+keyStratID).addClass('on');


				$("#strat-"+keyStratID).addClass('on');
				
				var six_key_title_html = "<a href='/news-announcements/?cat="+keyStratArray[keyStratID]+"'>"+keyStratArray[keyStratID]+"</a>";
				$("#six-key-title").html(six_key_title_html).slideDown("slow");
		
				var mainStoryURL = $(".ic_caption").find("a").attr('href');
				
				$("#capslide_img_cont").hover(
					function() {
						$(".ic_title").addClass("ic_title_over");
					},
					function() {
						$(".ic_title").removeClass("ic_title_over");
					}
				);
				
				
				
				
				$("#capslide_img_cont").click(function() {
						
					var msu = mainStoryURL.indexOf("player.htm");
					
					if (msu > 0){
						
						$.fancybox(
							{
							'href'				: mainStoryURL,
							'width'				: 875,
							'height'			: 600,
							'autoScale'     	: false,
							'transitionIn'		: 'none',
							'transitionOut'		: 'none',
							'type'				: 'iframe'
							}
						);

					
					}else{
						$(location).attr('href',mainStoryURL);
					}
					
					
				});
				
				//alert(linkBlock);
				
				

		
	});
} 





function generateListCarousel(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, numItems)
{
	
	
	var html = '<ul id="mycarousel" class="jcarousel-skin-tango">';
	var count = 0;
	var linkP = "";
	var regionID = $.cookie('regionIDcookie'); // Needs jquery.cookie
	var categoryCheck = "";
	
	if (regionID == 0) categoryCheck = "Global";
	if (regionID == 1) categoryCheck = "Asia";
	if (regionID == 2) categoryCheck = "EMEA";
	if (regionID == 3) categoryCheck = "Latin America";
	if (regionID == 4) categoryCheck = "North America";

	//alert (categoryCheck);


	
	if (showFirstItem != 0){
			numItems = numItems - 1;
	}
	
	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(){

			var categoryMatch = 0;
			var $item = $(this);
			var description = $item.find('description').text();
			var tag = $item.find('tag').text();
			var linkP = $item.find('link').text();
			//alert(description);
	
	
				
			// CATEGORY
			$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if ((categoryCheck == itemCategoryName) || (itemCategoryName == "Global")){
						categoryMatch = 1;
					}
			});		
			
			
	
	
			if ( ((showFirstItem == 0)&&(count == 0)) || (categoryMatch == 0) ){
			}else{
				html += "<li>";
				$(this).find("image").each(function(){
					// IMAGE 	
					if (showImage){	html += "<a href='" + linkP + "'><div class='image-carousel'><img src='" + getNodeText(this) + "'></div></a>"; }
				}).end().find("link").each(function(){
						//linkP = getNodeText(this);
						html += "<div class='title'><a href='" + linkP +"'>";
				}).end().find("title").each(function(){
						html += getNodeText(this) + "</a></div>";
				}).end().find("pubDate").each(function(){
					// DATE 	
					if (showDate){	html += "<div class='date'>" + getNodeText(this) + "</div>"; }
				}).end().find("description").each(function(){
					if ((showDesc)&&(description)){	html += "<div class='description'>" + description +"</div>"; }
				}).end().find("tag").each(function(){
					if (tag){	html += "<div class='tag'>Catagory: <a href=''>" + tag +"</a></div>"; }
				});
				html += "<div class='clear'></div></li>";
			}


			if (count == numItems){ return false; }				
			count = count + 1;

		});
		html += "</ul>";
		
		$(divID).html(html).slideDown("slow");
		
		
		jQuery('#mycarousel').jcarousel({
			auto: 0,
			wrap: 'last',
			initCallback: mycarousel_initCallback,
			itemLoadCallback: itemLoadCallbackFunction

		});
		
		$(".image-carousel").corner("8px cc:#f5f5f5");
		
		var i=1;
		for (i=1;i<=numItems;i++)
		{
			var image_ht = $(".jcarousel-item-"+i+" .image-carousel").height();
			var title_ht = $(".jcarousel-item-"+i+" .title").height();
			var desc_ht  = $(".jcarousel-item-"+i+" .description").height();
			var total_ht = image_ht + title_ht + desc_ht;
			
			//console.log(i+": "+image_ht+" - "+title_ht+" - "+desc_ht+" = "+total_ht);
			if (total_ht > 158){
					//alert("in here-"+i);
					$(".jcarousel-item-"+i).append("<div class='dots_more'>...</div>");
			}

		}
		
		
	});
	
	
	
	
		/*jQuery(document).ready(function() {
			
			jQuery('#mycarousel').jcarousel({
				auto: 6,
				wrap: 'last',
				initCallback: mycarousel_initCallback
			});
		});
		*/
	
	
	
	
} 


function getCategoryNameRegion(regionID)
{
	if (regionID == 0) catCheck = "Global";
	if (regionID == 1) catCheck = "Asia";
	if (regionID == 2) catCheck = "EMEA";
	if (regionID == 3) catCheck = "Latin America";
	if (regionID == 4) catCheck = "North America";
	
	return catCheck;
	
}


function getRegionShortname(regionID)
{
	if (regionID == 0) catCheck = "global";
	if (regionID == 1) catCheck = "asia";
	if (regionID == 2) catCheck = "emea";
	if (regionID == 3) catCheck = "latam";
	if (regionID == 4) catCheck = "noam";
	
	return catCheck;
	
}


function generateListCarousel2(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, numItems)
{
	
	
	var html = '<ul id="mycarousel" class="jcarousel-skin-tango">';
	var count = 0;
	var linkP = "";
	var regionID = $.cookie('regionIDcookie'); // Needs jquery.cookie
	var categoryCheck = "";
	categoryCheck = getCategoryNameRegion(regionID);
	


	
	if (showFirstItem != 0){
			numItems = numItems - 1;
	}
	
	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(){

			var categoryMatch = 0;
			var $item = $(this);
			var description = $item.find('description').text();
			var tag = $item.find('tag').text();
			var linkP = $item.find('link').text();
			//alert(description);
	
	
				
			// CATEGORY
			$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if ((categoryCheck == itemCategoryName) || (itemCategoryName == "Global") || (regionID == 0) ){
						categoryMatch = 1;
					}
			});		
			
			
	
	
			if ( ((showFirstItem == 0)&&(count == 0)) || (categoryMatch == 0) ){
			}else{
				html += "<li>";
				$(this).find("image").each(function(){
					// IMAGE 	
					if (showImage){	html += "<a href='" + linkP + "'><div class='image-carousel'><img src='" + getNodeText(this) + "'></div></a>"; }
				}).end().find("link").each(function(){
						//linkP = getNodeText(this);
						html += "<div class='ic_bg5'></div><div class='title'><a href='" + linkP +"'>";
				}).end().find("title").each(function(){
						html += getNodeText(this) + "</a></div>";
				}).end().find("pubDate").each(function(){
					// DATE 	
					if (showDate){	html += "<div class='date'>" + getNodeText(this) + "</div>"; }
				}).end().find("description").each(function(){
					if ((showDesc)&&(description)){	html += "<div class='description'>" + description +"</div>"; }
				}).end().find("tag").each(function(){
					if (tag){	html += "<div class='tag'>Catagory: <a href=''>" + tag +"</a></div>"; }
				});
				html += "<div class='clear'></div></li>";
			
				count = count + 1;
			}

			if ((count-1) == numItems){ return false; }				
		


		});
		html += "</ul>";
		
		$(divID).html(html).slideDown("slow");
		
		
		jQuery('#mycarousel').jcarousel({
			auto: 0,
			wrap: 'last',
			initCallback: mycarousel_initCallback,
			itemLoadCallback: itemLoadCallbackFunction

		});
		
		/*$(".image-carousel").corner("8px cc:#f5f5f5"); */
		
		/*
		var i=1;
		for (i=1;i<=numItems;i++)
		{
			var image_ht = $(".jcarousel-item-"+i+" .image-carousel").height();
			var title_ht = $(".jcarousel-item-"+i+" .title").height();
			var desc_ht  = $(".jcarousel-item-"+i+" .description").height();
			var total_ht = image_ht + title_ht + desc_ht;
			
			//console.log(i+": "+image_ht+" - "+title_ht+" - "+desc_ht+" = "+total_ht);
			if (total_ht > 158){
					//alert("in here-"+i);
					$(".jcarousel-item-"+i).append("<div class='dots_more'>...</div>");
			}

		}
		*/
		
	});
	
		
	
	
	
	
		/*jQuery(document).ready(function() {
			
			jQuery('#mycarousel').jcarousel({
				auto: 6,
				wrap: 'last',
				initCallback: mycarousel_initCallback
			});
		});
		*/
	
	
	
	
} 









function getLastDate(xmlFile, divID)
{
	var date_html ='';

	$.get(xmlFile, function(xml){

		$("item", xml).each(function(){
			
			var $item = $(this);
			$(this).find("pubDate").each(function(){
				date_html += "<div class='date'>" + getNodeText(this) + "</div>"; 
			});
			return false;
		});

		$(divID).html(date_html).slideDown("slow");
	}); //end get
} 




function getNodeText(node)
{
	var text = "";
	if(node.text) text = node.text;
	if(node.firstChild) text = node.firstChild.nodeValue;
	return text; 
} 


function getNewsXML(tabID)
{
	var regionNewsXML = "";
	
	if (tabID=="news-asia"){
		regionNewsXML = asiaNewsXML;
	}else if (tabID=="news-emea"){
		regionNewsXML = emeaNewsXML;
	}else if (tabID=="news-latAm"){
		regionNewsXML = latAmNewsXML;
	}else if (tabID=="news-noAm"){
		regionNewsXML = noAmNewsXML;
	}else{
		regionNewsXML = globalNewsXML;
	}

	return  regionNewsXML;
}


function getNewsDir(tabID)
{
	var newsDir = "";
	
	if (tabID=="news-asia"){
		newsDir = "asia";
	}else if (tabID=="news-emea"){
		newsDir = "emea";
	}else if (tabID=="news-latAm"){
		newsDir = "latAm";
	}else if (tabID=="news-noAm"){
		newsDir = "noAm";
	}else{
		newsDir = "global";
	}

	return  newsDir;
}


function getNewsSection(tabID)
{
	var newsDir = "";
	
	if (tabID=="news-asia"){
		newsSection = "Asia Pacific";
	}else if (tabID=="news-emea"){
		newsSection = "EMEA";
	}else if (tabID=="news-latAm"){
		newsSection = "Latin America";
	}else if (tabID=="news-noAm"){
		newsSection = "North America";
	}else{
		newsSection = "Global";
	}

	return  newsSection;
}


function getRegionHomepage(tabID)
{
	var regionHome = "";
	
	if (tabID=="news-asia"){
		regionHome = asiaHomepage;
	}else if (tabID=="news-emea"){
		regionHome = emeaHomepage;
	}else if (tabID=="news-latAm"){
		regionHome = latAmHomepage;
	}else if (tabID=="news-noAm"){
		regionHome = noAmHomepage;
	}else{
		regionHome = globalHomepage;
	}

	return  regionHome;
}




function getNews(tabID)
{
	$("#navRegionalSpotLgt li").removeClass('active');
	$("#"+tabID).addClass('active');

	var regionRSS = getNewsXML(tabID);
	var newsDir = getNewsDir(tabID);
	var newsSection = getNewsSection(tabID);
	var regionHomepageLink = getRegionHomepage(tabID);

	
	
	generateList(regionRSS, '#list-announcements-spotlight', 1, 1, 1, 1, 1);
	generateList(regionRSS, '#list-announcements-main', 0, 0, 0, 0, 5);
	
	var linkHTML = "<div class='announce-jumps'><a href='/news-announcements/"+newsDir+"/index.htm' >All " + newsSection + " Announcements</a>";
	if (tabID != "news-global"){
		linkHTML += "&nbsp;&nbsp;|&nbsp;&nbsp;<a href='" + regionHomepageLink + "'>" + newsSection + " Homepage</a>";
	}
	
	linkHTML += "</div>";
	
	$("#list-announcements-all").html(linkHTML);
	
} 



function getMonthName(monthID){
	var id = monthID - 1;
	var monthNameArray = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
	return monthNameArray[id];
}

function getFile(formData){
	//alert(formData.file.value);
	if (formData.file.value==""){
		alert("Please select one of the options");
	}else{
		window.open(formData.file.value, "", "");
	}
}

function getFilePlaybook(formData){
	//alert(formData.file.value);
	if (formData.file.value==""){
		alert("Please select a region");
	}else{
		window.open(formData.file.value, "", "");
	}
}


function getGoodString(str){
	str = str.toLowerCase();
	str = str.replace(/[^a-zA-Z 0-9]+/g,'');
	str = str.replace(/ /g,"-");
	return str;
}




function generateListPlaybook(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, numItems)
{
	//alert("a");
	var html = '<ul>';
	var count = 0;
	var linkP = "";
	
	
	

	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");

		
		$("item", xml).each(function(){
			
			
			var itemP = $(this);
			//var description = itemP.find('description').text();
			//var linkP = itemP.find('link').text();
				
			var pub 	= itemP.find('publication');
			//var issue 	= itemP.find('issue');
			
			var publicationMonth = pub.find('month').text();
			
			var publicationYear = pub.find('year').text();
			var publicationTitle = pub.find('title').text();
			
			
			html += "<li>";

			html += "<div class='rounded-gradient-shadow-fluid'>";
			html += "   <div class='rr-top'><div class='rr-right'></div></div>";
			html += "   <div class='rr-middle'><div class='rr-right'>";
			html += "   <div class='rr-content'>";




			
			html += "<div class='date-1'>"+getMonthName(publicationMonth)+" "+publicationYear+"</div>";
			html += "<div class='title'>"+publicationTitle+"</div>";
					
		
			
			//DOWNLOADS
			itemP.find("downloads:first").each(function(){
				html += "<div class='downloads'>";
				html += "	<h3>Downloads:</h3>";

				var pdfArray = new Array();
				var pptArray = new Array();
				var emailArray = new Array();
				var pdfArrayCount = 0;
				var pptArrayCount = 0;
				var emailArrayCount = 0;
				
				$(this).find("download").each(function(){
					if ($(this).attr("docType") == "pdf"){
						pdfArray[pdfArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
						++pdfArrayCount;
					}else if ($(this).attr("docType") == "ppt"){
						pptArray[pptArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
						++pptArrayCount;
					}else if ($(this).attr("docType") == "email"){
						emailArray[emailArrayCount] = "<option value='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</option>";
						++emailArrayCount;
					}							

					//alert($(this).attr("docType"));
//						pdfArray[arrayCount] = itemP.find("dTitle").text();
					//++arrayCount;
				});
				
				//display the pdf download block
				if (pdfArrayCount > 0){
					html += "<div class='downloadBlock-pdf'>";
					html += "<form><select name='file'>";
					html += "<option value=''>-- select --</option>";
					$.each(pdfArray, function() {
						html += this;
					});
					html += "</select>";
					html += "<input type='image' onclick=\"getFilePlaybook(this.form)\" src='/common-media/images/download_pdf.gif' name='image' width='64px' height='22px' />";
					html += "</form></div>";
				}
				//display the ppt download block
				if (pptArrayCount > 0){
					html += "<div class='downloadBlock-ppt'>";
					html += "<form><select name='file'>";
					html += "<option value=''>-- select --</option>";
					$.each(pptArray, function() {
						html += this;
					});
					html += "</select>";
					html += "<input type='image' onclick=\"getFilePlaybook(this.form)\" src='/common-media/images/download_ppt.gif' name='image' width='64px' height='22px' />";
					html += "</form></div>";
				}
				//display the email download block
				if (emailArrayCount > 0){
					html += "<div class='downloadBlock-email'>";
					html += "<form><select name='file'>";
					html += "<option value=''>-- select --</option>";
					$.each(emailArray, function() {
						html += this;
					});
						html += "</select>";
					html += "<input type='image' onclick=\"getFilePlaybook(this.form)\" src='/common-media/images/download_msg.gif' name='image' width='64px' height='22px' />";
					html += "</form></div>";

				}
				
			html += "</div>";	
			});
			//END DOWNLOADS			
			
			
			html += "</div>";
			html += "</div></div>";
			html += "<div class='rr-bottom'><div class='rr-right'></div></div>";
			html += "</div>";
			// end of the gradient



			html += "<div class='clear'></div>";
			html += "</li>";

			count = count + 1;








		});
		
		html += "</ul>";
		
		
	//$("#list-all").html("asjkajsk"+html+"asasa");
	$(divID).html(html).slideDown("slow");
	//alert(html);

		
	});

} 

function getLatestMonthPlaybook(xmlFile, divID){
	
	var html = '';
	var count = 0;
	

	$.get(xmlFile, function(xml){
		
		$("item:first", xml).each(function(){
			
			var itemP = $(this);
			var pub 	= itemP.find('publication');
			var publicationMonth = pub.find('month').text();
			var publicationYear = pub.find('year').text();
			var publicationTitle = pub.find('title').text();

			html = getMonthName(publicationMonth)+" "+publicationYear;

		});


	$(divID).html(html).slideDown("slow");

	});
	
}





function generateListConviction(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, numItems)
{
	//alert("a");
	var html = "<ul style='padding-top:5px;'>";
	var count = 0;
	var linkP = "";
	
	
	

	$.get(xmlFile, function(xml){
		
		$("item", xml).each(function(){
			
			var itemP = $(this);
				
			var pub 	= itemP.find('publication');
			//var issue 	= itemP.find('issue');
			
			var publicationMonth = pub.find('month').text();
			var publicationYear = pub.find('year').text();
			var publicationDay = pub.find('day').text();
			var publicationTitle = pub.find('title').text();
			
			
			html += "<li>";

			
			html += "<div class='date-1'>"+getMonthName(publicationMonth)+" "+publicationDay+", "+publicationYear+"</div>";
		
			
			//DOWNLOADS
			itemP.find("downloads:first").each(function(){
				html += "<div class='list-A4''><ul>";

				
				$(this).find("download").each(function(){

					html += "<li><a href='"+$(this).find("link").text()+"'>"+$(this).find("title").text()+"</a></li>";

				});
				
				
			html += "</ul></div>";	
			});
			//END DOWNLOADS			
			
			



			html += "<div class='clear'></div>";
			html += "</li>";

			count = count + 1;


		});
		
		html += "</ul>";
		
		

	$(divID).html(html).slideDown("slow");
	//alert(html);

		
	});

} 




/* ------------------ Video --------------------------- */
function generateListVidSub(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, numItems)
{
	var html = '<ul>';
	var count = 0;
	var linkP = "";
	
	if (showFirstItem != 0){
			numItems = numItems - 1;
	}
	

	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(){
			
			var $item = $(this);
			var description = $item.find('description').text();
			var linkP = $item.find('link').text();
			//alert(description);
				
			if ((showFirstItem == 0)&&(count == 0)){
			}else{
				html += "<li>";
				$(this).find("image").each(function(){
					// IMAGE 	
					if (showImage){	html += "<a href='" + linkP + "'><img class='image-main' src='" + getNodeText(this) + "'></a>"; }
				}).end().find("link").each(function(){
						//linkP = getNodeText(this);
						html += "<div class='title'><a href='" + linkP +"'>";
				}).end().find("title").each(function(){
						html += getNodeText(this) + "</a></div>";
				}).end().find("pubDate").each(function(){
					// DATE 	
					if (showDate){	html += "<div class='date'>" + getNodeText(this) + "</div>"; }
				}).end().find("description").each(function(){
					if ((showDesc)&&(description)){	html += "<div class='description'>" + description +"</div>"; }
				});
				html += "<div class='clear'></div></li>";
			}


			if (count == numItems){ return false; }				
			count = count + 1;


		});
		html += "</ul>";
		
		$(divID).html(html).slideDown("slow");
	});
} 


function generateListVidSpotlight(xmlFile, divID, categoryTitle)
{
	var html = '';
	var title = '';
	var description = '';
	var linkP = '';
	var image = '';
	var regionID = getRegionCook(); // Needs jquery.cookie
	var fullRegionName = "";
	fullRegionName = getCategoryNameRegion(regionID);
	//alert(categoryCheck);
	
	
	
	var itemMatch = 0;
	
	$.get(xmlFile, function(xml){

		$("item", xml).each(function(){
			var $item = $(this);
			var categoryMatch = 0;
			var regionMatch = 0;
			
			
			

			if (($(this).attr("keyHighlight")=="1")&&(itemMatch == 0)){
			// IN KEY HIGHLIGHT ***********************


				// CATEGORY
				if (categoryTitle == "mostRecent"){
						
					$(this).find("category").each(function(){
							itemCategoryName = getNodeText(this);							   
							
							// CHECK TO SEE IF REGIONS MATCH
							if ((itemCategoryName == fullRegionName) || (regionID==0) || (itemCategoryName=="Global")){
								//alert($item.find('title').text() + " - "+itemCategoryName);
								regionMatch = 1;
							}

							// loop to see if any cat matches key Strat
										/*
										var i=0;
										for (i=0;i<=5;i++)	{
											if ((itemCategoryName == keyStratArray[i]) && (categoryMatch == 0)){
												categoryMatch = 1;
												keyStratID = i;
											}
										}
										*/
							// end loop to see if matches any one of the key strats
							
					});								
					// end looping through each category
						
					//if ((categoryMatch == 1) && (regionMatch == 1)){
					if (regionMatch == 1){
						itemMatch = 1;
					}
						 

				}else{
					$(this).find("category").each(function(){
							itemCategoryName = getNodeText(this);							   
	
							// CHECK TO SEE IF REGIONS MATCH
							if ((itemCategoryName == fullRegionName) || (regionID==0) || (itemCategoryName=="Global")){
								//alert($item.find('title').text() + " - "+itemCategoryName);
								regionMatch = 1;
							}	
	
	
							if (categoryTitle == itemCategoryName){
								/*
								var i=0;
								for (i=0;i<=5;i++)
								{
									if (itemCategoryName == keyStratArray[i]){
										keyStratID = i;
									}
								}	
								*/
								categoryMatch = 1;
							}
							
					});						

					if ((categoryMatch == 1) && (regionMatch == 1)){
						itemMatch = 1;
					}


				}
				
				


				if (itemMatch == 1){
				// found both category and keyHighlight
					title 		= $item.find('title').text();
					imageTitle	= $item.find('image-title').text();
					imageSubTitle	= $item.find('image-sub-title').text();
					duration	= $item.find('duration').text();
					
					description = $item.find('description').text();
					linkP 		= $item.find('link').text();
					image = $item.find('image').text();

					/*if (image){
					}else{
						image = "/common-media/images/generic-announcement.jpg";
					}*/
					
					//html += "<a href=\""+linkP+"\">";
					
					html =  "<div>\n";
					html += "	<div id=\"capslide_img_cont\" class=\"ic_container\">\n";
					html += "		<div style=\"height:280px; width:383px; overflow:hidden;\"><div id='play-wrap'><div class='play-off' ></div></div><img src=\""+image+"\" width=\"383\" height=\"281\" alt=\"\"/></div>\n";
					html += "		<div class=\"overlay\" style=\"display:none;\"></div>\n";
					html += "		<div class=\"ic_caption\">\n";

					//html += "			<p class=\"ic_category\">Category</p>\n";
					html += "			<div class=\"ic_bg\"></div>\n";	

					html += "			<div class=\"bar-type\">Video</div>";
					html += "			<a href=\""+linkP+"\">\n";					
					html += "			<div class=\"ic_title\">"+imageTitle+"</div>\n";
					html += "			<div class=\"ic_subTitle\">"+imageSubTitle+"</div>\n";
					html += "			</a>\n";
					
					
					html += "		</div>\n";
					
					
					html += "	</div>\n";
					
					html += "	<h3>";
					html += "	<div class='duration'>"+duration+"</div>\n";
					html += 	title+"\n";
					html += "	</h3>";
					html += "	<div class='description'>"+description+"</div>\n";
					html += "	<a class='btn_more' href='javascript:play(1)'>Play Video</a>\n";
					
					//related 
					
					//if ($(this).attr("docType") == "pdf"
					$item.find("related").each(function(){				   
						html += "<div class='related'>";
							
						relatedTitle	= $(this).find('related-title').text();
						if (relatedTitle) html += "<h4>"+relatedTitle+"</h4>";
						
						
						$(this).find("related-items:first").each(function(){
							html += "<div class='list-A4'><ul>";
							
							$(this).find("related-item").each(function(){
								rit = $(this).find("related-item-title").text();
								ril = $(this).find("related-item-link").text();
							
								html += "<li>";
								if (ril){
									html += "<a href='"+ril+"'>"+rit+"</a>";
								}else{
									html += rit;
								}
								html +=	"</li>";	
							});
							html += "</ul></div>";
						});	
						//end related items
						
						
						
						html += "</div>"; //end related div
						
					
					});	
					//end related
						
									
		
					
					
					
					
					
					
					
					
					
					
					html += "</div>\n";

			
					
					
				// end found both category and keyHighlight
				}

			// IN KEY HIGHLIGHT ***********************
			}
		});
		
		

		$(divID).html(html).slideDown("slow");
		
		$("#capslide_img_cont").capslide({
			caption_color	: 'white',
			caption_bgcolor	: '',
			overlay_bgcolor : '',
			border			: '',
			showcaption	    : false
		});
		//$("#capslide_img_cont").corner("10px cc:#ECECEC");
		$("#capslide_img_cont").corner("10px cc:#FFFFFF");
				
		$("#capslide_img_cont").hover(
		function () {
			//alert("ain");
    		//$("#play-button").css('backgroundPosition', '68px 0px');
			$("#play-wrap").html("<div class='play-on'></div>");
			$('.play-on').supersleight();
			
			
  		},
  		function () {
			//alert('as');
    		//$('#play-button').removeClass('play-on').addClass('play-off');
			$("#play-wrap").html("<div class='play-off'></div>");
			$('.play-off').supersleight();
			
  		});
		
			
  
		$('.play-off').supersleight();

		
		
	});
} 



function generateListAllVideo(xmlFile, divID, showDate, showDesc, showImage, showFirstItem, showCategory, numItems, categoryTitle, authorName)
{
	// This function is used on the announcement index pages
		
	var html = '';
	var catTitleHTML = '';


	if (authorName){
		catTitleHTML = "<h2>Author: "+authorName+"</h2>";
	}else if (categoryTitle == null){
		var categoryTitle = "";
		catTitleHTML = "<h2>Category: All</h2>";
	}else{	
		catTitleHTML = "<h2>Category: "+categoryTitle+"</h2>";
	}
	
	html += '<ul>';
	var count = 0;
	var linkP = "";
	

	
	if (showFirstItem != 0){
			numItems = numItems - 1;
	}
	

	$.get(xmlFile, function(xml){

		//var channelTitle = $(xml).find('channel').attr("title");

		$("item", xml).each(function(){
			
			var $item = $(this);
			var itemMatch = 0;
			//var author = $item.find('author').text();
			var description = $item.find('description').text();
			var categoryDiv = "";
			var authorDiv = "";			

			if (categoryTitle == "") itemMatch = 1;
				
			// CATEGORY
			$(this).find("category").each(function(){
					itemCategoryName = getNodeText(this);							   
					if (categoryDiv) categoryDiv += "; ";	
					catLink = "generateListAllVideo(\""+xmlFile+"\",\""+divID+"\","+showDate+","+showDesc+","+showImage+","+showFirstItem+","+showCategory+",999,\""+itemCategoryName+"\")";
					categoryDiv += "<a href='javascript:"+catLink+"'>"+itemCategoryName+"</a>"; 
					
					if (categoryTitle == itemCategoryName){
						itemMatch = 1;
					}
					
			});			
			// END CATEGORY


			// AUTHOR 
			$(this).find("author").each(function(){
					itemAuthorName = getNodeText(this);							   
					if (authorDiv) authorDiv += ", ";	
					
					authorDiv += "<a href=\"?author="+itemAuthorName+"\"> " + itemAuthorName + "</a>"; 
					
					if (authorName == itemAuthorName){
						itemMatch = 1;
					}
					
			});	
			// END AUTHOR


			
			var linkP = $item.find('link').text();
			//alert(description);
				
			if ( ((showFirstItem == 0)&&(count == 0)) || (itemMatch == 0) ){
			}else{
				html += "<li>";
			
				
				// IMAGE
				$(this).find("image").each(function(){
					if (showImage){	html += "<a href='" + linkP + "'><div class=\"story-thumb-wrapper\"><div class=\"story-thumb\"><img src='" + getNodeText(this) + "'></div></div></a>"; }
				});
				
				
				html += "<div class='thumbContent'>";
				html += "<div class=\"hd\">";
			
					$(this).find("link").each(function(){
							//linkP = getNodeText(this);
							html += "<div class='title'><a href='" + linkP +"'>";
					}).end().find("title").each(function(){
							html += getNodeText(this) + "</a></div>";
					}).end().find("pubDate").each(function(){
						// DATE 	
						if (showDate){	html += "<div class='date'>" + getNodeText(this) + "</div>"; }
					});
					
					//AUTHOR
					if (authorDiv){ html += "<div class='author'>by " + authorDiv + "</div>"; }
					
				
				html += "</div>";
				
				
				$(this).find("description").each(function(){
					// DECRIPTION
					if ((showDesc)&&(description)){	html += "<div class='description'>" + description +"</div>"; }
				});
				
				//CATEGORY
				if ((showCategory)&&(categoryDiv)){ html += "<div class='category'>Category: " + categoryDiv + "</div>"; }
		
			
				html += "</div>";
				html += "<div class='clear'></div></li>";
			}


			if (count == numItems){ return false; }				
			count = count + 1;


		});
		html += "</ul>";
		
		$(divID).html(html).slideDown("slow");
		$(".story-thumb").corner("8px cc:#ffffff");
		//$(".story-thumb").css("border", "solid 1px red");
		$("#catTitle").html(catTitleHTML).slideDown("slow");

	});
} 






function generateEmployeesCombinedAsia(xmlFile, divID, roleRequest)
{
	var employeeTableHTML 	=  "<table class='table stripe' id='employeesTable' >";
	employeeTableHTML 	+= "<thead><tr>";
	employeeTableHTML 	+= "<th nowrap='nowrap'>Name</th>";
	employeeTableHTML 	+= "<th>Functions</th>";
	employeeTableHTML 	+= "<th>Department</th>";
	employeeTableHTML 	+= "<th>Phone</th>";
	//employeeTableHTML 	+= "<th style='width:30px' width='30'></th>";
	employeeTableHTML 	+= "</tr></thead>";

	var empCount = 0;
	var empFound = 0;
	var emp = new Array();

	

	
	$.get(xmlFile, function(xml){

		$("region", xml).each(function(){
			var regionP = $(this);
			var regionName = regionP.attr("name");
			
			
			
			//COUNTRY ***************************************

			regionP.find('country').each(function(){
				var country  = $(this);
				
				// fix the recursive country issues
				var hasChildren = country.children().length > 0;
				if (hasChildren){
					var countryName = country.attr("name");
				

					//OFFICES
					country.find("offices:first").each(function(){
	
						//Each office
						$(this).find("office").each(function(){
							var office = $(this);						 	
							var officeName = office.attr("name");

								
							//EMPLOYEE
							office.find("employees:first").each(function(){
			
								//Each employee
								$(this).find("employee").each(function(){
																	   
									var employee = $(this);						 	
									empFound = 0;	
									var employeeRole = employee.attr("role");
												
									if ((officeName == roleRequest) || (roleRequest == null) ){
										var employeeName = employee.attr("name");
										var employeeGEID = employee.attr("webGEID");
										var phone = employee.attr("phone");
										var realRole  = getRoleRealName(employeeRole);
										
										//for each new employee name in the xml loop through the employee array to see if there is a match
										for (x in emp){
											//officeFound = 0;
											
											if (emp[x].name == employeeName){
												empFound = 1;
												
												//see if role = role in xml
												if (emp[x].role == employeeRole){
													
													//add office to the office array
													newNumOffice = emp[x].office.length + 1;
													emp[x].office[newNumOffice] = officeName;
													//console.log(officeName);
													break;
												}else{ // END IF role found
													empFound = 0; //reset the  found flag to 0 to create a new entry
												}
												
											}
										}

										//if i didnt find the employee in the emp array create a new entry
										if (empFound == 0){
												newNum = emp.length + 1;
												//console.log(employeeName);
												
												emp[newNum] = new employeeObj();
												emp[newNum].name 		= employeeName;
												emp[newNum].geid 		= employeeGEID;
												emp[newNum].phone 		= phone;
												emp[newNum].role 		= employeeRole;
												emp[newNum].office 		= new Array();
												emp[newNum].office[0] 	= officeName;
										}
										

										
									}


									
									
									
													
									
								});
								//end each employee
								
							});
							//END EMPLOYEES								
								
								
								
							
							
						});
						//end each office
						
					});
					//END OFFICES



				} // end has children
			});


			//END COUNTRY************************************	
			
			
		});
		//end each region
		
		
		
		for (y in emp){

			officeH = "";
			for (k in emp[y].office){
				officeH += emp[y].office[k];
			}
					
			if (emp[y].geid){
				employeeHTML = "<a target='_new' href='"+gdURL+"?name="+emp[y].name+"&webGEID="+emp[y].geid+"'>"+emp[y].name+"</a>";
			}else{
				employeeHTML = emp[y].name;
			}
			
			employeeTableHTML += "<tr><td>"+employeeHTML+"</td><td>"+emp[y].role+"</td><td>"+officeH+"</td><td>"+emp[y].phone+"</td></tr>";
		}
		employeeTableHTML += "</table>";

		$("#employeesTableDiv").html(employeeTableHTML).slideDown("slow");
		
		$('#employeesTable').dataTable({
			 /*
			"bPaginate": true,
			"bLengthChange": true,
			"bFilter": false,
			"bStateSave": false
			*/
			"bLengthChange": false,
			"iDisplayLength": 20,
			"sPaginationType": "full_numbers"
		});


		$("#hiddenclicker").fancybox({
			'width'				: 450,
			'height'			: 450,
			'autoScale'     	: true,
			'transitionIn'		: 'none',
			'transitionOut'		: 'none',
			'type'				: 'iframe'
		});

		$("input#dataTableSearch").labelify({labelledClass: "labelinside"});

		$('input#dataTableSearch').focus(function() {
			if ($('#searchX').length == 0) {
				$(".input").append("<div id='searchX'></div>")
				$('#searchX').click(function() {
		  			resetDataTable();
				});
			}
		});
	});
	

} 









function generateADVTeamListToDT(divID, params)
{


	
	//DEFAULTS
	var sys = new Object();
	//sys.team = 1;
		
	//OPTIONS
	if (params.team != null) sys.team = params.team;
	
    sys.numItems = sys.numItems + 1 ;
		
	var html 	= "<table id='advTable' class='display table'>";
	html 		+= "<thead><tr><th>Teams</th></tr></thead>";
	html 		+= "<tbody>";
	
	var count = 0;
	var teamArray = new Array;
	

	$.get(globalAdvXML, function(xml){
		
		
		if (sys.team == "all"){
		
				//FOR ALL 
				$("team", xml).each(function(k){
					var faTeam = $(this).text();
					var isTeamFound = 0;
					var len=teamArray.length;
					for(var i=0; i<len; i++) {
						if (faTeam == teamArray[i]){
							isTeamFound = 1;
							break;
						}else{
							isTeamFound = 0;
						}
					}// end for
					
					if (isTeamFound){
						//do nothing
					}else{
						teamArray.push(faTeam);
						//alert('adding: '+faTeam);
					}
				}); //END EACH team
		
				var len2=teamArray.length;
				for(var i=0; i<len2; i++) {
					html += "<tr><td><a href='?team="+teamArray[i]+"'>"+teamArray[i]+ "</a></td></tr>";
				}
				
				$(divID).html(html).slideDown("slow");
				$('#advTable').dataTable({
					"bPaginate": true,
					"bStateSave": false,
					"iDisplayLength": 25,
					"sPaginationType": "full_numbers"
				});
				$("input#dataTableSearch").labelify({labelledClass: "labelinside"});

				
		}else{
			

			generateADVListToDT(divID, params)
			
			
			
			
			
		}
		
		
		


	});// end GET
	
} //END FUNCTION


function generateADVListToDT(divID, params)
{

	
	//DEFAULTS
	var sys = new Object();
	
	//OPTIONS
	if (params.team != null) sys.team = params.team;
	if (params.lob != null) sys.lob = params.lob;
	

    sys.numItems = sys.numItems + 1 ;
	
	var html 	= "";
	if (sys.team) html += "<div class='seeall'><a href='?team=all'>See All</a></div>";
	html 		+= "<table id='advTable'  class='display table'>";
	html 		+= "<thead><tr><th>Last Name</th><th>First Name</th><th>Name</th><th>Bio</th><th>Business Line</th><th>Team</th></tr></thead>";
	html 		+= "<tbody>";
	
	var count = 0;
	var linkP = "";
	var faIDArray = new Array;
	

	$.get(globalAdvXML, function(xml){
		
		$("advisor", xml).each(function(k){
			
			var $item = $(this);
			var faID = $item.attr("faID");
			var lob = $item.attr("lob");
			faIDArray[k] = faID;
			var itemMatch = 0;
			var faName = $item.find('faName').text();
			var faFirstName = $item.find('firstName').text();
			var faLastName = $item.find('lastName').text();
			var team = $item.find('team').text();

			if (sys.team == team) itemMatch = 1;
			if (sys.lob){
				if (sys.lob == lob) itemMatch = 1;
				else itemMatch = 0;
			}
			if(sys.team == null && sys.lob == null) itemMatch = 1;
			
				if (itemMatch){
					html += "<tr>";
					html += "<td>"+faLastName+"</td>";
					html += "<td>"+faFirstName+"</td>";
					html += "<td>"+faName+"</td>";
					html += "<td><a href='"+globalAdvBioURLBase+faID+".pdf'>Bio</a></td>";
					html += "<td>"+lob+"</td>";
					html += "<td><a href='?team="+team+"'>"+team+"</a></td>";
					html += "</tr>";
				}
				
				count = count + 1;
				
			//if (count == sys.numItems){ return false; }				

		}); //END EACH FA

		html += "</tbody>";
		html += "</table>";

		
		
		
		$(divID).html(html).slideDown("slow");
		$('#advTable').dataTable({
			"bPaginate": true,
			"bStateSave": false,
			"iDisplayLength": 50,
			"sPaginationType": "full_numbers"
		});
		$("input#dataTableSearch").labelify({labelledClass: "labelinside"});

		


	});// end GET
	
} //END FUNCTION




function generateFilter(){
	
	var mouse_is_inside = false;
	var filter_open = false;
	   
	$('.filter ul li').hover(function(){ 
       	mouse_is_inside=true; 
		//console.log(mouse_is_inside);
    }, function(){ 
       	mouse_is_inside=false; 
		//console.log(mouse_is_inside);
	});

	$("body").mouseup(function(){ 
    	if(! mouse_is_inside){
			//alert("hiding");
			$('.filter').hide();
		}
	});		
		
	$(".filter-wrapper a").click(function() {
		if 	(filter_open) $(this).parent().find(".filter").hide();
		else $(this).parent().find(".filter").show();
		
		//$(this).parent().find(".filter").toggle();											
											
//			alert("a");

	});
	
	$('#filter-cancel').click(function() {
		$('.filter').hide();
	});	
		
	
	
	

	
	
	
		/*$('.ui-icon-subs').each(function() {
    	//alert("b");
			
   			var dropdownP = $(this);
			var menuP = dropdownP.find('.filter');
			
			var showMenuP = function() {
			
				hideMenuP();
				
				dropdownP.find(".icon").addClass( "dd-open" );
				dropdownP.find(".icon").css({backgroundPosition: '0px -40px'});
				dropdownP.removeClass( "ui-icon-subs-closed" ).addClass( "ui-icon-subs-open" );
				showingFilterP = dropdownP.addClass('dropdown-active');
				showingMenuP = menuP.show();
				showingParentP = parent;
			};
   
   	 		
			
			
			dropdownP.bind('click',function(e) {
      			if(e) e.stopPropagation();
			    if(e) e.preventDefault();
				if(!dropdownP.hasClass('ui-icon-subs-open')){
					showMenuP();
				}else{
				//	hideMenuP();
				}

		    });
			
			
		
		});
		
		
	*/	
		
}// end function	


cpbns.attachVideoOverlaysForLists=function(){

   // if(cpbns.alreadyCalled)return;
	try{
			
		$('a[href*="/video/player.htm"]').fancybox({
			'width'				: 875,
			'height'			: 600,
			'autoScale'     	: false,
			'transitionIn'		: 'none',
			'transitionOut'		: 'none',
			'type'				: 'iframe'
		});		
		
		cpbns.alreadyCalled=true;
	}catch(err)
	{}

};

/*
function attachVideoOverlaysForLists() {
	// attach fancybox to video links
	
	$('a[href*="/video/player.htm"]').fancybox({
		'width'				: 875,
		'height'			: 600,
		'autoScale'     	: false,
		'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'type'				: 'iframe'
	});	
}
*/